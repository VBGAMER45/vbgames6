This is a quick and dirty example on how to add images to your VB menus as well as turn a group of menus items into option buttons.  I've created a class to encapsulate that functionality.  Again, this is a quick and dirty example to show you the different possibilities available to you with VB menus.

Turning a group of menus into option buttons via api calls is a cool little trick.  This is different from the check that VB allows you to do.  the option buttons only allow one of the menus to be selected at a time.  A very usefull little feature.

Hope this helps someone.