
==================== Terms Of Use ==========================  
  
    HEX EDITOR BETA 
    ===============  
    You may freely use and modify the source code  
contained in this program and you may also freely
distribute any application that uses this sample
code or derivations.    
    However, you may not redistribute any part of  
this archive or in any way derive financial gain from  
this sample without the express permission of it's  
author.    
  
    
===================== Requirements ========================  
  
    Screen resolution 800x600 or higher    
  
======================== Comments =========================  

    This Code not is commented... :(  

    Important:
    ==========
    This is a Beta Version, and I'm still working in him.
    This code was not tested fully and still exist some bugs  
that need to be corrected. 
  
  



    About Language Pack:  
    ====================  
    If you translate in new language, please, send me the .lpk  
file.   
    I don't speak English or Spanish very well, and if you
encounter some error in .lpk file, excuse me and please,
send me the correct file too.
  


    If you have some comment to do, please, write me.      

===========================================================  
  
			 HEX EDITOR
		Developed by Fausto C. Arruda  
	        e-mail: cruzarruda@hotmail.com
		    Londrina - Brazil  
  
  
		===========================  
		sorry for my bad english :)    
		===========================  
