	Place Animated Cursors in Standard Messsageboxes
	================================================
Licence:
Do anything you like with it.
Contact:
Bribobs@mail.com

It is possible to hook messages associated with the standard message box to play around with its restricted form (e.g. change button captions, etc.) This example goes a bit further and allows the changing of the icon from one of the four available to any (static) icon. Also, a routine is included to place an animated icon (*.ani file) on a form, or anything that has a hwnd property. By finding the hwnd of the Msgbox icon in the hook procedure, the animation can be placed in the msgbox, as shown in this example.

Note: animated icons cannot usually be loaded from resource files in Windows 9.X (they can be in NT, and probably Windows 2000), and must be loaded from a file. When expanding this zip, tick "use folder names" so the example program can find the anis in the proper place.


Brian Reilly
July 12th 2001.