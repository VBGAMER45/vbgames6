WindowsShares

Scans a network or Internet to detect open shared drives.
This tool is designed for securing your own computing resources
and I take no responsibility if you use it illegally.

You have the right to use the source code, but you may not
resell it or pass it off as your own.

	Timothy Cain
	[Brother Cain Software]
	tim.cain@sentinel1.com