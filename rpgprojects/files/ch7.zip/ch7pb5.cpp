//Written by Jonathan Valentin
//Octerber, 2002
//Chapter 7
//Assigment 5 Quarterly Sales Statistics

#include<iostream.h>
#include<iomanip.h>

float sales [4] [6];

void highestsales(void)
{
float div[6][4];
float quart[4];

 for(int i=1;i < 5;i++)    //quarters
 {
 	for (int g=1; g < 7;g++) // divisoins
   {
    	div[i][g] = 0;

   }
 }

  for(int i=1;i < 5;i++)    //quarters
 {
 	for (int g=1; g < 7;g++) // divisoins
   {
    	div[i][g] = div[i][g] + sales[g][i];

   }

 }

for (int h=1; h < 7; h++)
{
   for (int d2=1; d2 < 7; d2++)
	{

 	if (div[1][h] > div1[1][d2])
   quart[1] = div[1][h];


   }
}
cout <<"The highest sales for Quarter 1 was Division "<<quart[1];
 



} // end highest sales


void averagesales(void)
{
float total[4];
total[1]=0;
total[2]=0;
total[3]=0;
total[4]=0;


 for(int i=1;i < 5;i++)    //quarters
 {
 	for (int g=1; g < 7;g++) // divisoins
   {
    	total[i]=total[i] + sales[g][i];

   }

 }
 total[1]=total[1] / 6;
 total[2]=total[2] / 6;
 total[3]=total[3] / 6;
 total[4]=total[4] / 6;
 total[5]=total[5] / 6;
 total[6]=total[6] / 6;
cout.setf(ios::fixed | ios::showpoint);
cout.precision(2);
cout <<"Quarter 1 Avergae Sales is $"<<total[1]<<endl;
cout <<"Quarter 2 Average Sales is $"<<total[2]<<endl;
cout <<"Quarter 3 Average Sales is $"<<total[3]<<endl;
cout <<"Quarter 4 Average Sales is $"<<total[4]<<endl;
}

void totalsales(void)
{
float total[4];
total[1]=0;
total[2]=0;
total[3]=0;
total[4]=0;


 for(int i=1;i < 5;i++)
 {
 	for (int g=1; g < 7;g++)
   {
    	total[i]=total[i] + sales[g][i];

   }

 }
cout.setf(ios::fixed | ios::showpoint);
cout.precision(2);
cout <<"Quarter 1 Total Sales is $"<<total[1]<<endl;
cout <<"Quarter 2 Total Sales is $"<<total[2]<<endl;
cout <<"Quarter 3 Total Sales is $"<<total[3]<<endl;
cout <<"Quarter 4 Total Sales is $"<<total[4]<<endl;
}


void saleslist(void)
{
float div[6];
div[1]=0;
div[2]=0;
div[3]=0;
div[4]=0;
div[5]=0;
div[6]=0;

 for(int i=1;i < 5;i++)
 {
 	for (int g=1; g < 7;g++)
   {
    	div[g]=div[g] + sales[g][i];

   }

 }
cout.setf(ios::fixed | ios::showpoint);
cout.precision(2);

cout <<"Division 1 Total Sales is $"<<div[1]<<endl;
cout <<"Division 2 Total Sales is $"<<div[2]<<endl;
cout <<"Division 3 Total Sales is $"<<div[3]<<endl;
cout <<"Division 4 Total Sales is $"<<div[4]<<endl;
cout <<"Division 5 Total Sales is $"<<div[5]<<endl;
cout <<"Division 6 Total Sales is $"<<div[6]<<endl;



}

void main(void)
{
 int extest;

 cout <<"Quarterly Sales Statistics"<<endl;
 for(int i=1;i < 5;i++)
 {
 	for (int g=1; g < 7;g++)
   {
    	cout <<"Please enter Division "<<g<<" Quater "<<i<<" Sales: ";
      cin >> sales [g][i];
   }

 }
  cout <<endl;
 saleslist();

 totalsales();

 averagesales();
 highestsales();

 cin >> extest;

}