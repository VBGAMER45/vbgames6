//Written by Jonathan Valentin
//Octerber 2, 2002
//Chapter 7
//Assigment 8 Vector Modification
#include<iostream.h>
#include<iomanip.h>
#include<vector>

using namespace std;

bool testpin(vector<int>,vector<int>);

void main(void)
{
	int extest;
  //int ipin1[7] = {2,4,1,8,7,9,0};
  //int ipin2[7] = {2,4,6,8,7,9,0};
  //int ipin3[7] = {1,2,3,4,5,6,7};

   vector<int> pin1(8);// = {2,4,1,8,7,9,0};
   vector<int> pin2(8);// = {2,4,6,8,7,9,0};
   vector<int> pin3(8);// = {1,2,3,4,5,6,7};
   pin1.at(1)= 2;
   pin1.at(2)=4;
   pin1.at(3)=1;
   pin1.at(4)=8;
   pin1.at(5)=7;
   pin1.at(6)=9;
   pin1.at(7)=0;
   pin2.at(1)=2;
   pin2.at(2)=4;
   pin2.at(3)=6;
   pin2.at(4)=8;
   pin2.at(5)=7;
   pin2.at(6)=9;
   pin2.at(7)=0;
   pin3.at(1)=1;
   pin3.at(2)=2;
   pin3.at(3)=3;
   pin3.at(4)=4;
   pin3.at(5)=5;
   pin3.at(6)=6;
   pin3.at(7)=7;

   if (testpin(pin1,pin2))
   	cout <<"Error: pin1 and pin2 report to be the same. \n";
   else
   	cout <<"Success: pin1 and pin2 are different. \n";
   if (testpin(pin1,pin3))
   	cout <<"Error: pin1 and pin3 report to be the same. \n";
   else
   	cout <<"Success: pin1 and pin3 are different. \n";
   if (testpin(pin1,pin1))
   	cout <<"Error: pin1 and pin1 report to be the same. \n";
   else
   	cout <<"Success: pin1 and pin1 are different. \n";
cin >> extest;
}

bool testpin(vector<int> custpin, vector<int> databasepin)
{
 int k,j;
 	for (short ndx = 0;ndx <7;ndx++)
   {
       j= custpin.at(ndx);
     k= databasepin.at(ndx);

    	if(j !=k)
      {
      	return false;
      }
      return true;
   }

}

