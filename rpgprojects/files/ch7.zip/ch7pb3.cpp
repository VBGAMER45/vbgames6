//Written by Jonathan Valentin
//Octerber, 2002
//Chapter 7
//Assigment 3 Lowercase to Upper Case

#include<iostream.h>
#include<iomanip.h>
#include<ctype.h>

void main(void)
{

 int extest;
 int i;
 char word[30] = "                              ";
 char word2[30];
 i=0;
 cout <<"Lowercase to Uppercase Converter"<<endl;
 cout<<"Please enter a word"<<endl;
 cout.width(30);
 //cin >> word;
 //cout <<endl;
cin.getline(word,30);
while(i <30)
{
 //cout <<toupper(word[i]);
//cout <<int(word[i])<<endl;

 if (int(word[i]) > 97) //" //&& int(word[i]) < 122)
 {

 //cout << char(int(word[i-32]));
 cout <<char(word[i]-32);
 }
 if(int(word[i]) == 32)
 {
  cout <<" ";
 }

 i=i+1;
 }
 cout <<endl;

  cin >> extest;
 cin >> extest;

}