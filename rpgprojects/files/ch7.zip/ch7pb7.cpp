//Written by Jonathan Valentin
//Octerber 2, 2002
//Chapter 7
//Assigment 7 Driver's License Exam
#include<iostream.h>
#include<iomanip.h>

void main(void)
{
int extest;

char answers[21] ={" bdaacabacdbcdadccbda"};
char student[20];
int bad[20];
int correct;
int wrong;
wrong=0;
correct=0;

cout <<"Driver's License Exam"<<endl;

for(int i=1;i<21;i++)
{
 	cout <<"Please enter the answer for question "<<i<<" (a,b,c,d)"<<endl;
   cin >> student[i];

}
for(int i=1;i<21;i++)
{
 	if( int(student[i])==int(answers[i]))
 	{
      correct=correct +1;
	 }
    else
    {
     	bad[i]=i;
    }

}

wrong=20-correct;
if(correct > 14)
{
 	cout <<"The student passed the exam"<<endl;
}
else
{
 cout <<"The student failed the exam"<<endl;
}

cout <<"Total correct answers was "<<correct<<endl;
cout <<"Total wrong answers was "<<wrong<<endl;
cout <<"Questions missed were:"<<endl;
for(int i=1;i<20;i++)
{
 if(bad[i] > 0 && bad[i] <21)
 {
  cout <<" "<<bad[i];

 }


}

cin >> extest;

}