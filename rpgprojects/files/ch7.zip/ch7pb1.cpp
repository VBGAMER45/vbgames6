//Written by Jonathan Valentin
//Octerber, 2002
//Chapter 7
//Assigment 1 Largest/Smallest array values

#include<iostream.h>
#include<iomanip.h>

void main(void)
{
 int num[10];
 int extest;
 int smallest, largest;
 smallest = 10000;
 largest =  -9999;
 cout <<"Largest/Smallest Array Values"<<endl;
 for(int i=1;i < 11;i++)
 {
  cout <<"Please enter in number "<<i<<": ";
  cin >> num[i];
 }

 for(int s=1; s < 11;s++)
 {
 	if (num[s] > largest)
   {
   largest = num[s];
   }
   if (num[s] < smallest)
   {
    smallest = num[s];
   }


 }
cout <<"The largest number is:"<<largest<<endl;
cout <<"The smallest number is:"<<smallest<<endl;


 cin >> extest;

}