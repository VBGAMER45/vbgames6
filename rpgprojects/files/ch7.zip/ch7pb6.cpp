//Written by Jonathan Valentin
//Octerber 2, 2002
//Chapter 7
//Assigment 6 Payroll
#include<iostream.h>
#include<iomanip.h>

void main(void)
{
int extest;
int empid[7] = {5658845,4520125,7895122,8777541,8451277,1302850,7580489};
float payrate[7];
float wages[7];
float hours[7];


cout <<"Payroll"<<endl;

for(int i=0;i < 7;i++)
{
	cout <<"Employee number: "<<empid[i]<<endl;
   cout <<"Please enter the employee's hours: ";
   cin >> hours[i];
   cout <<endl;
   cout <<"Please enter the employee's payrate: ";
   cin >> payrate[i];
   cout <<endl;

   wages[i]=hours[i] * payrate[i];


}
for(int i=0;i < 7;i++)
{
 cout.setf(ios::fixed | ios::showpoint);
 cout.precision(2);
 cout <<"Employee number: " <<empid[i]<<" wages is: $"<<wages[i]<<endl;
}

cin >> extest;
}



