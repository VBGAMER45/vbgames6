//Written by Jonathan Valentin
//Octerber, 2002
//Chapter 7
//Assigment 4 Proper Words

#include<iostream.h>
#include<iomanip.h>
#include<vector>
using namespace std;
vector<char> letters(25,' ');
void output(char word[])
{
	int i =0;

	while(i <25)
	{
 		if (int(word[i]) > 97) //" //&& int(word[i]) < 122)
 		{
 			cout <<char(word[i]-32);
 		}
 		if(int(word[i]) == 32)
      {
		  cout <<" ";
 		}
		 i=i+1;
 		}
 cout <<endl;
}

void main(void)
{

 int extest;
 int i;
 char word[25];
 i=0;
 cout <<"Proper Words"<<endl;
 cout<<"Please enter a string"<<endl;
 cout.width(25);
 cin.getline(word,25);
 output(word);
 cin >> extest;
 cin >> extest;

}