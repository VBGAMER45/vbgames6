//Written by Jonathan Valentin
//Octerber, 2002
//Chapter 7
//Assigment 2 Rainfall Statistics

#include<iostream.h>
#include<iomanip.h>

void main(void)
{
 float num[12];
 int extest;
 int smallest, largest;
 int h,l;
 float total;
 float average;
 smallest = 10000;
 largest =  -9999;
 total =0;
 cout <<"Rainfall Statistics"<<endl;
 for(int i=1;i < 13;i++)
 {
  cout <<"Please enter the rainfall for month "<<i<<": ";
  cin >> num[i];
  total = total + num[i];
 }

 for(int s=1; s < 13;s++)
 {
 	if (num[s] > largest)
   {
   h=s;
   largest = num[s];
   }
   if (num[s] < smallest)
   {
   	l=s;
    smallest = num[s];
   }


 }

cout <<"The highest rainfall is: "<<largest<<" in month number "<<h<<endl;
cout <<"The lowest rainfall is: "<<smallest<<" in month number "<<l<<endl;
average = total / 12;
cout.setf(ios::fixed | ios::showpoint);
cout.precision(2);
cout <<"The average rainfall for each month was: "<<average<<endl;
cout <<"The rainfall for the year is: "<<total<<endl;
 cin >> extest;

}