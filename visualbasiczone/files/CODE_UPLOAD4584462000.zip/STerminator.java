// Processed by NMI's Java Code Viewer 4.8.1 � 1997-2000 B. Lemaire
// Website: http://njcv.htmlplanet.com	E-mail: info@njcv.htmlplanet.com
// Copy registered to Evaluation Copy
// Source File Name:   Snake6110.java

import java.applet.Applet;

class STerminator extends Thread {

    Snake6110 gameApplet;

    STerminator(Applet applet) {
        gameApplet = (Snake6110)applet;
    }

    public void run() {
        synchronized(gameApplet) {
            while(gameApplet.state == 1) 
                try {
                    gameApplet.wait();
                }
                catch(InterruptedException _ex) { }
            gameApplet.terminateGame();
            return;
        }
    }
}
