// Processed by NMI's Java Code Viewer 4.8.1 � 1997-2000 B. Lemaire
// Website: http://njcv.htmlplanet.com	E-mail: info@njcv.htmlplanet.com
// Copy registered to Evaluation Copy
// Source File Name:   SGame.java

import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.*;

public class SGame
    implements Runnable {

    static final int LEVEL_DELAYS[] = {
        490, 361, 282, 233, 172, 136, 108, 88, 75
    };
    static final int MAX_PILLS = 212;
    static final int LEVEL_BONUS = 100;
    static final int EXTRA_TIME = 40;
    int level;
    int score;
    int pills;
    private int overruns;
    private boolean gameValid;
    Snake6110 Snake6110;
    SPlayfield playfield;
    Dimension gridDim;
    Snake playerSnake;
    int playerLives;
    int playerScore;
    SPill pill;
    final int PILL_MAXTIME = 200;
    final int PILL_MAXLENGTH = 10;
    int sleepTime;
    int gridSquares;

    SGame(int i, int j, SPlayfield splayfield, int k, Applet applet) {
        gameValid = true;
        playerLives = i;
        sleepTime = LEVEL_DELAYS[k - 1];
        playfield = splayfield;
        gridDim = splayfield.getGridDimension();
        gridSquares = gridDim.width * gridDim.height;
        Snake6110 = (Snake6110)applet;
        playerSnake = new Snake(j - 1, gridDim.height - 1, j, 4, splayfield);
        pill = new SPill(new Dimension(10, 5), splayfield);
        level = k;
        score = 1350;
        pills = 150;
        overruns = 0;
        gameValid = true;
    }

    public void startGame() {
        pill.draw();
        playerSnake.draw();
    }

    public boolean keyDown(Event event, int i) {
        switch(i) {
        default:
            break;

        case 56: // '8'
        case 1004: 
            playerSnake.setDirection(1);
            break;

        case 50: // '2'
        case 1005: 
            playerSnake.setDirection(2);
            break;

        case 52: // '4'
        case 1006: 
            playerSnake.setDirection(3);
            break;

        case 54: // '6'
        case 1007: 
            playerSnake.setDirection(4);
            break;

        case 49: // '1'
        case 1001: 
            int j = playerSnake.getDirection();
            if(j == 1 || j == 2)
                playerSnake.setDirection(3);
            else
                playerSnake.setDirection(2);
            break;

        case 51: // '3'
        case 1003: 
            int k = playerSnake.getDirection();
            if(k == 1 || k == 2)
                playerSnake.setDirection(4);
            else
                playerSnake.setDirection(2);
            break;

        case 55: // '7'
        case 1000: 
            int l = playerSnake.getDirection();
            if(l == 1 || l == 2)
                playerSnake.setDirection(3);
            else
                playerSnake.setDirection(1);
            break;

        case 57: // '9'
        case 1002: 
            int i1 = playerSnake.getDirection();
            if(i1 == 1 || i1 == 2)
                playerSnake.setDirection(4);
            else
                playerSnake.setDirection(1);
            break;
        }
        return false;
    }

    public int getScore() {
        return score;
    }

    public int getPills() {
        return pills;
    }

    public boolean isGameValid() {
        return gameValid;
    }

    public void run() {
        long l1 = System.currentTimeMillis();
        do {
            l1 += sleepTime;
            long l = l1 - System.currentTimeMillis();
            if(l <= 0L) {
                overruns++;
                if(overruns > 50)
                    gameValid = false;
            } else {
                try {
                    Thread.sleep(l);
                }
                catch(InterruptedException _ex) { }
            }
            if(playerSnake.inDanger())
                try {
                    l1 += 40L;
                    Thread.sleep(40L);
                }
                catch(InterruptedException _ex) { }
            int i = playerSnake.moveSnake();
            switch(i) {
            case 1: // '\001'
                Snake6110.deathClip.play();
                synchronized(Snake6110) {
                    Snake6110.state = 2;
                    Snake6110.notify();
                }
                return;

            case 2: // '\002'
                if(pill != null) {
                    pills++;
                    score += level;
                    if(pills >= 212) {
                        score += 100;
                        synchronized(Snake6110) {
                            Snake6110.state = 2;
                            Snake6110.notify();
                        }
                        return;
                    }
                    Snake6110.eatPillClip.play();
                    playerSnake.addLength(1);
                    pill = null;
                }
                break;
            }
            if(pill == null) {
                pill = randomPill();
                if(pill == null) {
                    synchronized(Snake6110) {
                        Snake6110.state = 2;
                        Snake6110.notify();
                    }
                    return;
                }
                pill.draw();
            }
            playfield.repaint();
        } while(true);
    }

    private SPill randomPill() {
        Dimension dimension = new Dimension();
        int i = gridSquares - playerSnake.getLength() - 1;
        if(i < 0)
            return null;
        int j = (int)(Math.random() * (double)i);
        int k = 0;
        int l = 0;
        int i1 = 0;
        for(int j1 = j; j1 >= 0; j1--)
            do {
                l = k % gridDim.width;
                i1 = k / gridDim.width;
                k++;
            } while(playfield.getSquareContent(l, i1) != 0);

        dimension.width = l;
        dimension.height = i1;
        if(playfield.getSquareContent(l, i1) == 0)
            return new SPill(dimension, playfield);
        else
            return null;
    }

    int getLevel() {
        return level;
    }

}
