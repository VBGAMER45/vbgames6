// Processed by NMI's Java Code Viewer 4.8.1 � 1997-2000 B. Lemaire
// Website: http://njcv.htmlplanet.com	E-mail: info@njcv.htmlplanet.com
// Copy registered to Evaluation Copy
// Source File Name:   SLevel.java

import java.applet.Applet;
import java.awt.*;

public class SLevel extends Canvas {

    Image offImage;
    Graphics offGraphics;
    Applet ownerApplet;
    Font uiFont;
    Dimension fieldDimension;
    int barX;
    int barY;
    int barHeight;
    int barWidth;
    private int level;
    private boolean mouseInside;

    public SLevel(Applet applet) {
        barX = 24;
        barY = 70;
        barHeight = 16;
        barWidth = 13;
        level = 5;
        mouseInside = false;
        ownerApplet = applet;
        level = 1;
    }

    public void initialize() {
        uiFont = new Font("Helvetica", 1, 12);
        fieldDimension = size();
        offImage = createImage(fieldDimension.width, fieldDimension.height);
        offGraphics = offImage.getGraphics();
        offGraphics.setColor(SPlayfield.PF_BACKGROUND);
        offGraphics.fillRect(0, 0, fieldDimension.width, fieldDimension.height);
        offGraphics.setColor(SPlayfield.PF_SNAKE);
        offGraphics.drawRect(0, 0, fieldDimension.width - 1, fieldDimension.height - 1);
        offGraphics.setFont(uiFont);
        offGraphics.drawString("Level:", 12, 18);
        setBackground(SPlayfield.PF_BACKGROUND);
        repaint();
    }

    public void update(Graphics g) {
        if(offImage == null)
            initialize();
        paintUI();
        g.drawImage(offImage, 0, 0, ownerApplet);
    }

    public void paint(Graphics g) {
        update(g);
    }

    public boolean mouseMove(Event event, int i, int j) {
        int k = 1;
        for(int l = 0; l < 9; l++)
            if(i > barX + l * 13)
                k = l + 1;

        if(k != level) {
            level = k;
            repaint();
        }
        mouseInside = true;
        return true;
    }

    public boolean mouseEnter(Event event, int i, int j) {
        mouseInside = true;
        repaint();
        return true;
    }

    public boolean mouseExit(Event event, int i, int j) {
        mouseInside = false;
        repaint();
        return true;
    }

    public int getLevel() {
        return level;
    }

    public void increaseLevel() {
        if(level < 9)
            level++;
        repaint();
    }

    public void decreaseLevel() {
        if(level > 1)
            level--;
        repaint();
    }

    private void paintUI() {
        offGraphics.setColor(SPlayfield.PF_BACKGROUND);
        offGraphics.fillRect(0, 0, fieldDimension.width, fieldDimension.height);
        offGraphics.setColor(SPlayfield.PF_SNAKE);
        offGraphics.drawRect(0, 0, fieldDimension.width - 1, fieldDimension.height - 1);
        offGraphics.setFont(uiFont);
        offGraphics.drawString("Level:", 12, 18);
        int i = barX;
        for(int j = 0; j < 9; j++) {
            offGraphics.drawLine(i, barY - barHeight - j * 4, i, barY);
            offGraphics.drawLine(i, barY - barHeight - j * 4, i + 8, barY - barHeight - j * 4);
            if(j + 1 <= level) {
                for(int k = j + 4; k >= 0; k--)
                    offGraphics.drawLine(i, barY - k * 4, i + 8, barY - k * 4);

            }
            i += 13;
        }

        if(mouseInside)
            offGraphics.drawString("Select level, click to play", 12, barY + 20);
    }
}
