// Processed by NMI's Java Code Viewer 4.8.1 � 1997-2000 B. Lemaire
// Website: http://njcv.htmlplanet.com	E-mail: info@njcv.htmlplanet.com
// Copy registered to Evaluation Copy
// Source File Name:   Snake6110.java

import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.*;
import java.awt.image.MemoryImageSource;
import java.awt.image.PixelGrabber;

public class Snake6110 extends Applet {

    static final int LOOP_DELAY = 490;
    static final int SNAKE_INITLENGTH = 9;
    static final int SET_LEVEL = 0;
    static final int PLAY_GAME = 1;
    static final int GAME_OVER = 2;
    static final int GAME_OVER2 = 3;
    static final int PLAYFIELD_X = 0;
    static final int PLAYFIELD_Y = 0;
    static final int PLAYFIELD_W = 166;
    static final int PLAYFIELD_H = 94;
    SLevel levelUI;
    SPlayfield playfield;
    SGame game;
    Thread gameThread;
    STerminator sterminator;
    HighScore hScore;
    Image bkImg;
    Panel uiPanel;
    Panel statusPanel;
    Button startButton;
    int width;
    int height;
    int gridWidth;
    public AudioClip eatPillClip;
    public AudioClip deathClip;
    int state;
    private int score;
    public boolean speedOk;
    int lblWidth;
    public Image name;
    public Image email;
    public Image ok;
    public Image send;
    public Image cancel;
    public Image draw;
    public Image carve;
    public Image drawcarve;
    public Image drawquest;
    public Image carvequest;
    public Image inst;

    public void init() {
        width = size().width;
        height = size().height;
        String s = getParameter("GRIDWIDTH");
        if(s != null)
            try {
                gridWidth = Integer.parseInt(s);
            }
            catch(NumberFormatException _ex) { }
        name = getImage(getDocumentBase(), "p11.gif");
        email = getImage(getDocumentBase(), "p12.gif");
        send = getImage(getDocumentBase(), "sendit.gif");
        cancel = getImage(getDocumentBase(), "cancel.gif");
        ok = getImage(getDocumentBase(), "ok.gif");
        draw = getImage(getDocumentBase(), "p21.gif");
        carve = getImage(getDocumentBase(), "p31.gif");
        drawcarve = getImage(getDocumentBase(), "p41.gif");
        drawquest = getImage(getDocumentBase(), "kys2.gif");
        carvequest = getImage(getDocumentBase(), "kys1.gif");
        inst = getImage(getDocumentBase(), "plread.gif");
        MediaTracker mediatracker = new MediaTracker(this);
        mediatracker.addImage(name, 0);
        mediatracker.addImage(email, 0);
        mediatracker.addImage(send, 0);
        mediatracker.addImage(cancel, 0);
        mediatracker.addImage(draw, 0);
        mediatracker.addImage(carve, 0);
        mediatracker.addImage(drawcarve, 0);
        mediatracker.addImage(carvequest, 0);
        mediatracker.addImage(drawquest, 0);
        mediatracker.addImage(ok, 0);
        mediatracker.addImage(inst, 0);
        try {
            mediatracker.waitForID(0);
        }
        catch(Exception _ex) { }
        name = imageToRGB(name);
        email = imageToRGB(email);
        send = imageToRGB(send);
        cancel = imageToRGB(cancel);
        draw = imageToRGB(draw);
        carve = imageToRGB(carve);
        drawcarve = imageToRGB(drawcarve);
        carvequest = imageToRGB(carvequest);
        drawquest = imageToRGB(drawquest);
        ok = imageToRGB(ok);
        inst = imageToRGB(inst);
        eatPillClip = getAudioClip(getDocumentBase(), "pill.au");
        eatPillClip.play();
        deathClip = getAudioClip(getDocumentBase(), "gameover.au");
        deathClip.play();
        mediatracker = new MediaTracker(this);
        bkImg = createImage(100, 100);
        playfield = new SPlayfield(gridWidth, this);
        levelUI = new SLevel(this);
        bkImg = imageToRGB(bkImg);
        setLayout(null);
        add(levelUI);
        levelUI.reshape(0, 0, 166, 94);
        validate();
        FontMetrics fontmetrics = getFontMetrics(getFont());
        lblWidth = fontmetrics.stringWidth("Do you wish to post your high-score entry ?");
        hScore = new HighScore(this, lblWidth + 60);
        repaint();
    }

    public void start() {
        requestFocus();
    }

    public void stop() {
        if(gameThread != null) {
            gameThread.stop();
            if(hScore != null)
                hScore.show(false);
        }
    }

    public void paint(Graphics g) {
        g.drawImage(bkImg, 0, 0, this);
    }

    public void update(Graphics g) {
        paint(g);
    }

    public boolean mouseUp(Event event, int i, int j) {
        switch(state) {
        case 0: // '\0'
            startGame();
            break;

        case 3: // '\003'
            remove(playfield);
            add(levelUI);
            validate();
            state = 0;
            repaint();
            break;
        }
        return true;
    }

    public boolean keyDown(Event event, int i) {
        if(state == 1)
            switch(i) {
            case 49: // '1'
            case 50: // '2'
            case 51: // '3'
            case 52: // '4'
            case 54: // '6'
            case 55: // '7'
            case 56: // '8'
            case 57: // '9'
            case 1000: 
            case 1001: 
            case 1002: 
            case 1003: 
            case 1004: 
            case 1005: 
            case 1006: 
            case 1007: 
                if(game != null)
                    game.keyDown(event, i);
                break;

            default:
                return super.keyDown(event, i);
            }
        else
        if(state == 0)
            switch(i) {
            case 1004: 
            case 1007: 
                levelUI.increaseLevel();
                break;

            case 1005: 
            case 1006: 
                levelUI.decreaseLevel();
                break;

            default:
                startGame();
                return super.keyDown(event, i);
            }
        else
        if(state == 3) {
            remove(playfield);
            add(levelUI);
            validate();
            state = 0;
            repaint();
            levelUI.repaint();
            return super.keyDown(event, i);
        }
        return super.keyDown(event, i);
    }

    private void startGame() {
        requestFocus();
        if(gameThread != null)
            gameThread.stop();
        if(hScore != null)
            hScore.hide();
        remove(levelUI);
        add(playfield);
        playfield.reshape(0, 0, 166, 94);
        validate();
        repaint();
        playfield.initialize();
        int i = 1;
        if(levelUI != null)
            i = levelUI.getLevel();
        try {
            Thread.sleep(i * 160);
        }
        catch(InterruptedException _ex) { }
        game = new SGame(3, 9, playfield, i, this);
        gameThread = new Thread(game);
        sterminator = new STerminator(this);
        state = 1;
        game.startGame();
        gameThread.start();
        sterminator.start();
    }

    public void terminateGame() {
        score = game.getScore();
        if(gameThread != null)
            gameThread.stop();
        gameThread = null;
        playfield.displayGameOver(score);
        repaint();
        speedOk = game.isGameValid();
        hScore = new HighScore(this, lblWidth + 60);
        if(score > hScore.getLowScore() && speedOk)
            hScore.initialize(true);
        else
            hScore.initialize(false);
        game = null;
        try {
            Thread.sleep(1500L);
        }
        catch(InterruptedException _ex) { }
        state = 3;
    }

    public int getScore() {
        return score;
    }

    public Image imageToRGB(Image image) {
        int i = image.getWidth(this);
        int j = image.getHeight(this);
        int ai[] = new int[i * j];
        PixelGrabber pixelgrabber = new PixelGrabber(image, 0, 0, i, j, ai, 0, i);
        try {
            pixelgrabber.grabPixels();
        }
        catch(InterruptedException _ex) { }
        MemoryImageSource memoryimagesource = new MemoryImageSource(i, j, ai, 0, i);
        Image image1 = createImage(memoryimagesource);
        image.flush();
        image = null;
        return image1;
    }

    public Snake6110() {
        gridWidth = 20;
        state = 0;
        speedOk = true;
    }
}
