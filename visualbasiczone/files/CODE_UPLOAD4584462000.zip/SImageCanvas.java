// Processed by NMI's Java Code Viewer 4.8.1 � 1997-2000 B. Lemaire
// Website: http://njcv.htmlplanet.com	E-mail: info@njcv.htmlplanet.com
// Copy registered to Evaluation Copy
// Source File Name:   SImageCanvas.java

import java.awt.*;

public class SImageCanvas extends Canvas {

    private int size_x;
    private int size_y;
    private Image img;
    private Image buffer;
    private Graphics buf;

    public SImageCanvas(Image image, int i, int j) {
        size_x = i;
        size_y = j;
        img = image;
    }

    public boolean mouseDown(Event event, int i, int j) {
        Event event1 = new Event(this, 1001, null);
        deliverEvent(event1);
        return super.mouseDown(event, i, j);
    }

    public void update(Graphics g) {
        paint(g);
    }

    public void paint(Graphics g) {
        if(buffer == null || buf == null) {
            buffer = createImage(size_x, size_y);
            buf = buffer.getGraphics();
            buf.setColor(getBackground());
            buf.fillRect(0, 0, size_x, size_y);
        }
        buf.drawImage(img, 0, 0, this);
        g.drawImage(buffer, 0, 0, this);
    }

    public Dimension minimumSize() {
        return new Dimension(size_x, size_y);
    }

    public Dimension preferredSize() {
        return new Dimension(size_x, size_y);
    }
}
