// Processed by NMI's Java Code Viewer 4.8.1 � 1997-2000 B. Lemaire
// Website: http://njcv.htmlplanet.com	E-mail: info@njcv.htmlplanet.com
// Copy registered to Evaluation Copy
// Source File Name:   SPill.java

import java.awt.Dimension;

public class SPill extends SActor {

    int addedLength;
    int scoreValue;
    int scoreConstant;

    SPill(Dimension dimension, SPlayfield splayfield) {
        scoreConstant = 500;
        gridPos.width = dimension.width;
        gridPos.height = dimension.height;
        ownerPlayfield = splayfield;
    }

    public void setPosition(int i, int j) {
        erase();
        gridPos.width = i;
        gridPos.height = j;
        draw();
    }

    public void draw() {
        ownerPlayfield.setSquareContent(gridPos.width, gridPos.height, 2);
    }

    public void erase() {
        ownerPlayfield.setSquareContent(gridPos.width, gridPos.height, 0);
    }
}
