// Processed by NMI's Java Code Viewer 4.8.1 � 1997-2000 B. Lemaire
// Website: http://njcv.htmlplanet.com	E-mail: info@njcv.htmlplanet.com
// Copy registered to Evaluation Copy
// Source File Name:   Snake.java

import java.awt.Dimension;
import java.util.Enumeration;
import java.util.Vector;

public class Snake extends SActor {

    public static final int SNDIR_UP = 1;
    public static final int SNDIR_DOWN = 2;
    public static final int SNDIR_LEFT = 3;
    public static final int SNDIR_RIGHT = 4;
    static final int SN_MAXLENGTH = 256;
    private int length;
    int direction;
    int toGrow;
    int prevMovement;
    Vector segmentCoords;

    Snake(int i, int j, int k, int l, SPlayfield splayfield) {
        segmentCoords = new Vector();
        gridPos.width = i;
        gridPos.height = j;
        length = k;
        direction = l;
        toGrow = 0;
        ownerPlayfield = splayfield;
        ownerPlayfield.getGridDimension();
        for(int i1 = 0; i1 < k; i1++) {
            segmentCoords.insertElementAt(new Dimension(i, j), i1);
            i--;
        }

    }

    public void draw() {
        int i = -1;
        int j = -1;
        for(Enumeration enumeration = segmentCoords.elements(); enumeration.hasMoreElements();) {
            Dimension dimension = (Dimension)enumeration.nextElement();
            ownerPlayfield.setSquareContent(dimension.width, dimension.height, 1);
            if(i >= 0 && j >= 0)
                ownerPlayfield.connectSquares(i, j, dimension.width, dimension.height);
            i = dimension.width;
            j = dimension.height;
        }

    }

    public void erase() {
        Dimension dimension;
        for(Enumeration enumeration = segmentCoords.elements(); enumeration.hasMoreElements(); ownerPlayfield.setSquareContent(dimension.width, dimension.height, 0))
            dimension = (Dimension)enumeration.nextElement();

    }

    public void setPosition(int i, int j) {
        erase();
        segmentCoords.setSize(0);
        gridPos.width = i;
        gridPos.height = j;
        segmentCoords.insertElementAt(new Dimension(i, j), 0);
        toGrow = length - 1;
        length = 1;
        draw();
    }

    public int moveSnake() {
        Dimension dimension = new Dimension(gridPos);
        if(toGrow > 0) {
            length++;
            toGrow--;
        } else {
            Dimension dimension1 = (Dimension)segmentCoords.lastElement();
            segmentCoords.removeElement(dimension1);
            Dimension dimension3 = (Dimension)segmentCoords.lastElement();
            ownerPlayfield.disconnectSquares(dimension1.width, dimension1.height, dimension3.width, dimension3.height);
            ownerPlayfield.setSquareContent(dimension1.width, dimension1.height, 0);
        }
        Dimension dimension2 = ownerPlayfield.getGridDimension();
        switch(direction) {
        default:
            break;

        case 1: // '\001'
            if(gridPos.height < 1)
                return 1;
            gridPos.height--;
            prevMovement = 1;
            break;

        case 2: // '\002'
            if(gridPos.height > dimension2.height - 2)
                return 1;
            gridPos.height++;
            prevMovement = 2;
            break;

        case 3: // '\003'
            if(gridPos.width < 1)
                return 1;
            gridPos.width--;
            prevMovement = 3;
            break;

        case 4: // '\004'
            if(gridPos.width > dimension2.width - 2)
                return 1;
            gridPos.width++;
            prevMovement = 4;
            break;
        }
        int i = ownerPlayfield.getSquareContent(gridPos.width, gridPos.height);
        if(i == 1)
            return i;
        if(i != 0)
            ownerPlayfield.setSquareContent(gridPos.width, gridPos.height, 0);
        ownerPlayfield.setSquareContent(gridPos.width, gridPos.height, 1);
        segmentCoords.insertElementAt(new Dimension(gridPos.width, gridPos.height), 0);
        ownerPlayfield.connectSquares(dimension.width, dimension.height, gridPos.width, gridPos.height);
        return i;
    }

    public void setDirection(int i) {
        switch(i) {
        default:
            break;

        case 2: // '\002'
            if(prevMovement == 1)
                return;
            break;

        case 1: // '\001'
            if(prevMovement == 2)
                return;
            break;

        case 3: // '\003'
            if(prevMovement == 4)
                return;
            break;

        case 4: // '\004'
            if(prevMovement == 3)
                return;
            break;
        }
        direction = i;
    }

    public int getDirection() {
        return direction;
    }

    public void addLength(int i) {
        toGrow += i;
    }

    public int getLength() {
        return length;
    }

    public boolean inDanger() {
        Dimension dimension = new Dimension(gridPos);
        Dimension dimension1 = ownerPlayfield.getGridDimension();
        switch(direction) {
        case 2: // '\002'
            dimension.height++;
            break;

        case 1: // '\001'
            dimension.height--;
            break;

        case 3: // '\003'
            dimension.width--;
            break;

        case 4: // '\004'
            dimension.width++;
            break;
        }
        if(dimension.height < 0 || dimension.height > dimension1.height - 1 || dimension.width < 0 || dimension.width > dimension1.width - 1)
            return true;
        return ownerPlayfield.getSquareContent(dimension.width, dimension.height) == 1;
    }
}
