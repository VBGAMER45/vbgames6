// Processed by NMI's Java Code Viewer 4.8.1 � 1997-2000 B. Lemaire
// Website: http://njcv.htmlplanet.com	E-mail: info@njcv.htmlplanet.com
// Copy registered to Evaluation Copy
// Source File Name:   STextField.java

import java.awt.Dimension;
import java.awt.TextField;

public class STextField extends TextField {

    private int size_x;
    private int size_y;

    public STextField() {
        this(20, 10);
    }

    public STextField(int i, int j) {
        size_x = i;
        size_y = j;
    }

    public Dimension minimumSize() {
        return new Dimension(size_x, size_y);
    }

    public Dimension preferredSize() {
        return new Dimension(size_x, size_y);
    }
}
