// Processed by NMI's Java Code Viewer 4.8.1 � 1997-2000 B. Lemaire
// Website: http://njcv.htmlplanet.com	E-mail: info@njcv.htmlplanet.com
// Copy registered to Evaluation Copy
// Source File Name:   SActor.java

import java.awt.Dimension;

public abstract class SActor {

    SPlayfield ownerPlayfield;
    Dimension maxSize;
    Dimension gridPos;
    Dimension pixelPos;

    public abstract void draw();

    public abstract void erase();

    public abstract void setPosition(int i, int j);

    public Dimension getPosition() {
        return new Dimension(gridPos.width, gridPos.height);
    }

    public SActor() {
        gridPos = new Dimension();
        pixelPos = new Dimension();
    }
}
