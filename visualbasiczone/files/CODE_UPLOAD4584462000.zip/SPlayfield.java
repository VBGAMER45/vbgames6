// Processed by NMI's Java Code Viewer 4.8.1 � 1997-2000 B. Lemaire
// Website: http://njcv.htmlplanet.com	E-mail: info@njcv.htmlplanet.com
// Copy registered to Evaluation Copy
// Source File Name:   SPlayfield.java

import java.applet.Applet;
import java.awt.*;

public class SPlayfield extends Canvas {

    static final int SC_ERROR = -1;
    static final int SC_EMPTY = 0;
    static final int SC_SNAKE = 1;
    static final int SC_PILL = 2;
    static final Color PF_BACKGROUND = new Color(148, 189, 123);
    static final Color PF_GRID;
    static final Color PF_SNAKE = new Color(30, 30, 30);
    static final Color PF_GAMEOVER;
    static final int MARGIN_PIX = 6;
    Dimension fieldDimension;
    Image offImage;
    Graphics offGraphics;
    Applet ownerApplet;
    Image snakeImg;
    Image pillImg;
    int squareSide;
    private Dimension gridDimension;
    private Dimension gridInset;
    Font goFont;
    int gridArray[];

    public SPlayfield(int i, Applet applet) {
        goFont = new Font("Helvetica", 1, 12);
        gridDimension = new Dimension();
        gridInset = new Dimension();
        gridDimension.width = i;
        ownerApplet = applet;
        setBackground(PF_BACKGROUND);
    }

    public void initialize() {
        fieldDimension = new Dimension(166, 94);
        offImage = createImage(fieldDimension.width, fieldDimension.height);
        offGraphics = offImage.getGraphics();
        offGraphics.setColor(PF_BACKGROUND);
        offGraphics.setFont(goFont);
        offGraphics.fillRect(0, 0, fieldDimension.width, fieldDimension.height);
        offGraphics.setColor(PF_SNAKE);
        offGraphics.drawRect(1, 1, fieldDimension.width - 3, fieldDimension.height - 3);
        squareSide = (fieldDimension.width - 6) / gridDimension.width;
        gridDimension.height = (fieldDimension.height - 6) / squareSide;
        snakeImg = createImage(squareSide - 2, squareSide - 2);
        Graphics g = snakeImg.getGraphics();
        g.setColor(PF_SNAKE);
        g.fillRect(0, 0, squareSide - 2, squareSide - 2);
        pillImg = createImage(squareSide - 2, squareSide - 2);
        int i = (squareSide - 2) / 3;
        g = pillImg.getGraphics();
        g.setColor(PF_BACKGROUND);
        g.fillRect(0, 0, squareSide - 2, squareSide - 2);
        g.setColor(PF_SNAKE);
        g.fillRect(i, 0, i, i);
        g.fillRect(0, i, i, i);
        g.fillRect(2 * i, i, i, i);
        g.fillRect(i, 2 * i, i, i);
        gridArray = new int[gridDimension.width * gridDimension.height];
        for(int j = 0; j < gridArray.length; j++)
            gridArray[j] = 0;

    }

    public void clearOffscreen() {
        offImage = null;
        offGraphics = null;
    }

    public void update(Graphics g) {
        reshape(0, 0, 166, 94);
        if(offImage == null)
            initialize();
        g.drawImage(offImage, 0, 0, ownerApplet);
    }

    public void paint(Graphics g) {
        update(g);
    }

    public Dimension getGridDimension() {
        return gridDimension;
    }

    public int getSquareContent(int i, int j) {
        try {
            return gridArray[j * gridDimension.width + i];
        }
        catch(IndexOutOfBoundsException _ex) {
            return -1;
        }
        catch(NullPointerException _ex) {
            return -1;
        }
    }

    public int setSquareContent(int i, int j, int k) {
        try {
            gridArray[j * gridDimension.width + i] = k;
            drawSquareContent(i, j);
            return 0;
        }
        catch(IndexOutOfBoundsException _ex) {
            return -1;
        }
        catch(NullPointerException _ex) {
            return -1;
        }
    }

    private void drawSquareContent(int i, int j) {
        if(offGraphics == null)
            return;
        Dimension dimension = gridToPixels(i, j);
        switch(getSquareContent(i, j)) {
        case -1: 
            return;

        case 0: // '\0'
            offGraphics.setColor(PF_BACKGROUND);
            offGraphics.fillRect(dimension.width, dimension.height, squareSide, squareSide);
            return;

        case 1: // '\001'
            offGraphics.drawImage(snakeImg, dimension.width + 1, dimension.height + 1, this);
            return;

        case 2: // '\002'
            offGraphics.setColor(PF_SNAKE);
            offGraphics.drawImage(pillImg, dimension.width + 1, dimension.height + 1, this);
            break;
        }
    }

    public void connectSquares(int i, int j, int k, int l) {
        if(i > k) {
            int i1 = i;
            i = k;
            k = i1;
        }
        if(j > l) {
            int j1 = j;
            j = l;
            l = j1;
        }
        Dimension dimension = gridToPixels(i, j);
        if(i < k)
            offGraphics.drawImage(snakeImg, dimension.width + squareSide / 2, dimension.height + 1, this);
        if(j < l)
            offGraphics.drawImage(snakeImg, dimension.width + 1, dimension.height + squareSide / 2, this);
    }

    public void disconnectSquares(int i, int j, int k, int l) {
        byte byte0 = 0;
        if(i > k)
            byte0 = 1;
        else
        if(i < k)
            byte0 = 3;
        if(j > l)
            byte0 = 2;
        else
        if(j < l)
            byte0 = 0;
        Dimension dimension = gridToPixels(k, l);
        offGraphics.setColor(PF_BACKGROUND);
        switch(byte0) {
        case 0: // '\0'
            offGraphics.fillRect(dimension.width, dimension.height, squareSide, 1);
            break;

        case 1: // '\001'
            offGraphics.fillRect((dimension.width + squareSide) - 1, dimension.height, 1, squareSide);
            break;

        case 2: // '\002'
            offGraphics.fillRect(dimension.width, (dimension.height + squareSide) - 1, squareSide, 1);
            break;

        case 3: // '\003'
            offGraphics.fillRect(dimension.width, dimension.height, 1, squareSide);
            break;
        }
        offGraphics.setColor(PF_SNAKE);
    }

    public Dimension gridToPixels(int i, int j) {
        int k = i * squareSide + 3;
        int l = j * squareSide + 3;
        return new Dimension(k, l);
    }

    public void displayGameOver(int i) {
        String s = "Your score: " + i;
        offGraphics.setColor(PF_BACKGROUND);
        offGraphics.fillRect(0, 0, fieldDimension.width, fieldDimension.height);
        offGraphics.setColor(PF_SNAKE);
        offGraphics.drawRect(1, 1, fieldDimension.width - 3, fieldDimension.height - 3);
        offGraphics.drawString("Game Over!", 12, 18);
        offGraphics.drawString("Click to play again", 12, 74);
        Graphics g = offImage.getGraphics();
        g.setColor(PF_BACKGROUND);
        g.fillRect(12, 30, 100, 10);
        offGraphics.drawString(s, 12, 36);
        g = null;
        System.gc();
        repaint();
    }

    static  {
        PF_GRID = Color.gray;
        PF_GAMEOVER = Color.cyan;
    }
}
