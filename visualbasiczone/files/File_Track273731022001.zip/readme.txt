##########################
#                        #
# File Tracker           #
# Version 1.0            #
#                        #
# By                     #
# Joel Hill              #
# Web Developer          #
# 		         #
#                        #
# Last Modified 9/17/2001#
#                        #
##########################

This file is free to use, just don't try to sell it. I'm not making any money off it and neither should you. If you do use my code let me know <therogue92@hotmail.com> I'd like to know that my code is actually being used by someone other than me (call it a minor ego boost).

Enjoy the application, if you see ways to improve upon it, let me know. I'm always out to make things better =).



This application allows the user to track traffic to thier site. It was specifically designed to monitor file downloads such as applications or forms. It is assumed that the administrator has a basic understanding of ASP code. Nothing is assumed of the user.

----Version Notes----

1.0 Initial Release

----Files----

There are 23 files in this application all but 3 are contained in folders. They are grouped together for a reason and would be highly in-advisable to break them up. 

make sure these files are contained in the zip file

Admin Folder (contains these files)
	
	Adminadd.asp
	AdminDoAdd.asp
	AdminDoRemove.asp
	AdminDoReset.asp
	AdminDoUpdate.asp
	AdminGetUpdate.asp
	Adminremove.asp
	Adminreset.asp
	Adminupdate.asp
	default.asp

Reports Folder (contains these files)
	
	default.asp
	RptByDate.asp
	RptByDateGet.asp
	RptByFile.asp
	RptByFileGet.asp
	RptLeast.asp
	RptMost.asp

Data Folder (contains these files)

	connect.asp
	Paths.asp
	file_track.mdb

These 3 files do not need to be in a folder and are better off just staying in the root directory.

	list.asp
	download.asp
	default.asp

----Configuration----

2 files set up the configuration for the entire application. 
DO NOT CHANGE ANY OTHER FILES UNLESS ABSOLUTELY NECESSARY AND YOU KNOW WHAT YOU ARE DOING!.

-------------
connect.asp |
-------------

This file contains the connection string necessary to connect to the database. this should be an absolute or virtual path and not a URL.

-----------
Paths.asp |
-----------

This file contains the path information needed to connect the pages in the application. This is done so if you need to move items around the application will continue to work by updating 1 file and not 21! The file itself includes more detailed instructions as to what is expected there. 