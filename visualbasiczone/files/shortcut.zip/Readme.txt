
Thank you for downloading Softuarium Shortcut.

Description
~~~~~~~~~~~
Shortcut is an ActiveX control designed to create shortcuts to programs and documents and place them on desktop.

Installation
~~~~~~~~~~~~
To use Shortcut in your projects you must first register it using
Regsvr32.exe (you'll find it in windows\system directory). 
Alternatively, you can browse for it from within VB IDE, in which case it is registered automatically.
NOTE: you must register the control BEFORE you attempt to use it or run sample project included in the package.

Use
~~~
For practical demonstration please see included sample VB project.
Shortcut has the following properties:

Target (string)
~~~~~~
It is the full path of the file you want the shortcut to point to. 
Example: Shrtcut1.FileName = "c:\program files\adobe\pshop3.exe"

Note: while shortcuts usually point to executable files, it is also possible to create shortcuts to documents registered on your computer (eg. HTML files, images, help files, etc). Occasionally it is also possible to create shortcuts pointing to other, existing shortcuts. Please experiment with the sample project and see what it can do on your machine.

ShortcutName (string)
~~~~~~~~~~~~
Any name you want to associate with the shortcut.
Example: Shrtcut1.ShortcutName = "Run this program"
After the shortcut is placed on your desktop you can always change its name just as you would with any other desktop item. See Windows Help for details.

Shortcut has one method:

Go 
~~
Creates shortcut and places it on the desktop.
Example: Shrtcut1.Go

Release information
~~~~~~~~~~~~~~~~~~~
Shortcut was created and compiled using VB6/SP3.

Pricing
~~~~~~~
Shortcut ActiveX control is freeware. 
You may use it and/or distribute free of charge.
You may not, however, sell it, change the contents of zip file or claim credit.

Disclaimer
~~~~~~~~~~
Shortcut ActiveX control is distributed "as is".  No warranty of any kind is expressed or implied. While every precaution was taken to produce bug free code, you use it at your own risk. The author will not be liable for data loss, damages, loss of profits or any other kind of loss while using or misusing this software.

Credits
~~~~~~~
This software is based in part on work of Dave Scarmozzino (www.thescarms.com).


Thank you for using Softuarium Shortcut ActiveX control.
