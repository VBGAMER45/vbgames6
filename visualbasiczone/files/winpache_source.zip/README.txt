Winpache v1.0 Read Me

(Please do not delete "winpache.gif" in this directory. It is
needed for winpache functions)

With the sudden burst of cable and DSL modems I figured this 
would be a cool project. Now everyone can host their own web
page. If you had DSL or Cable in the past, most Web Servers dont
run on Windows95/98/ME. So you couldn't host your own page, now 
you can. This program has the stability and stregnth to serve
for a long time.
The longest uptime I had with it so far was 1 day 2 hours. I have
a regular dial-up line and my line kicked me off or the webserver
would have kept running. So id like to hear more feedback from
you guys.
This is a Open Source program and the source can be downloaded at
http://members.aol.com/vsabotagev

I can be contacted at sabotage@redconnect.net

I hope you enjoy this program and it really helps you out :)