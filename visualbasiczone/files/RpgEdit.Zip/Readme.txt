                    Wire Technology Presents:
                              Rpg Edit 2.0


    
   Hello this is a Tile Map Editor which is pretty much fully functional but i'm still working on it. I will write a tutorial on how to use the special ".map" files that this editor saves in. With higher resolutions than 800x600 you might notice distoritions, thats because its meant for 800x600 but it should still work properly in higher resolutions.

If you have any questions Email me at: gizmo2001@hotmail.com or 
visit my page @ www.WireTechnology.org

