#ifndef MATHSTACK_H
#define MATHSTACK_H

#include "intstack.h"

class MathStack : public IntStack
{
public:
	MathStack(int s) : IntStack(s) {}
	void add(void);
	void sub(void);
};

#endif
