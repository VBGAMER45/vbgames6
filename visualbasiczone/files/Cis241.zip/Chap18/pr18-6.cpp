// This program demonstrates the DynIntQeue class

#include <iostream.h>
#include "dynintqueue.h"

void main(void)
{
	DynIntQueue iQueue;

	cout << "Enqueuing 5 items...\n";
	// Enqueue 5 items.
	for (int x = 0; x < 5; x++)
		iQueue.enqueue(x);

	// Deqeue and retrieve all items in the queue
	cout << "The values in the queue were:\n";
	while (!iQueue.isEmpty())
	{
		int value;
		iQueue.dequeue(value);
		cout << value << endl;
	}
}
