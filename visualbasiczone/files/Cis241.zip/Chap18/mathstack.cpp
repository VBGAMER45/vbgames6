#include "mathstack.h"

//***********************************************
// Member function add. add pops                *
// the first two values off the stack and       *
// adds them. The sum is pushed onto the stack. *
//***********************************************

void MathStack::add(void)
{
	int num, sum;

	pop(num);
	sum = num;
	pop(num);
	sum += num;
	push(sum);
}

//***********************************************
// Member functon sub. sub pops the             *
// first two values off the stack. The          *
// second value is subtracted from the          *
// first value. The difference is pushed        *
// onto the stack.                              *
//***********************************************

void MathStack::sub(void)
{
	int num, diff;

	pop(num);
	diff = num;
	pop(num);
	diff -= num;
	push(diff);
}

