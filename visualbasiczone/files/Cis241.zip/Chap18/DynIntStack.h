#ifndef DYNINTSTACK_H
#define DYNINTSTACK_H

class DynIntStack
{
private:
	struct stackNode
	{
		int value;
		stackNode *next;
	};

	stackNode *top;

public:
	DynIntStack(void)
			{	top = NULL; }
	void push(int);
	void pop(int &);
	bool isEmpty(void);
};
	
#endif
