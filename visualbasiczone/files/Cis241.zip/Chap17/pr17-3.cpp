// This program calls the displayList member function.
// The function traverses the linked list displaying
// the value stored in each node.

#include <iostream.h>
#include "FloatList.h"

void main(void)
{
	FloatList list;

	// Build the list
	list.appendNode(2.5);
	list.appendNode(7.9);
	list.appendNode(12.6);

	// Insert a node in the middle
	// of the list.
	list.insertNode(10.5);

	// Dispay the list
	list.displayList();
}
