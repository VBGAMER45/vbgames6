// This program demonstrates a simple append
// operation on a linked list.

#include <iostream.h>
#include "floatlist.h"

void main(void)
{
	FloatList list;

	list.appendNode(2.5);
	list.appendNode(7.9);
	list.appendNode(12.6);
}
