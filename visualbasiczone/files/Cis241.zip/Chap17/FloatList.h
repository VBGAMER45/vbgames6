#ifndef FLOATLIST_H
#define FLOATLIST_H

class FloatList
{
private:
	// Declare a structure for the list
	struct ListNode
	{
		float value;
		struct ListNode *next;
	}; 

	ListNode *head;	// List head pointer

public:
	FloatList(void)	// Constructor
		{ head = NULL; }
	~FloatList(void); // Destructor
	void appendNode(float);
	void insertNode(float);
	void deleteNode(float);
	void displayList(void);
};

#endif
