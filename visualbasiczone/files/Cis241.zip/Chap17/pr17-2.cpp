// This program calls the displayList member function.
// The funcion traverses the linked list displaying
// the value stored in each node.

#include <iostream.h>
#include "FloatList.h"

void main(void)
{
	FloatList list;

	list.appendNode(2.5);
	list.appendNode(7.9);
	list.appendNode(12.6);
	list.displayList();
}
