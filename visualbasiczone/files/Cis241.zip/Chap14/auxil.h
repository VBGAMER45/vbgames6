#ifndef AUXIL_H
#define AUXIL_H

class Budget;  // Forward declaration of Budget class 

// Aux class declaration

class Aux
{
private:
	float auxBudget;
public:
	Aux(void) { auxBudget = 0; }
	void addBudget(float, Budget &);
	float getDivBudget(void) { return auxBudget; }
};

#endif
