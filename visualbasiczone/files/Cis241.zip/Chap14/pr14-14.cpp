// This program demonstrates the << and >> operators, 
// overloaded to work with the FeetInches class.

#include <iostream.h>
#include "feetinc6.h"

void main(void)
{
	FeetInches distance;
	float f;
	int i;

	cout << "Enter a distance in feet and inches:\n";
	cin >> distance;
	f = distance;
	i = distance;
	cout << "The value " << distance;
	cout << " is equivalent to " << f << " feet\n";
	cout << "or " << i << " feet, rounded down.\n";
}
