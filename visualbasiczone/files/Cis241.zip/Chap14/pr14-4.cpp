#include <iostream.h>

class Rectangle
{
private:
	float width;
	float length;
	float area;
	void calcArea(void) { area = width * length; }
public:
	void setData(float W, float L)
		{ width = W; length = L; calcArea(); }
	float getWidth(void)
		{ return width; }
	float getLength(void)
		{ return length; }
	float getArea(void)
		{ return area; }
};


void main(void)
{
	Rectangle box1, box2;

	box1.setData(10, 20);
	box2.setData(5, 10);
	cout << "Before the assignment:\n";
	cout << "Box 1's width: " << box1.getWidth() << endl;
	cout << "Box 1's length: " << box1.getLength() << endl;
	cout << "Box 1's area: " << box1.getArea() << endl;
	cout << "Box 2's width: " << box2.getWidth() << endl;
	cout << "Box 2's length: " << box2.getLength() << endl;
	cout << "Box 2's area: " << box2.getArea() << endl;
	box2 = box1;
	cout << "-------------------------\n";
	cout << "After the assignment:\n";
	cout << "Box 1's width: " << box1.getWidth() << endl;
	cout << "Box 1's length: " << box1.getLength() << endl;
	cout << "Box 1's area: " << box1.getArea() << endl;
	cout << "Box 2's width: " << box2.getWidth() << endl;
	cout << "Box 2's length: " << box2.getLength() << endl;
	cout << "Box 2's area: " << box2.getArea() << endl;
}
