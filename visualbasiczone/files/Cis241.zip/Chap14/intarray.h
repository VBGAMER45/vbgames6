#ifndef INTARRAY_H
#define INTARRAY_H


class IntArray
{
private:
	int *aptr;
	int arraySize;
	void memError(void); // Handles memory allocation errors.
	void subError(void); // Handles subscripts out of range.
public:
	IntArray(int);  				// Constructor
	IntArray(const IntArray &); 	// Copy constructor
	~IntArray(void); 				// Destructor
	int size(void)
		{ return arraySize; }
	int &operator[](const int &); // Overloaded [] operator
};

#endif
