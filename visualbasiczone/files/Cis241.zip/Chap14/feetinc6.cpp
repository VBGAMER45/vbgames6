#include <stdlib.h>   // Needed for abs()
#include "feetinc6.h"

//************************************************************
// Definition of member function simplify. This function     *
// checks for values in the inches member greater than       *
// twelve and less than zero. If such a value is found,      *
// the numbers in feet and inches are adjusted to conform    *
// to a standard feet & inches expression. For example,      *
// 3 feet 14 inches would be adjusted to 4 feet 2 inches and *
// 5 feet -2 inches would be adjusted to 4 feet 10 inches.   *
//************************************************************

void FeetInches::simplify(void)
{
	if (inches >= 12)
	{
		feet += (inches / 12); // Integer division
		inches = inches % 12;
	}
	else if (inches < 0)
	{
		feet -= ((abs(inches) / 12) + 1);
		inches = 12 - (abs(inches) % 12);
	}
}

//************************************************************
// Overloaded binary + operator.                             *
//************************************************************

FeetInches FeetInches::operator+(const FeetInches &right)
{
	FeetInches temp;

	temp.inches = inches + right.inches;
	temp.feet = feet + right.feet;
	temp.simplify();
	return temp;
}

//************************************************************
// Overloaded binary - operator.                             *
//************************************************************

FeetInches FeetInches::operator-(const FeetInches &right)
{
	FeetInches temp;

	temp.inches = inches - right.inches;
	temp.feet = feet - right.feet;
	temp.simplify();
	return temp;
}

//*************************************************************
// Overloaded prefix ++ operator. Causes the inches member to *
// be incremented. Returns the incremented object.            *
//*************************************************************

FeetInches FeetInches::operator++()
{
	++inches;
	simplify();
	return *this;
}

//**************************************************************
// Overloaded postfix ++ operator. Causes the inches member to *
// be incremented. Returns the value of the object before the  *
// increment.                                                  *
//**************************************************************

FeetInches FeetInches::operator++(int)
{
	FeetInches temp(feet, inches);

	inches++;
	simplify();
	return temp;
}

//************************************************************
// Overloaded > operator. Returns 1 if the current object is *
// set to a value greater than that of right.                *
//************************************************************

int FeetInches::operator>(const FeetInches &right)
{
	if (feet > right.feet)
		return 1;
	else if (feet == right.feet && inches > right.inches)
		return 1;
	else return 0;
}

//************************************************************
// Overloaded < operator. Returns 1 if the current object is *
// set to a value less than that of right.                   *
//************************************************************

int FeetInches::operator<(const FeetInches &right)
{
	if (feet < right.feet)
		return 1;
	else if (feet == right.feet && inches < right.inches)
		return 1;
	else return 0;
}

//*************************************************************
// Overloaded == operator. Returns 1 if the current object is *
// set to a value equal to that of right.                     *
//*************************************************************

int FeetInches::operator==(const FeetInches &right)
{
	if (feet == right.feet && inches == right.inches)
		return 1;
	else return 0;
}

//*************************************************************
// Conversion function to convert a FeetInches object         *
// to a float.                                                *
//*************************************************************

FeetInches::operator float()
{
	float temp = feet;

	temp += (inches / 12.0);
	return temp;
}

//********************************************************
// Overloaded << operator. Gives cout the ability to     *
// directly display FeetInches objects.                  *
//********************************************************

ostream &operator<<(ostream &strm, FeetInches &obj)
{
	strm << obj.feet << " feet, " << obj.inches << " inches";
	return strm;
}

//********************************************************
// Overloaded >> operator. Gives cin the ability to      *
// store user input directly into FeetInches objects.    *
//********************************************************

istream &operator>>(istream &strm, FeetInches &obj)
{
	cout << "feet: ";
	strm >> obj.feet;
	cout << "inches: ";
	strm >> obj.inches;
	return strm;
}
