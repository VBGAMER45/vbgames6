// This program demonstrates the overloaded = operator.

#include <iostream.h>
#include <string.h>  // For strlen

class PersonInfo
{
private:
	char *name;
	int age;
public:
	PersonInfo(char *n, int a)
		{ name = new char[strlen(n) + 1];
		  strcpy(name, n); 
		  age = a; }
	PersonInfo(const PersonInfo &obj) // Copy constructor
		{ name = new char[strlen(obj.name) + 1];
		  strcpy(name, obj.name); 
		  age = obj.age; }
	~PersonInfo(void)
		{ delete [] name; }
	char *getName(void)
		{ return name; }
	int getAge(void)
		{ return age; }
	void operator=(const PersonInfo &right)
		{ delete [] name;
		  name = new char[strlen(right.name) + 1];
		  strcpy(name, right.name); 
		  age = right.age; }
};

void main(void)
{
	PersonInfo jim("Jim Young", 27),
	           bob("Bob Faraday", 32), 
	           clone = jim;

	cout << "The Jim Object contains: " << jim.getName();
	cout << ", " << jim.getAge() << endl;
	cout << "The Bob Object contains: " << bob.getName();
	cout << ", " << bob.getAge() << endl;
	cout << "The Clone Object contains: " << clone.getName();
	cout << ", " << clone.getAge() << endl;
	cout << "Now the Clone will change to Bob and ";
	cout << "Bob will change to Jim.\n";
	clone = bob;	// Call overloaded = operator
	bob = jim;		// Call overloaded = operator
	cout << "The Jim Object contains: " << jim.getName();
	cout << ", " << jim.getAge() << endl;
	cout << "The Bob Object contains: " << bob.getName();
	cout << ", " << bob.getAge() << endl;
	cout << "The Clone Object contains: " << clone.getName();
	cout << ", " << clone.getAge() << endl;
}
