#include <iostream.h>
#include "intarray.h"

void main(void)
{
	IntArray table(10);

	// Store values in the array.
	for (int x = 0; x < 10; x++)
		table[x] = x;
	// Display the values in the array.
	for (x = 0; x < 10; x++)
		cout << table[x] << " ";
	cout << endl;
	cout << "Now attempting to store a value in table[11].\n";
	table[11] = 0;
}
