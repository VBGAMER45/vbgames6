#include <iostream.h>
#include <stdlib.h>
#include "intarray.h"

//*******************************************************
// Constructor for IntArray class. Sets the size of the *
// array and allocates memory for it.                   *
//*******************************************************

IntArray::IntArray(int s)
{
	arraySize = s;
	aptr = new int [s];
	if (aptr == 0)
		memError();
	for (int count = 0; count < arraySize; count++)
		*(aptr + count) = 0;
}

//******************************************************
// Copy Constructor for IntArray class.                *
//******************************************************

IntArray::IntArray(const IntArray &obj)
{
	arraySize = obj.arraySize;
	aptr = new int [arraySize];
	if (aptr == 0)
		memError();
	for(int count = 0; count < arraySize; count++)
		*(aptr + count) = *(obj.aptr + count);
}

//******************************************************
// Destructor for IntArray class.                      *
//******************************************************

IntArray::~IntArray(void)
{
	if (arraySize > 0)
		delete [] aptr;
}

//*******************************************************
// memError function. Displays an error message and     *
// terminates the program when memory allocation fails. *
//*******************************************************

void IntArray::memError(void)
{
	cout << "ERROR:Cannot allocate memory.\n";
	exit(0);
}

//***********************************************************
// subError function. Displays an error message and         *
// terminates the program when a subscript is out of range. *
//***********************************************************

void IntArray::subError(void)
{
	cout << "ERROR: Subscript out of range.\n";
	exit(0);
}

//*******************************************************
// Overloaded [] operator. The argument is a subscript. *
// This function returns a reference to the element     *
// in the array indexed by the subscript.               *
//*******************************************************

int &IntArray::operator[](const int &sub)
{
	if (sub < 0 || sub > arraySize)
		subError();
	return aptr[sub];
}
