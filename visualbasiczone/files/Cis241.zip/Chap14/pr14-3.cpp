// This program demonstrates a static class member variable.

#include <iostream.h>
#include <iomanip.h>
#include "budget3.h"

void main(void)
{
	float amount;

	cout << "Enter the main office's budget request: ";
	cin >> amount;
	Budget::mainOffice(amount);	
	Budget divisions[4];
    Aux auxOffices[4];
	for (int count = 0; count < 4; count++)
	{
		float bud;

		cout << "Enter the budget request for division ";
		cout << (count + 1) << ": ";
		cin >> bud;
		divisions[count].addBudget(bud);
		cout << "Enter the budget request for division ";
		cout << (count + 1) << "'s\nauxiliary office: ";
		cin >> bud;
		auxOffices[count].addBudget(bud, divisions[count]);

	}
	cout.precision(2);
    cout.setf(ios::showpoint | ios::fixed);
	cout << "Here are the division budget requests:\n";
	for (int count = 0; count < 4; count++)
	{
        cout << "\tDivision " << (count + 1) << "\t\t\t$ ";

		cout << setw(7);
		cout << divisions[count].getDivBudget() << endl;
		cout << "\tAuxilary Office of Division " << (count+1);
		cout << "\t$  ";
		cout << auxOffices[count].getDivBudget() << endl;
	}
	cout << "\tTotal Requests (including main office): $ ";
	cout << divisions[0].getCorpBudget() << endl; 
}
