#ifndef FEETINCHES_H
#define FEETINCHES_H

// A class to hold distances or measurements expressed
// in feet and inches. 

class FeetInches
{
private:
	int feet;
	int inches;
	void simplify(void);
public:
	FeetInches(int f = 0, int i = 0)
		{ feet = f; inches = i; simplify(); }
	void setData(int f, int i)
		{ feet = f; inches = i; simplify(); }
	int getFeet(void)
		{ return feet; }
	int getInches(void)
		{ return inches; }
	FeetInches operator + (const FeetInches &); // Overloaded +
	FeetInches operator - (const FeetInches &); // Overloaded -
};

#endif
