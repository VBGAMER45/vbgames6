#ifndef CUSTOMER_H
#define CUSTOMER_H

#include "account.h"
#include "mystring.h"

class Customer
{
public:
	MyString name;
	MyString address;
	MyString city;
	MyString state;
	MyString zip;
	Account savings;
	Account checking;
	Customer(char *n, char *a, char *c, char *s, char *z)
	   { name = n; address = a; city = c; state = s; zip = z; }
};

#endif
