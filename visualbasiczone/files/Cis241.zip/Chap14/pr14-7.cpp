// This program demonstrates the FeetInches class' overloaded
// + and - operators.

#include <iostream.h>
#include "feetinc2.h"

void main(void)
{
	FeetInches first, second, third;
	int f, i;
	cout << "Enter a distance in feet and inches: ";
	cin >> f >> i;
	first.setData(f, i);
	cout << "Enter another distance in feet and inches: ";
	cin >> f >> i;
	second.setData(f, i);
	third = first + second;
	cout << "first + second = ";
	cout << third.getFeet() << " feet, ";
	cout << third.getInches() << " inches.\n";
	third = first - second;
	cout << "first - second = ";
	cout << third.getFeet() << " feet, ";
	cout << third.getInches() << " inches.\n";
}
