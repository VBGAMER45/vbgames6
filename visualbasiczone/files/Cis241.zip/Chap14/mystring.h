#ifndef MYSTRING_H
#define MYSTRING_H

#include <iostream.h>

// The following declarations are needed
// by some compilers.
class MyString;	// Forward declaration.
ostream &operator<<(ostream &, MyString &);
istream &operator>>(istream &, MyString &);

// MyString class. An abstract data type for handling strings.

class MyString
{
private:
	char *str;
	int len;
	void memError(void);
public:
	MyString(void) { str = NULL; len = 0; }
	MyString(char *);
	MyString(MyString &); // Copy constructor
    ~MyString(void) { if (len != 0) delete [] str; }
	int length(void) { return len; }
	char *getValue(void) { return str; };
	MyString operator+=(MyString &);
	char *operator+=(const char *);
	MyString operator=(MyString &);
	char *operator=(const char *);
	int operator==(MyString &);
	int operator==(const char *);
	int operator!=(MyString &);
	int operator!=(const char *);
	int operator>(MyString &);
	int operator>(const char *);
	int operator<(MyString &);
	int operator<(const char *); 
	int operator>=(MyString &);
	int operator>=(const char*);
	int operator<=(MyString &);
	int operator<=(const char *);
	friend ostream &operator<<(ostream &, MyString &);
	friend istream &operator>>(istream &, MyString &);
};

#endif
