#ifndef FEETINCHES_H
#define FEETINCHES_H

#include <iostream.h>	// Needed to overload << and >>

// The following declarations are needed
// by some compilers.
class FeetInches;	// Forward Declaration
// Function Prototypes for Overloaded Stream Operators
ostream &operator<<(ostream &, FeetInches &);
istream &operator>>(istream &, FeetInches &);


// A class to hold distances or measurements expressed
// in feet and inches. 
class FeetInches
{
private:
	int feet;
	int inches;
	void simplify(void);
public:
	FeetInches(int f = 0, int i = 0)
		{ feet = f; inches = i; simplify(); }
	void setData(int f, int i)
		{ feet = f; inches = i; simplify(); }
	int getFeet(void)
		{ return feet; }
	int getInches(void)
		{ return inches; }
	FeetInches operator + (const FeetInches &); // Overloaded +
	FeetInches operator - (const FeetInches &); // Overloaded -
	FeetInches operator++(void);  // Prefix ++
	FeetInches operator++(int); // Postfix ++
	int operator>(const FeetInches &);
	int operator<(const FeetInches &);
	int operator==(const FeetInches &);
	friend ostream &operator<<(ostream &, FeetInches &);
	friend istream &operator>>(istream &, FeetInches &);
};

#endif
