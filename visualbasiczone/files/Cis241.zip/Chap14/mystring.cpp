#include <string.h>  // For string library functions
#include <stdlib.h>  // For exit() function
#include "mystring.h"

//*************************************************
// Definition of member function memError.        *
// This function is called to terminate a program *
// if a memory allocation fails.                  *
//*************************************************

void MyString::memError(void)
{
	cout << "Error allocating memory.\n";
	exit(0);
}

//*************************************************
// Constructor to initialize the str member       *
// with a string constant.                        *
//*************************************************

MyString::MyString(char *sptr)
{
	len = strlen(sptr);
	str = new char[len + 1];
	if (str == NULL)
		memError();
	strcpy(str, sptr);
}

//*************************************************
// Copy constructor                               *
//*************************************************

MyString::MyString(MyString &right)
{
	str = new char[right.length() + 1];
	if (str == NULL)
		memError();
	strcpy(str, right.getValue());
	len = right.length();
}


//*************************************************
// Overloaded = operator. Called when operand     *
// on the right is another MyString object.       *
// Returns the calling object.                    *
//*************************************************

MyString MyString::operator=(MyString &right)
{
	if (len != 0)
		delete [] str;
	str = new char[right.length() + 1];
	if (str == NULL)
		memError();
	strcpy(str, right.getValue());
	len = right.length();
	return *this;
}

//*************************************************
// Overloaded = operator. Called when operand     *
// on the right is a string.                      *
// Returns the str member of the calling object.  *
//*************************************************

char *MyString::operator=(const char *right)
{
	if (len != 0)
		delete [] str;
	len = strlen(right);
	str = new char[len + 1];
	if (str == NULL)
		memError();
	strcpy(str, right);
	return str;
}

//*************************************************
// Overloaded += operator. Called when operand    *
// on the right is another MyString object.       *
// Concatenates the str member of right to the    *
// str member of the calling object.              *
// Returns the calling object.                    *
//*************************************************

MyString MyString::operator+=(MyString &right)
{
	char *temp = str;

	str = new char[strlen(str) + right.length() + 1];
	if (str == NULL)
		memError();
	strcpy(str, temp);
	strcat(str, right.getValue());
	if (len != 0)
        	delete [] temp;
	len = strlen(str);
	return *this;
}

//*************************************************
// Overloaded += operator. Called when operand    *
// on the right is a string. Concatenates the     *
// str member of right to the str member of       *
// the calling object.                            *
// Returns the str member of the calling object.  *
//*************************************************

char *MyString::operator+=(const char *right)
{
	char *temp = str;

	str = new char[strlen(str) + strlen(right) + 1];
	if (str == NULL)
		memError();
	strcpy(str, temp);
	strcat(str, right);
	if (len != 0)
        	delete [] temp;
	return str;
}

//*****************************************************
// Overloaded == operator.                            *
// Called when the operand on the right is a MyString *
// object. Returns 1 if right.str is the same as str. *
//*****************************************************

int MyString::operator==(MyString &right)
{
	return !strcmp(str, right.getValue());
}

//****************************************************
// Overloaded == operator.                           *
// Called when the operand on the right is a string. *
// Returns 1 if right is the same as str.            *
//****************************************************

int MyString::operator==(const char *right)
{
	return !strcmp(str, right);
}

//******************************************************
// Overloaded != operator.                             *
// Called when the operand on the right is a MyString  *
// object. Returns 1 if right.str is not equal to str. *
//******************************************************

int MyString::operator!=(MyString &right)
{
	return strcmp(str, right.getValue());
}

//****************************************************
// Overloaded != operator.                           *
// Called when the operand on the right is a string. *
// Returns 1 if right is not equal to str.           *
//****************************************************

int MyString::operator!=(const char *right)
{
	return strcmp(str, right);
}

//******************************************************
// Overloaded > operator.                              *
// Called when the operand on the right is a MyString  *
// object. Returns 1 if right.str is greater than str. *
//******************************************************

int MyString::operator>(MyString &right)
{
	if (strcmp(str, right.getValue()) > 0)
		return 1;
	else
		return 0;
}

//****************************************************
// Overloaded > operator.                            *
// Called when the operand on the right is a string. *
// Returns 1 if right is greater than str.           *
//****************************************************

int MyString::operator>(const char *right)
{
	if (strcmp(str, right) > 0)
		return 1;
	else
		return 0;
}

//*****************************************************
// Overloaded < operator.                             *
// Called when the operand on the right is a MyString *
// object. Returns 1 if right.str is less than str.   *
//*****************************************************

int MyString::operator<(MyString &right)
{
	if (strcmp(str, right.getValue()) < 0)
		return 1;
	else
		return 0;
}

//****************************************************
// Overloaded < operator.                            *
// Called when the operand on the right is a string. *
// Returns 1 if right is less than str.              *
//****************************************************

int MyString::operator<(const char *right)
{
	if (strcmp(str, right) < 0)
		return 1;
	else
		return 0;
}

//*****************************************************
// Overloaded >= operator.                            *
// Called when the operand on the right is a MyString *
// object. Returns 1 if right.str is greater than or  *
// equal to str.                                      *
//*****************************************************

int MyString::operator>=(MyString &right)
{
	if (strcmp(str, right.getValue()) >= 0)
		return 1;
	else
		return 0;
}

//******************************************************
// Overloaded >= operator.                             *
// Called when the operand on the right is a string.   *
// Returns 1 if right is greater than or equal to str. *
//******************************************************

int MyString::operator>=(const char *right)
{
	if (strcmp(str, right) >= 0)
		return 1;
	else
		return 0;
}

//*******************************************************
// Overloaded <= operator.                              *
// Called when the operand on the right is a MyString   *
// object. Returns 1 if right.str is less than or equal *
// to str.                                              *
//*******************************************************

int MyString::operator<=(MyString &right)
{
	if (strcmp(str, right.getValue()) <= 0)
		return 1;
	else
		return 0;
}

//****************************************************
// Overloaded <= operator.                           *
// Called when the operand on the right is a string. *
// Returns 1 if right is less than or equal to str.  *
//****************************************************

int MyString::operator<=(const char *right)
{
	if (strcmp(str, right) <= 0)
		return 1;
	else
		return 0;
}

//*************************************************
// Overloaded stream insertion operator (<<).     *
//*************************************************

ostream &operator<<(ostream &strm, MyString &obj)
{
	strm << obj.str;
	return strm;
}

//*************************************************
// Overloaded stream extraction operator (>>).    *
//*************************************************

istream &operator>>(istream &strm, MyString &obj)
{
	strm.getline(obj.str, obj.len);
	strm.ignore();
	return strm;
}
