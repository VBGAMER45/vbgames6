// This program demonstrates the FeetInches class' overloaded
// + and - operators.

#include <iostream.h>
#include "feetinc4.h"

void main(void)
{
	FeetInches first, second, third;
	int f, i;
	cout << "Enter a distance in feet and inches: ";
	cin >> f >> i;
	first.setData(f, i);
	cout << "Enter another distance in feet and inches: ";
	cin >> f >> i;
	second.setData(f, i);
	if (first == second)
		cout << "first is equal to second.\n";
	if (first > second)
		cout << "first is greater than second.\n";
	if (first < second)
		cout << "first is less than second.\n";
}
