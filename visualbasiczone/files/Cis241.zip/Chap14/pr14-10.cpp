// This program demonstrates the << and >> operators, 
// overloaded to work with the FeetInches class.

#include <iostream.h>
#include "feetinc5.h"

void main(void)
{
	FeetInches first, second, third;

	cout << "Enter a distance in feet and inches: ";
	cin >> first;
	cout << "Enter another distance in feet and inches: ";
	cin >> second;
	cout << "The values you entered are:\n";
	cout << first << " and " << second;
}
