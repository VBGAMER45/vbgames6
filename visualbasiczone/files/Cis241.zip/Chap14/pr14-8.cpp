// This program demonstrates the FeetInches class' overloaded 
// prefix and postfix ++ operators.

#include <iostream.h>
#include "feetinc3.h"

void main(void)
{
	FeetInches first, second(1, 5);

	cout << "Demonstrating prefix ++ operator.\n";
	for (int count = 0; count < 12; count++)
	{
		first = ++second;
		cout << "first: " << first.getFeet() << " feet, ";
		cout << first.getInches() << " inches. ";
		cout << "second: " << second.getFeet() << " feet, ";
		cout << second.getInches() << " inches.\n";
	}
	cout << "\nDemonstrating postfix ++ operator.\n";
	for (int count = 0; count < 12; count++)
	{
		first = second++;
		cout << "first: " << first.getFeet() << " feet, ";
		cout << first.getInches() << " inches. ";
		cout << "second: " << second.getFeet() << " feet, ";
		cout << second.getInches() << " inches.\n";
	}
}
