// This program demonstrates a static class member variable.

#include <iostream.h>
#include <iomanip.h>
#include "budget.h" // For Budget class declaration

float Budget::corpBudget = 0;	// Definition of static member of Budget class

void main(void)
{
	Budget divisions[4];

	for (int count = 0; count < 4; count++)
	{
		float bud;

		cout << "Enter the budget request for division ";
		cout << (count + 1) << ": ";
		cin >> bud;
		divisions[count].addBudget(bud);
	}
	cout.precision(2);
    cout.setf(ios::showpoint | ios::fixed);
	cout << "\nHere are the division budget requests:\n";
	for (count = 0; count < 4; count++)
	{
        cout << "\tDivision " << (count + 1) << "\t$ ";
		cout << divisions[count].getDivBudget() << endl;
	}
	cout << "\tTotal Budget Requests:\t$ ";
	cout << divisions[0].getCorpBudget() << endl; 
}
