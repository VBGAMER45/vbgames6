#ifndef BUDGET3_H
#define BUDGET3_H

#include "auxil.h"	// For Aux class declaration

// Budget class declaration
class Budget
{
private:
	static float corpBudget;
	float divBudget;
public:
	Budget(void) { divBudget = 0; }
	void addBudget(float b)
		{ divBudget += b; corpBudget += divBudget; }
	float getDivBudget(void) { return divBudget; }
	float getCorpBudget(void) { return corpBudget; }
	static void mainOffice(float);
	friend void Aux::addBudget(float, Budget &);
};

#endif
