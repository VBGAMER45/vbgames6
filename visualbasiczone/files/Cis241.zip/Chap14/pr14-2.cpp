// This program demonstrates a static class member function.

#include <iostream.h>
#include <iomanip.h>
#include "budget2.h" // For Budget class declaration

void main(void)
{
	float amount;

	cout << "Enter the main office's budget request: ";
	cin >> amount;
	Budget::mainOffice(amount);	
	Budget divisions[4];
	for (int count = 0; count < 4; count++)
	{
		float bud;

		cout << "Enter the budget request for division ";
		cout << (count + 1) << ": ";
		cin >> bud;
		divisions[count].addBudget(bud);
	}
	cout.precision(2);
    cout.setf(ios::showpoint | ios::fixed);
	cout << "\nHere are the division budget requests:\n";
	for (int count = 0; count < 4; count++)
	{
        cout << "\tDivision " << (count + 1) << "\t$ ";
		cout << divisions[count].getDivBudget() << endl;
	}
	cout << "\tTotal Requests (including main office): $ ";
	cout << divisions[0].getCorpBudget() << endl;
}
