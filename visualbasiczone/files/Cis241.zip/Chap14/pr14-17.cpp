#include <iostream.h>
#include "customer.h"

void main(void)
{
	Customer smith("Smith, John", "127 Pine View Drive",
	               "Brassville", "NC", "28801");
	smith.savings.makeDeposit(1000);
	smith.checking.makeDeposit(500);
	smith.savings.calcInterest();
	smith.checking.calcInterest();
	cout.precision(2);
	cout.setf(ios::showpoint | ios::fixed);
	cout << "Customer Name: " << smith.name << endl;
	cout << "Address: " << smith.address << endl;
	cout << "City: " << smith.city << endl;
	cout << "State: " << smith.state << endl;
	cout << "Zip: " << smith.zip << endl;
	cout << "Savings Account Balance: ";
	cout << smith.savings.getBalance() << endl;
	cout << "Interest earned from savings: ";
	cout << smith.savings.getInterest() << endl;
	cout << "Checking Accout Balance: ";
	cout << smith.checking.getBalance() << endl;
	cout << "Interest earned from checking: ";
	cout << smith.checking.getInterest() << endl;
}
