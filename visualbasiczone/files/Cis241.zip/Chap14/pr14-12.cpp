#include <iostream.h>
#include "intarray.h"

void main(void)
{
	IntArray table(10);

	// Store values in the array.
	for (int x = 0; x < 10; x++)
		table[x] = (x * 2);
	// Display the values in the array.
	for (x = 0; x < 10; x++)
		cout << table[x] << " ";
	cout << endl;
	// Use the built-in + operator on array elements.
	for (x = 0; x < 10; x++)
		table[x] = table[x] + 5;
	// Display the values in the array.
	for (x = 0; x < 10; x++)
		cout << table[x] << " ";
	cout << endl;
	// Use the built-in ++ operator on array elements.
	for (x = 0; x < 10; x++)
		table[x]++;
	// Display the values in the array.
	for (x = 0; x < 10; x++)
		cout << table[x] << " ";
	cout << endl;
}
