#include <iostream.h>
void main(void){float shares=220.0;float avgPrice=14.67;cout
<<"There were "<<shares<<" shares sold at $"<<avgPrice<<
" per share.\n";}
