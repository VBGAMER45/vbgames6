// PROGRAM: PAYROLL.CPP
// Written by Herbert Dorfmann
// Also known as "The Dorfmiester"
// Last modification: 3/30/96
// This program calculates company payroll.
// Payroll should be done every Friday no later than
// 12:00 pm. To start the program type PAYROLL and 
// press the enter key.

#include <iostream.h>    // Need the iostream file because
void main(void)          // This is the start of function main.
{                        // This is the opening brace for main.
     float payRate;      // payRate is a float variable.
                         // It holds the hourly pay rate.
     float hours;        // hours is a float variable too.
                         // It holds the hours worked.
     int   empNum;       // empNum is an integer.
                         // It holds the employee number.

     // The remainder of this program is left out.
}
