// This program demonstrates creating a bool data type
// for use with a pre-standard C++ compiler.

#include <iostream.h>

typedef int bool;
const bool true = 1;
const bool false = 0;


void main(void)
{
   bool boolValue;

   boolValue = true;
   cout << boolValue << endl;
   boolValue = false;
   cout << boolValue << endl;
}
