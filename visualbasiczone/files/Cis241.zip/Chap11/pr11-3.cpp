// This program uses a structure to hold someone's first,
// middle, and last name.

#include <iostream.h>
#include <string.h>

struct Name
{
	char first[15];
	char middle[15];
	char last[15];
	char full[45];
};

void main(void)
{
	Name person;

	cout << "Enter your first name: ";
	cin >> person.first;
	cout << "Enter your middle name: ";
	cin >> person.middle;
	cout << "Enter your last name: ";
	cin >> person.last;
	strcpy(person.full, person.first);
	strcat(person.full, " ");
	strcat(person.full, person.middle);
	strcat(person.full, " ");
	strcat(person.full, person.last);
	cout << "\nYour full name is " << person.full << endl;
}
