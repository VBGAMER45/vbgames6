// This program stores, in an array of structures,
// the hours worked by 5 employees, and their hourly
// pay rates. (This is a modification of Program 7-11).

#include <iostream.h>

struct PayInfo
{
	int hours;		// Hours Worked
	float payRate;	// Hourly Pay Rate
};

void main(void)
{
	PayInfo workers[5];  // Array of 5 structures

	cout << "Enter the hours worked by 5 employees and their\n";
	cout << "hourly rates.\n";
	for (int index = 0; index < 5; index++)
	{
		cout << "Hours worked by employee #" << (index + 1);
		cout << ": ";
		cin >> workers[index].hours;
		cout << "Hourly pay rate for employee #";
		cout << (index + 1) << ": ";
		cin >> workers[index].payRate;
	}
	cout << "Here is the gross pay for each employee:\n";
	cout.precision(2);
	cout.setf(ios::fixed | ios::showpoint);
        for (int index = 0; index < 5; index++)
	{
        float gross;
		gross = workers[index].hours * workers[index].payRate;
		cout << "Employee #" << (index + 1);
		cout << ": $" << gross << endl;
	}
}
