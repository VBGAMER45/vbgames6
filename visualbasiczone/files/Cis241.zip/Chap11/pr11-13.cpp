// This program demonstrates an anonymous union.

#include <iostream.h>

void main(void)
{
	union		// Anonymous union
	{
		int hours;
		float sales;
	};

	char payType;
    float payRate, grossPay;

	cout.precision(2);
	cout.setf(ios::showpoint);
	cout << "This program calculates either hourly wages\n";
	cout << "sales commission.\n";
	cout << "Enter H for hourly wages or C for commission: ";
	cin >> payType;
	if (payType == 'H')
	{
		cout << "What is the hourly pay rate? ";
		cin >> payRate;
		cout << "How many hours were worked? ";
		cin >> hours;   // Anonymous union member
		grossPay = hours * payRate;
		cout << "Gross pay: $" << grossPay << endl;
	}
	else if (payType == 'C')
	{
		cout << "What are the total sales for this employee? ";
		cin >> sales;   // Anonymous union member
		grossPay = sales * 0.10;
		cout << "Gross pay: $" << grossPay << endl;
	}
	else
	{
		cout << payType << " is not a valid selection.\n";
	}
}
