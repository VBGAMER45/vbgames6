// This program demonstrates partially initialized
// structure variables

#include <iostream.h>

struct EmpPay
{
	char name[25];
	int empNum;
	float payRate;
	float hours;
	float grossPay;
};

void main(void)
{
	EmpPay employee1 = {"Betty Ross", 141, 18.75};
	EmpPay employee2 = {"Jill Sandburg", 142, 17.50};

	cout.precision(2);
	cout.setf(ios::fixed | ios::showpoint);
	// Calculate pay for employee1
	cout << "name: " << employee1.name << endl;
	cout << "Employee Number: " << employee1.empNum << endl;
	cout << "Enter the hours worked by this employee: ";
	cin >> employee1.hours;
	employee1.grossPay = employee1.hours * employee1.payRate;
	cout << "Gross Pay: " << employee1.grossPay << endl << endl;

	// Calculate pay for employee2
	cout << "name: " << employee2.name << endl;
	cout << "Employee Number: " << employee2.empNum << endl;
	cout << "Enter the hours worked by this employee: ";
	cin >> employee2.hours;
	employee2.grossPay = employee2.hours * employee2.payRate;
	cout << "Gross Pay: " << employee2.grossPay << endl;
}
