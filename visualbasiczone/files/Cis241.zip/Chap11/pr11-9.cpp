// This program uses a function to return a structure. This 
// is a modification of Program 11-2.

#include <iostream.h>
#include <iomanip.h>
#include <math.h>		// For the pow function

// Circle structure declaration
struct Circle
{
	float radius;
	float diameter;
	float area;
};

// Function prototype
Circle getInfo();

// Constant definition for pi
const float pi = 3.14159;

void main(void)
{
	Circle c;

	c = getInfo();
	c.area = pi * pow(c.radius, 2.0);
	cout << "The radius and area of the circle are:\n";
	cout.precision(2);
	cout.setf(ios::fixed | ios::showpoint);
	cout << "Radius: " << c.radius << endl;
	cout << "Area: " << c.area << endl;
}

//**************************************************************
// Definition of function getInfo. This function uses a        *
// local variable, Round, which is a circle structure.         *
// The user enters the diameter of thecircle, which is         *
// stored in Round.diameter. The function then calculates      *
// the radius, which is stored in Round.radius. Round is then  *
// returned from the function.                                 *
//**************************************************************

Circle getInfo()
{
	Circle Round;

	cout << "Enter the diameter of a circle: ";
	cin >> Round.diameter;
	Round.radius = Round.diameter / 2;
	return Round;
}
