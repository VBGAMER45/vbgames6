// This program shows a structure with two nested structure
// members.

#include <iostream.h>

struct Date
{
	int month;
	int day;
	int year;
};

struct Place
{
	char address[50];
	char city[20];
	char state[15];
	char zip[11];
};

struct EmpInfo
{
	char name[50];
	int empNumber;
	Date birthDate;
	Place residence;
};

void main(void)
{
	EmpInfo manager;

	// Ask for the manager's name and employee number
	cout << "Enter the manager's name: ";
	cin.getline(manager.name, 50);
	cout << "Enter the manager's employee number: ";
	cin >> manager.empNumber;

	// Get the manager's birth date
	cout << "Now enter the manager's date-of-birth.\n";
	cout << "month (up to 2 digits): ";
	cin >> manager.birthDate.month;
	cout << "day (up to 2 digits): ";
	cin >> manager.birthDate.day;
	cout << "year (2 digits): ";
	cin >> manager.birthDate.year;
	cin.get();	// Eat the remaining newline character

	// Get the manager's residence information
	cout << "Enter the manager's street address: ";
	cin.getline(manager.residence.address, 50);
	cout << "city: ";
	cin.getline(manager.residence.city, 20);
	cout << "state: ";
	cin.getline(manager.residence.state, 15);
	cout << "zip Code: ";
	cin.getline(manager.residence.zip, 11);

	// Display the information just entered
	cout << "\nHere is the manager's information:\n";
	cout << manager.name << endl;
	cout << "Employee number " << manager.empNumber << endl;
	cout << "Date of Birth: ";
	cout << manager.birthDate.month << "-";
	cout << manager.birthDate.day << "-";
	cout << manager.birthDate.year << endl;
	cout << "Place of residence:\n";
	cout << manager.residence.address << endl;
	cout << manager.residence.city << ", ";
	cout << manager.residence.state << "  ";
	cout << manager.residence.zip << endl;
}
