// This program uses a structure to hold geometric data about
// a circle.

#include <iostream.h>
#include <iomanip.h>
#include <math.h>		// For the pow function

struct Circle
{
	float radius;
	float diameter;
	float area;
};

const float pi = 3.14159;

void main(void)
{
	Circle c;

	cout << "Enter the diameter of a circle: ";
	cin >> c.diameter;
	c.radius = c.diameter / 2;
	c.area = pi
		* pow(c.radius, 2.0);
	cout << "The radius and area of the circle are:\n";
	cout.precision(2);
	cout.setf(ios::fixed | ios::showpoint);
	cout << "radius: " << c.radius << endl;
	cout << "area: " << c.area << endl;
}
