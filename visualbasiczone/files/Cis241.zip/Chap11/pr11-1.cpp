// This program demonstrates the use of structures.

#include <iostream.h>

struct PayRoll
{
	int empNumber;		// employee number
	char name[25];		// employee's name
	float hours;		// hours worked
	float payRate;		// Hourly payRate
	float grossPay;		// Gross Pay
};

void main(void)
{
	PayRoll employee;	// employee is a PayRoll structure

	cout << "Enter the employee's number: ";
	cin >> employee.empNumber;
	cout << "Enter the employee's name: ";
	cin.ignore();	// To skip the remaining '\n' character
	cin.getline(employee.name, 25);
	cout << "How many hours did the employee work? ";
	cin >> employee.hours;
	cout << "What is the employee's hourly payRate? ";
	cin >> employee.payRate;
	employee.grossPay = employee.hours * employee.payRate;
	cout << "Here is the employee's payroll data:\n";
	cout << "name: " << employee.name << endl;
	cout << "Number: " << employee.empNumber << endl;
	cout << "hours worked: " << employee.hours << endl;
	cout << "Hourly payRate: " << employee.payRate << endl;
	cout.precision(2);
	cout.setf(ios::fixed | ios::showpoint);
	cout << "Gross Pay: $" << employee.grossPay << endl;
}
