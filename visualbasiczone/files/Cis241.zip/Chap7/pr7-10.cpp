// This program stores, in an array, the hours worked by 5
// employees who all make the same hourly wage.

#include <iostream.h>

void main(void)
{
	int hours[5];
	float payrate;

	cout << "Enter the hours worked by 5 employees who all\n";
	cout << "earn the same hourly rate.\n";
	for (int index = 0; index < 5; index++)
	{
		cout << "Employee #" << (index + 1) << ": ";
		cin >> hours[index];
	}
	cout << "Enter the hourly pay rate for all the employees: ";
	cin >> payrate;
	cout << "Here is the gross pay for each employee:\n";
	cout.precision(2);
	cout.setf(ios::fixed | ios::showpoint);
	for (index = 0; index < 5; index++)
	{
        float grossPay = hours[index] * payrate;
		cout << "Employee #" << (index + 1);
		cout << ": $" << grossPay << endl;
	}
}

