// This program uses a function to copy a string into an array.

#include <iostream.h>

void stringCopy(char [], char []);	// Function prototype

void main(void)
{
	char first[30], second[30];

	cout << "Enter a string with no more than 29 characters:\n";
	cin.getline(first, 30);
	stringCopy(first, second);
	cout << "The string you entered is:\n" << second << endl;
}

//***********************************************************
// Definition of the stringCopy function.                   *
// This function accepts two character arrays as            *
// arguments. The function assumes the two arrays           *
// contain C-strings. The contents of the second array is   *
// copied to the first array.                               *
//***********************************************************


void stringCopy(char string1[], char string2[])
{
	int index = 0;

	while (string1[index] != '\0')
	{
		string2[index] = string1[index];
		index++;
	}
	string2[index] = '\0';
}
