// This program uses the == operator to compare the string entered
// by the user with the valid stereo part numbers.

#include <iostream>
#include <string>
using namespace std;

void main(void)
{
	const float aprice = 249.0, bprice = 299.0;
	string partNum;

	cout << "The stereo part numbers are:\n";
	cout << "\tBoom Box, part number S147-29A\n";
	cout << "\tShelf Model, part number S147-29B\n";
	cout << "Enter the part number of the stereo you\n";
	cout << "wish to purchase: ";	
	cin >> partNum;
	cout.setf(ios::fixed | ios::showpoint);
	cout.precision(2);
	if (partNum == "S147-29A")
		cout << "The price is $" << aprice << endl;
	else if (partNum == "S147-29B")
		cout << "The price is $" << bprice << endl;
	else
		cout << partNum << " is not a valid part number.\n";
}
