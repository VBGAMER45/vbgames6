// This program demonstrates a function, countChars, that counts
// the number of times a specific character appears in a string.

#include <iostream.h>

// Function prototype
int countChars(char *, char);

void main(void)
{
	char userString[51], letter;

	cout << "Enter a string (up to 50 characters): ";
	cin.getline(userString, 51);
	cout << "Enter a character and I will tell you how many\n";
	cout << "times it appears in the string: ";
	cin >> letter;
	cout << letter << " appears ";
	cout << countChars(userString, letter) << " times.\n";
}

//****************************************************************
// Definition of countChars. The parameter strPtr is a pointer   *
// that points to a string. The parameter Ch is a character that *
// the function searches for in the string. The function returns *
// the number of times the character appears in the string.      *
//****************************************************************

int countChars(char *strPtr, char Ch)
{
	int times = 0;

	while (*strPtr != '\0')
	{
		if (*strPtr == Ch)
			times++;
		strPtr++;
	}
	return times;
}
