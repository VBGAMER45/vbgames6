// This program tests a customer number to determine if it is
// in the proper format.

#include <iostream.h>
#include <ctype.h>

// Function prototype
bool testNum(char []);

void main(void)
{
	char customer[8];

	cout << "Enter a customer number in the form ";
	cout << "LLLNNNN\n";
	cout << "(LLL = letters and NNNN = numbers): ";
	cin.getline(customer, 8);
	if (testNum(customer))
		cout << "That's a valid customer number.\n";
	else
	{
		cout << "That is not the proper format of the ";
		cout << "customer number.\nHere is an example:\n";
		cout << "   ABC1234\n";
	}
}

//**********************************************************
// Definition of function testNum. This function accepts a *
// character array as its argument and tests its contents  *
// for a valid customer number.                            *
//**********************************************************

bool testNum(char custNum[])
{
	// Test the first three characters for alphabetic letters
	for (int count = 0; count < 3; count++)
	{
		if (!isalpha(custNum[count]))
			return false;
	}
	// Test the last 4 characters for numeric digits
	for (count = 3; count < 7; count++)
	{
		if (!isdigit(custNum[count]))
			return false;
	}
	return true;
}
