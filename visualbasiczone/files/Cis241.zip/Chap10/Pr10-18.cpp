// This program demonstrates a string
// object's length member function.

#include <iostream>
#include <string>
using namespace std;

void main(void)
{
	string town;

	cout << "Where do you live? ";
	cin >> town;
	cout << "Your town's name has " << town.length() ;
	cout << " characters\n";
}
