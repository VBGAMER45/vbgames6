// This program uses the function nameSlice to "cut" the last
// name off of a string that contains the user's first and 
// last names.

#include <iostream.h>

void nameSlice(char []);	// Function prototype

void main(void)
{
	char name[41];

	cout << "Enter your first and last names, separated ";
	cout << "by a space:\n";
	cin.getline(name, 41);
	nameSlice(name);
	cout << "Your first name is: " << name << endl;
}

//**************************************************************
// Definition of function nameSlice. This function accepts a   *
// character array as its argument. It scans the array looking *
// for a space. When it finds one, it replaces it with a null  *
// terminator.                                                 *
//**************************************************************

void nameSlice(char userName[])
{
	int count = 0;

	while (userName[count] != ' ' && userName[count] != '\0')
		count++;
	if (userName[count] == ' ')
		userName[count] = '\0';
}
