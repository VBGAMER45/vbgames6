// This program contains string constants

#include <iostream.h>

void main(void)
{
	char again;
	do
	{
		cout << "C++ programming is great fun!" << endl;
		cout << "Do you want to see the message again? ";
		cin >> again;
	} while (again == 'Y' || again == 'y');
}
