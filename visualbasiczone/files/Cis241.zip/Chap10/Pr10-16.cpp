// This program demonstrates the C++ string class.
#include <iostream>
#include <string>
using namespace std;

void main(void)
{
	string greeting;
	string name("William Smith");

	greeting = "Hello ";
	cout << greeting << name << endl;
}
