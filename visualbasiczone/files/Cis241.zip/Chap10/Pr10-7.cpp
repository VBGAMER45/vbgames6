// This program demonstrates the strcmp and atoi functions.

#include <iostream.h>
#include <string.h> // For strcmp
#include <stdlib.h> // For atoi

void main(void)
{
	char input[20];
	int total = 0, count = 0;
	float average;

	cout << "This program will average a series of numbers.\n";
	cout << "Enter the first number or Q to quit: ";
	cin.getline(input, 20);
	while ((strcmp(input, "Q") != 0)&&(strcmp(input, "q") != 0))
	{
		total += atoi(input);  // Keep a running total
		count++;  // Keep track of how many numbers entered
		cout << "Enter the next number or Q to quit: ";
		cin.getline(input, 20);
	}
	if (count != 0)
	{
		average = total / count;
		cout << "average: " << average << endl;
	}
}
