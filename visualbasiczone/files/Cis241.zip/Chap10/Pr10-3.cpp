// This program calculates the area of a circle. It asks the user
// if he or she wishes to continue. A loop that demonstrates the
// toupper function repeats until the user enters 'y', 'Y',
// 'n', or 'N'.

#include <iostream.h>
#include <ctype.h>

void main(void)
{
	const float pi = 3.14159;
	float radius;
	char go;

	cout << "This program calculates the area of a circle.\n";
	cout.precision(2);
	cout.setf(ios::fixed);
	do
	{
		cout << "Enter the circle's radius: ";
		cin >> radius;
		cout << "The area is " << (pi * radius * radius);
		cout << endl;
		do
		{
			cout << "Calculate another? (Y or N) ";
			cin >> go;
		} while (toupper(go) != 'Y' && toupper(go) != 'N');
	} while (toupper(go) == 'Y');
}
