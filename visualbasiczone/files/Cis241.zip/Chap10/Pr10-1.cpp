// This program demonstrates some of the character testing
// macros. 

#include <iostream.h>
#include <ctype.h>

void main(void)
{
	char input;

	cout << "Enter any character: ";
	cin.get(input);
	cout << "The character you entered is: " << input << endl;
	cout << "Its ASCII code is: " << int(input) << endl;
	if (isalpha(input))
		cout << "That's an alphabetic character.\n";
	if (isdigit(input))
		cout << "That's a numeric digit.\n";
	if (islower(input))
		cout << "The letter you entered is lowercase.\n";
	if (isupper(input))
		cout << "The letter you entered is uppercase.\n";
	if (isspace(input))
		cout << "That's a whitespace character.\n";
}
