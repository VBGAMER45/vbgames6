// This program stores the address of a variable in a pointer.
#include <iostream.h>

void main(void)
{
	int x = 25;
	int *ptr;

	ptr = &x;   // Store the address of x in ptr
	cout << "The value in x is " << x << endl;
	cout << "The address of x is " << ptr << endl;
}
