// This program processes the contents of an array. Pointer
// notation is used.

#include <iostream.h>

void main(void)
{
	int numbers[5];

	cout << "Enter five numbers: ";
	for (int count = 0; count < 5; count++)
		cin >> *(numbers + count);
	cout << "Here are the numbers you entered:\n";
	for (count = 0; count < 5; count++)
		cout << *(numbers + count)<< " ";
	cout << endl;
}
