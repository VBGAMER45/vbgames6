// This program shows the donations made to the United Cause
// by the employees of CK Graphics, Inc. It displays
// the donations in order from lowest to highest
// and in the original order they were received.

#include <iostream.h>

// Function prototypes
void arrSelectSort(int *[], int);
void showArray(int [], int);
void showArrPtr(int *[], int);

// numDons is the number of donations
const int numDons = 15;

void main(void)
{
	int donations[numDons] = {5,  100, 5,  25, 10,
				              5,  25,  5,  5,  100,
				              10, 15,  10, 5,  10};
	int *arrPtr[numDons];

	for (int count = 0; count < numDons; count++)
		arrPtr[count] = &donations[count];
	arrSelectSort(arrPtr, numDons);
	cout << "The donations, sorted in ascending order are: \n";
	showArrPtr(arrPtr, numDons);
	cout << "The donations, in their original order are: \n";
	showArray(donations, numDons);
}

//****************************************************************
// Definition of function arrSelectSort.                         *
// This function performs an ascending order selection sort on   *
// array, which is an array of pointers. Each element of array   *
// points to an element of a second array. After the sort,       *
// array will point to the elements of the second array in       *
// ascending order.                                              *
//****************************************************************

void arrSelectSort(int *array[], int elms)
{
	int startScan, minIndex;
	int *minElem;

	for (startScan = 0; startScan < (elms - 1); startScan++)
	{
		minIndex = startScan;
		minElem = array[startScan];
		for(int index = startScan + 1; index < elms; index++)
		{
			if (*(array[index]) < *minElem)
			{
				minElem = array[index];
				minIndex = index;
			}
		}
		array[minIndex] = array[startScan];
		array[startScan] = minElem;
	}
}

//*************************************************************
// Definition of function showArray.                          *
// This function displays the contents of array. elms is the  *
// number of elements.                                        *
//*************************************************************

void showArray(int array[], int elms)
{
	for (int count = 0; count < elms; count++)
		cout << array[count] << " ";
	cout << endl;
}

//**************************************************************
// Definition of function showArrPtr.                          *
// This function displays the contents of the array pointed to *
// by array. elms is the number of elements.                   *
//**************************************************************

void showArrPtr(int *array[], int elms)
{
	for (int count = 0; count < elms; count++)
		cout << *(array[count]) << " ";
	cout << endl;
}
