// This program uses the address of each element in the array.

#include <iostream.h>
#include <iomanip.h>

void main(void)
{
	float coins[5] = {0.05, 0.1, 0.25, 0.5, 1.0};
	float *floatPtr; // Pointer to a float
	int count;       // Array index
	
	cout.precision(2);
	cout << "Here are the values in the coins array:\n";
	for (count = 0; count < 5; count++)
	{
		floatPtr = &coins[count];
		cout << *floatPtr << " ";
	}
	cout << endl;
}

