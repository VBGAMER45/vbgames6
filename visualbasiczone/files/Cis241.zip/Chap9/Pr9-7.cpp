// This program uses subscript notation with a pointer and
// pointer notation with an array name.

#include <iostream.h>
#include <iomanip.h>

void main(void)
{
	float coins[5] = {0.05, 0.1, 0.25, 0.5, 1.0};
	float *floatPtr; // Pointer to a float
	int count;       // Array index
	
	floatPtr = coins; // floatPtr now points to coins array
	cout.precision(2);
	cout << "Here are the values in the coins array:\n";
	for (count = 0; count < 5; count++)
		cout << floatPtr[count] << " ";
	cout << "\nAnd here they are again:\n";
	for (count = 0; count < 5; count++)
		cout << *(coins + count) << " ";
	cout << endl;
}
