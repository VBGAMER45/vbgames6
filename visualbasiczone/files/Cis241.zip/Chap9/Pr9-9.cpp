// This program uses a pointer to display the contents
// of an integer array.

#include <iostream.h>

void main(void)
{
	int set[8] = {5, 10, 15, 20, 25, 30, 35, 40};
	int *nums, index;

	nums = set;
	cout << "The numbers in set are:\n";
	for (index = 0; index < 8; index++)
	{
		cout << *nums << " ";
		nums++;
	}
	cout << "\nThe numbers in set backwards are:\n";
	for (index = 0; index < 8; index++)
	{
		nums--;
		cout << *nums << " ";
	}
}
