// This program demonstrates the use of the indirection
// operator.

#include <iostream.h>

void main(void)
{
	int x = 25;
	int *ptr;

	ptr = &x;   // Store the address of x in ptr
	cout << "Here is the value in x, printed twice:\n";
	cout << x << "  " << *ptr << endl;
	*ptr = 100;
	cout << "Once again, here is the value in x:\n";
	cout << x << "  " << *ptr << endl;
}
