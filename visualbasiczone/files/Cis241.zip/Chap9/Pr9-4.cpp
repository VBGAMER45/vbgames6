// This program demonstrates the use of the indirection
// operator.

#include <iostream.h>

void main(void)
{
	int x = 25, y = 50, z = 75;
	int *ptr;

	cout << "Here are the values of x, y, and z:\n";
	cout << x << "  " << y << "  " << z << endl;
	ptr = &x;  // Store the address of x in ptr
	*ptr *= 2; // Multiply value in x by 2
	ptr = &y;  // Store the address of y in ptr
	*ptr *= 2;  // Multiply value in y by 2
	ptr = &z;   // Store the address of z in ptr
	*ptr *= 2;  // Multiply value in z by 2
	cout << "Once again, here are the values of x, y, and z:\n";
	cout << x << "  " << y << "  " << z << endl;
}
