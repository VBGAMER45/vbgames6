// This program displays the contents of the inventory file.

#include <iostream.h>
#include <fstream.h>

// Declaration of Invtry structure
struct Invtry
{
	char desc[31];
	int qty;
	float price;
};

void main(void)
{
	fstream inventory("invtry.dat", ios::in | ios::binary);
	Invtry record = { "", 0, 0.0 };

	// Now read and display the records
	inventory.read((char *)&record, sizeof(record));
	while (!inventory.eof())
	{
		cout << "Description: ";
		cout << record.desc << endl;
		cout << "Quantity: ";
		cout << record.qty << endl;
		cout << "Price: ";
		cout << record.price << endl << endl;
		inventory.read((char *)&record, sizeof(record));
	}
	inventory.close();
}
