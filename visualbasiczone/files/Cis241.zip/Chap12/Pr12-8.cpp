// This program uses the >> operator to read information from a
// file.

#include <iostream.h>
#include <fstream.h>

void main(void)
{
	fstream dataFile;
	char name[81];

	dataFile.open("demofile.txt", ios::in);
	if (!dataFile)
	{
		cout << "File open error!" << endl;
		return;
	}
	cout << "File opened successfully.\n";
	cout << "Now reading information from the file.\n\n";
	for (int count = 0; count < 4; count++)
	{
		dataFile >> name;
		cout << name << endl;
	}
	dataFile.close();
	cout << "\nDone.\n"; 
}
