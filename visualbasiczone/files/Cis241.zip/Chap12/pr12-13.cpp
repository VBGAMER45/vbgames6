// This program uses the file stream object's getline() member
// function to read a line of information from the file.

#include <iostream.h>
#include <fstream.h>

void main(void)
{
	fstream nameFile;
	char input[81];

	nameFile.open("murphy.txt", ios::in);
	if (!nameFile)
	{
		cout << "File open error!" << endl;
		return;
	}
	nameFile.getline(input,81); // use \n as a delimiter
	while (!nameFile.eof())
	{
		cout << input << endl;
		nameFile.getline(input,81); // use \n as a delimiter
	}
	nameFile.close();
}
