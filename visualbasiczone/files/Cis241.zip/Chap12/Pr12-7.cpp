 //   This program writes three rows of numbers to a file.

#include <iostream.h>
#include <fstream.h>
#include <iomanip.h>

void main(void)
{
    fstream outFile("table.txt", ios::out);
	int nums[3][3] = { 2897, 5, 837,
	                   34, 7, 1623,
	                   390, 3456, 12 };

	// Write the three rows of numbers
	for (int row = 0; row < 3; row++)
	{
		for (int col = 0; col < 3; col++)
		{
     		outFile << setw(4) << nums[row][col] << "  ";
		}
		outFile << endl;
	}
	outFile.close();
}
