// This program uses the file stream object's eof() member
// function to detect the end of the file.


#include <iostream.h>
#include <fstream.h>

void main(void)
{
	fstream nameFile;
	char input[81];
    nameFile.open("murphy.txt", ios::in);
	if (!nameFile)
	{
		cout << "File open error!" << endl;
		return;
	}
	nameFile >> input;
	while (!nameFile.eof())
	{
		cout << input;
		nameFile >> input;
	}
	nameFile.close();
}
