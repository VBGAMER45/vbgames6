// This program sets up a file of blank inventory records.

#include <iostream.h>
#include <fstream.h>

// Declaration of Invtry structure
struct Invtry
{
	char desc[31];
	int qty;
	float price;
};

void main(void)
{
	fstream inventory("invtry.dat", ios::out | ios::binary);
	Invtry record = { "", 0, 0.0 };

	// Now write the blank records
	for (int count = 0; count < 5; count++)
	{
		cout << "Now writing record " << count << endl;
		inventory.write((char *)&record, sizeof(record));
	}
	inventory.close();
}

