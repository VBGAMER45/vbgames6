// This program uses the write and read functions.

#include <iostream.h>
#include <fstream.h>

void main(void)
{
	fstream file("NUMS.DAT", ios::out | ios::binary);
	int buffer[10] = {1,  2,  3,  4,  5, 6,  7,  8,  9,  10};

	cout << "Now writing the data to the file.\n";
	file.write((char *)buffer, sizeof(buffer));
	file.close();
	file.open("NUMS.DAT", ios::in);  // Reopen the file.
	cout << "Now reading the data back into memory.\n";
	file.read((char *)buffer, sizeof(buffer));
	for (int count = 0; count < 10; count++)
		cout << buffer[count] << " ";
	file.close();
}
