// This program allows the user to edit a specific record in
// the inventory file.

#include <iostream.h>
#include <fstream.h>

// Declaration of Invtry structure
struct Invtry
{
	char desc[31];
	int qty;
	float price;
};

void main(void)
{
	fstream inventory("invtry.dat", ios::in | ios::out | ios::binary);
	Invtry record;
	long recNum;

	cout << "Which record do you want to edit?";
	cin >> recNum;
	inventory.seekg(recNum * sizeof(record), ios::beg);
	inventory.read((char *)&record, sizeof(record));
	cout << "Description: ";
	cout << record.desc << endl;
	cout << "Quantity: ";
	cout << record.qty << endl;
	cout << "Price: ";
	cout << record.price << endl;
	cout << "Enter the new data:\n";
	cout << "Description: ";
	cin.ignore();
	cin.getline(record.desc, 31);
	cout << "Quantity: ";
	cin >> record.qty;
	cout << "Price: ";
	cin >> record.price;
	inventory.seekp(recNum * sizeof(record), ios::beg);
	inventory.write((char *)&record, sizeof(record));
	inventory.close();
}
