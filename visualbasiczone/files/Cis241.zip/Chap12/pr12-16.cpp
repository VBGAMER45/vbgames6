// This program demonstrates the put() member function.

#include <iostream.h>
#include <fstream.h>

void main(void)
{
	fstream dataFile("sentence.txt", ios::out);
	char ch;

	cout << "Type a sentence and be sure to end it with a ";
	cout << "period.\n";
	while (1)
	{
		cin.get(ch);
		dataFile.put(ch);
		if (ch == '.')
			break;
	}
	dataFile.close();
}

