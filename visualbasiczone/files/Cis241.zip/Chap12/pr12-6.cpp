// This program uses the precision member function of a
// file stream object to format file output.

#include <iostream.h>
#include <fstream.h>

void main(void)
{
	fstream dataFile;
	float num = 123.456;

	dataFile.open("numfile.txt", ios::out);
	if (!dataFile)
	{
		cout << "File open error!" << endl;
		return;
	}
	dataFile.setf(ios::fixed);
	dataFile << num << endl;
	dataFile.precision(3);
	dataFile << num << endl;
	dataFile.precision(2);
	dataFile << num << endl;
	dataFile.precision(1);
	dataFile << num << endl;
}
