// This program demonstrates the tellg function.

#include <iostream.h>
#include <fstream.h>
#include <ctype.h>	// For toupper

void main(void)
{
     fstream file("letters.txt", ios::in);
     long offset;
     char ch, again;

     do
     {
		cout << "Currently at position " << file.tellg() << endl;
		cout << "Enter an offset from the beginning of the file: ";
		cin >> offset;
		file.seekg(offset, ios::beg);
		file.get(ch);
		cout << "Character read: " << ch << endl;
		cout << "Do it again? ";
		cin >> again;
     } while (toupper(again) == 'Y');
     file.close();
}
