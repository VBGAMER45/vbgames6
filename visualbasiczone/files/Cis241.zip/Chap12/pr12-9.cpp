// This program uses the file stream object's eof() member
// function to detect the end of the file.

#include <iostream.h>
#include <fstream.h>

void main(void)
{
	fstream dataFile;
	char name[81];

	dataFile.open("demofile.txt", ios::in);
	if (!dataFile)
	{
		cout << "File open error!" << endl;
		return;
	}
	cout << "File opened successfully.\n";
	cout << "Now reading information from the file.\n\n";
	dataFile >> name;			// Read first name from the file
	while (!dataFile.eof())		// Test for end of file
	{		
		cout << name << endl;
		dataFile >> name;
	}
	dataFile.close();
	cout << "\nDone.\n";
}
