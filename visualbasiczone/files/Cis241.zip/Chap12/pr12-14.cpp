// This file demonstrates the getline function with a user-
// specified delimiter.

#include <iostream.h>
#include <fstream.h>

void main(void)
{
	fstream dataFile("names2.txt", ios::in);
	char input[81];

	dataFile.getline(input, 81, '$');
	while (!dataFile.eof())
	{
		cout << input << endl;
		dataFile.getline(input, 81, '$');
	}
	dataFile.close();
}
