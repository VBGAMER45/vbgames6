// This program asks the user for a file name. The file is 
// opened and its contents are displayed on the screen.

#include <iostream.h>
#include <fstream.h>

void main(void)
{
	fstream file;
	char ch, fileName[51];

	cout << "Enter a file name: ";
	cin >> fileName;
	
	file.open(fileName, ios::in);
	if (!file)
	{
		cout << fileName << " could not be opened.\n";
		return;
	}
	file.get(ch);			// Get a character
	while (!file.eof())
	{
		cout << ch;
		file.get(ch);		// Get another character
	}
	file.close();
}
