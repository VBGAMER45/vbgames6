// This program uses the file stream object's eof() member
// function to detect the end of the file.

#include <iostream.h>
#include <fstream.h>

// Function prototypes

bool openFileIn(fstream &, char [51]);
void showContents(fstream &);

void main(void)
{
	fstream dataFile;

	if (!openFileIn(dataFile,"demofile.txt"))
	{
		cout << "File open error!" << endl;
		return;
	}
	cout << "File opened successfully.\n";
	cout << "Now reading information from the file.\n\n";
	showContents(dataFile);
	dataFile.close();
	cout << "\nDone.\n";
}

//***********************************************************
// Definition of function openFileIn. Accepts a reference   *
// to an fstream object as its argument. The file is opened *
// for input. The function returns true upon success, false *
// upon failure.                                            *
//***********************************************************

bool openFileIn(fstream &file, char name[51])
{
	bool status;

	file.open(name, ios::in);
	if (file.fail())
		status = false;
	else
		status = true;
	return status;
}

//***********************************************************
// Definition of function showContents. Accepts an fstream  *
// reference as its argument. Uses a loop to read each name *
// from the file and displays it on the screen.             *
//***********************************************************

void showContents(fstream &file)
				  
{
	char name[81];

	file >> name;
	while (!file.eof())
	{
		cout << name << endl;
		file >> name;
	}
}
