// This program demonstrates the opening of a file at the
// time the file stream object is declared.

#include <iostream.h>
#include <fstream.h>

void main(void)
{
	fstream dataFile("names.dat", ios::in | ios::out);
	cout << "The file names.dat was opened.\n";
}
