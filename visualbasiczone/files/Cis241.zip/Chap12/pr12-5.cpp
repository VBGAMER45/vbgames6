// This program writes information to a file, closes the file,
// then reopens it and appends more information.
#include <iostream.h>
#include <fstream.h>

void main(void)
{
	fstream dataFile;

	dataFile.open("demofile.txt", ios::out);
	dataFile << "Jones\n";
	dataFile << "Smith\n";
	dataFile << "Willis\n";
	dataFile << "Davis\n";
	dataFile.close();
}
