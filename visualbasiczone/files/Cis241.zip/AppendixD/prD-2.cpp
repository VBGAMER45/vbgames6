// This program demonstrates an enumerated type.

#include <iostream.h>

// Declare the enumerated type
enum Roster { Tom, Sharon, Bill, Teresa, John };

// Array to hold student grades
float grade[5] = { 89, 100, 97, 84, 89 };

void main(void)
{
	Roster student;

	cout << "Here are the student grades:\n";
	for (student = Tom; student <= John; student = Roster(student + 1))
		cout << grade[student] << endl;
}

