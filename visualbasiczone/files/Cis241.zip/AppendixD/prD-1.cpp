// This program demonstrates an enumerated type.

#include <iostream.h>

// Declare the enumerated type
enum Roster { Tom, Sharon, Bill, Teresa, John };

float grade[5];	// Array to hold student grades

void main(void)
{
	float score;
	int who;

	cout << "Enter a student's test score: ";
	cin >> score;
	cout << "Which student made that score?\n";
	cout << "0 = Tom\n";
	cout << "1 = Sharon\n";
	cout << "2 = Bill\n";
	cout << "3 = Teresa\n";
	cout << "4 = John\n";
	cin >> who;

	switch (who)
	{
	case Tom	:	grade[Tom] = score;
					break;
	case Sharon	:	grade[Sharon] = score;
					break;
	case Bill	:	grade[Bill] = score;
					break;
	case Teresa	:	grade[Teresa] = score;
					break;
	case John	:	grade[John] = score;
					break;
	default		:	cout << "Invalid selection\n";
	}
}

