#ifndef SIMPLEVECTOR_H
#define SIMPLEVECTOR_H

#include <iostream.h>
#include <stdlib.h>

template <class T>
class SimpleVector
{
private:
	T *aptr;
	int arraySize;
	void memError(void);					// Handles memory allocation errors.
	void subError(void);					// Handles subscripts out of range.
public:
	SimpleVector()							// Default constructor
   	{ aptr = 0; arraySize = 0;}
	SimpleVector(int);  					// Constructor
	SimpleVector(const SimpleVector &); 	// Copy constructor
	~SimpleVector(void);					// Destructor
	int size(void)
		{ return arraySize; }
	T &operator[](const int &); 			// Overloaded [] operator
};

//***********************************************************
// Constructor for SimpleVector class. Sets the size of the *
// array and allocates memory for it.                       *
//***********************************************************

template <class T>
SimpleVector<T>::SimpleVector(int s)
{
	arraySize = s;
	aptr = new T [s];
	if (aptr == 0)
		memError();
	for (int count = 0; count < arraySize; count++)
		*(aptr + count) = 0;
}

//*******************************************
// Copy Constructor for SimpleVector class. *
//*******************************************

template <class T>
SimpleVector<T>::SimpleVector(const SimpleVector &obj)
{
	arraySize = obj.arraySize;
	aptr = new T [arraySize];
	if (aptr == 0)
		memError();
	for(int count = 0; count < arraySize; count++)
		*(aptr + count) = *(obj.aptr + count);
}

//**************************************
// Destructor for SimpleVector class.  *
//**************************************

template <class T>
SimpleVector<T>::~SimpleVector(void)
{
	if (arraySize > 0)
		delete [] aptr;
}

//*******************************************************
// memError function. Displays an error message and     *
// terminates the program when memory allocation fails. *
//*******************************************************

template <class T>
void SimpleVector<T>::memError(void)
{
	cout << "ERROR:Cannot allocate memory.\n";
	exit(0);
}

//***********************************************************
// subError function. Displays an error message and         *
// terminates the program when a subscript is out of range. *
//***********************************************************

template <class T>
void SimpleVector<T>::subError(void)
{
	cout << "ERROR: Subscript out of range.\n";
	exit(0);
}

//*******************************************************
// Overloaded [] operator. The argument is a subscript. *
// This function returns a reference to the element     *
// in the array indexed by the subscript.               *
//*******************************************************

template <class T>
T &SimpleVector<T>::operator[](const int &sub)
{
	if (sub < 0 || sub > arraySize)
		subError();
	return aptr[sub];
}

#endif
