// This program provides a simple demonstration of the
// vector STL template.

#include <iostream.h>
#include <vector>  // Include the vector header
using namespace std;

void main(void)
{
   int x;
   vector<int> vect;    // Declare a vector object

   // Use the size member function to get
   // the number of elements in the vector.
   cout << "vect starts with " << vect.size()
        << " elements.\n";
   // Use push_back to push values into the vector.
   for (x = 0; x < 10; x++)
		vect.push_back(x);
   cout << "Now vect has " << vect.size()
        << " elements. Here they are:\n";
   // Use the [] operator.
   for (x = 0; x < vect.size(); x++)
		cout << vect[x] << " ";
   cout << endl;
   // Use the pop_back member function.
   cout << "Popping the values out of vect...\n";
   for (x = 0; x < 10; x++)
   		vect.pop_back();
   cout << "Now vect has " << vect.size() << " elements.\n";
}
