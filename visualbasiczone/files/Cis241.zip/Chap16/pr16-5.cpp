// This program uses a function template.

#include <iostream.h>

// Template definition for Square function.
template <class T>
T square(T number)
{
	return number * number;
}

void main(void)
{
	int userInt;
	float userFloat;

	cout.precision(5);
	cout << "Enter an integer and a floating-point value: ";
	cin >> userInt >> userFloat;
	cout << "Here are their squares: ";
	cout << square(userInt) << " and " << square(userFloat) << endl;
}
