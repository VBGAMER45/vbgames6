// This program demonstrates the SearchableVector template.

#include <iostream.h>
#include "searchvect.h"

void main(void)
{
	SearchableVector<int> intTable(10);
	SearchableVector<float> floatTable(10);
	int x, result;

	// Store values in the arrays.
	for (x = 0; x < 10; x++)
	{
		intTable[x] = (x * 2);
		floatTable[x] = (x * 2.14);
	}

	// Display the values in the arrays.
	cout << "These values are in intTable:\n";
	for (x = 0; x < 10; x++)
		cout << intTable[x] << " ";
	cout << endl;
	cout << "These values are in floatTable:\n";
	for (x = 0; x < 10; x++)
		cout << floatTable[x] << " ";
	cout << endl;
	
	// Now search for values in the arrays.
	cout << "Searching for 6 in intTable.\n";
	result = intTable.findItem(6);
	if (result == -1)
		cout << "6 was not found in intTable.\n";
	else
		cout << "6 was found at subscript " << result << endl;

	cout << "Searching for 12.84 in floatTable.\n";
	result = floatTable.findItem(12.84);
	if (result == -1)
		cout << "12.84 was not found in floatTable.\n";
	else
		cout << "12.84 was found at subscript " << result << endl;
}
