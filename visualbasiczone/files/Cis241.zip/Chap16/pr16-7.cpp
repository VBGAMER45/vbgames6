// This program demonstrates the use of the swap function template
// with two type parameters

#include <iostream.h>

template <class T1, class T2>
void swap(T1 &var1, T2 &var2)
{
	T1 temp;

	temp = var1;
	var1 = (T1)var2;
	var2 = (T2)temp;
}

void main(void)
{
	char character;
	int intNum;
	float floatNum;

	// Get and swap a char and an int
	cout << "Enter a character and an int: ";
	cin >> character >> intNum;
	swap(character, intNum);
	cout << character << " " << intNum << endl;

	// Get and a float and an int
	cout << "Enter a float and an int: ";
	cin >> floatNum >> intNum;
	swap(floatNum, intNum);
	cout << floatNum << " " << intNum << endl;
}
