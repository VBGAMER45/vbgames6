// This program demonstrates the use of the swap function template

#include <iostream.h>

template <class T>
void swap(T &var1, T &var2)
{
	T temp;

	temp = var1;
	var1 = var2;
	var2 = temp;
}

void main(void)
{
	char firstChar, secondChar;
	int firstInt, secondInt;
	float firstFloat, secondFloat;

	// Get and swap two chars
	cout << "Enter two characters: ";
	cin >> firstChar >> secondChar;
	swap(firstChar, secondChar);
	cout << firstChar << " " << secondChar << endl;

	// Get and swap two ints
	cout << "Enter two integers: ";
	cin >> firstInt >> secondInt;
	swap(firstInt, secondInt);
	cout << firstInt << " " << secondInt << endl;

	// Get and swap two floats
	cout << "Enter two floating-point numbers: ";
	cin >> firstFloat >> secondFloat;
	swap(firstFloat, secondFloat);
	cout << firstFloat << " " << secondFloat << endl;
}
