// This program provides a simple demonstration of an
// iterator.

#include <iostream.h>
#include <vector>  // Include the vector header
using namespace std;

void main(void)
{
	int x;
	vector<int> vect;    // Declare a vector object
   	vector<int>::iterator iter; // Declare an iterator

   	// Use push_back to push values into the vector.
	for (x = 0; x < 10; x++)
		vect.push_back(x);
	// Step the iterator through the vector,
   	// and use it to display the vector's contents.
   	cout << "Here are the values in vect: ";
	for (iter = vect.begin(); iter < vect.end(); iter++)
   	{
		cout << *iter << " ";
   	}
   	cout << "\nand here they are backwards: ";
	for (iter = vect.end() - 1; iter >= vect.begin(); iter--)
   	{
		cout << *iter << " ";
   	}
}
