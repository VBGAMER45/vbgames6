// This program demonstrates the SimpleVector template.

#include <iostream.h>
#include "simplevector.h"

void main(void)
{
	SimpleVector<int> intTable(10);
	SimpleVector<float> floatTable(10);
	int x;

	// Store values in the arrays.
	for (x = 0; x < 10; x++)
	{
		intTable[x] = (x * 2);
		floatTable[x] = (x * 2.14);
	}

	// Display the values in the arrays.
	cout << "These values are in intTable:\n";
	for (x = 0; x < 10; x++)
		cout << intTable[x] << " ";
	cout << endl;
	cout << "These values are in floatTable:\n";
	for (x = 0; x < 10; x++)
		cout << floatTable[x] << " ";
	cout << endl;
	
	// Use the built-in + operator on array elements.
	for (x = 0; x < 10; x++)
	{
		intTable[x] = intTable[x] + 5;
		floatTable[x] = floatTable[x] + 1.5;
	}
	
	// Display the values in the array.
	cout << "These values are in intTable:\n";
	for (x = 0; x < 10; x++)
		cout << intTable[x] << " ";
	cout << endl;
	cout << "These values are in floatTable:\n";
	for (x = 0; x < 10; x++)
		cout << floatTable[x] << " ";
	cout << endl;
	
	// Use the built-in ++ operator on array elements.
	for (x = 0; x < 10; x++)
	{
		intTable[x]++;
		floatTable[x]++;
	}
	
	// Display the values in the array.
	cout << "These values are in intTable:\n";
	for (x = 0; x < 10; x++)
		cout << intTable[x] << " ";
	cout << endl;
	cout << "These values are in floatTable:\n";
	for (x = 0; x < 10; x++)
		cout << floatTable[x] << " ";
	cout << endl;
}
