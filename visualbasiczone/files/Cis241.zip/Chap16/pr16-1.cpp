#include <iostream.h>

// Function prototype
float divide(int, int);

void main(void)
{
	int num1, num2;
	float quotient;

	cout << "Enter two numbers: ";
	cin >> num1 >> num2;

	try
	{
		quotient = divide(num1, num2);
		cout << "The quotient is " << quotient << endl;
	}
	catch (char *exceptionString)
	{
		cout << exceptionString;
	}

	cout << "End of the program.\n";
}

float divide(int numerator, int denominator)
{
	if (denominator == 0)
		throw "ERROR: Cannot divide by zero.\n";
	else
			return float(numerator) / denominator;
}
