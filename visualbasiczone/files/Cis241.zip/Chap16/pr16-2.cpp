#include <iostream.h>
#include "intrange.h"

void main(void)
{
	IntRange range(5, 10);
	int userValue;

	cout << "Enter a value in the range 5 - 10: ";
	try
	{
		userValue = range.getInput();
		cout << "You entered " << userValue << endl;
	}
	catch (IntRange::OutOfRange)
	{
		cout << "That value is out of range.\n";
	}
	cout << "End of the program.\n";
}
