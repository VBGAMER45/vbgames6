#ifndef SALE_H
#define SALE_H

// Sale class declaration
class Sale
{
private:
	float taxRate;
	float total;
public:
	Sale(float rate) { taxRate = rate; }
	void calcSale(float cost)
		{ total = cost + (cost * taxRate); }
	float getTotal(void) { return total; }
};

#endif
