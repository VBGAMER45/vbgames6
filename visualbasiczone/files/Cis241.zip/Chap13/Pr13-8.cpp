// This program demonstrates a destructor.

#include <iostream.h>

class Demo
{
public:
	Demo(void); // Constructor
	~Demo(void); // Destructor
};

Demo::Demo(void)
{
	cout << "Welcome to the constructor!\n";
}

Demo::~Demo(void)
{
	cout << "The destructor is now running.\n";
}

void main(void)
{
	Demo demoObj;	// Declare a Demo object;

	cout << "This program demonstrates an object\n";
	cout << "with a constructor and destructor.\n";
}
