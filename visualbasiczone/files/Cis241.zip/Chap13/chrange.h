#ifndef CHRANGE_H
#define CHRANGE_H

class CharRange
{
private:
	char input;		// User Input
	char lower;		// Lowest valid character
	char upper;		// Highest valid character
	char *errMsg;	// Message to be displayed upon error
public:
	CharRange(char, char, const char *);
	char getChar(void);
};

#endif