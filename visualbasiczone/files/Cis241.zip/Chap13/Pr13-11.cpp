#include <iostream.h>
#include "sale2.h"

void main(void)
{
	Sale cashier1;			// Use default sales tax rate
	Sale cashier2(0.06);	// Use 6% sales tax rate
	float amnt;

	cout.precision(2);
	cout.setf(ios::fixed | ios::showpoint);	
	cout << "Enter the amount of the sale: ";
	cin >> amnt;
	cashier1.calcSale(amnt);
	cashier2.calcSale(amnt);
	cout << "With a 0.05 sales tax rate, the total\n";
	cout << "of the sale is $";
	cout << cashier1.getTotal() << endl;
	cout << "With a 0.06 sales tax rate, the total\n";
	cout << "of the sale is $";
	cout << cashier2.getTotal() << endl;
}
