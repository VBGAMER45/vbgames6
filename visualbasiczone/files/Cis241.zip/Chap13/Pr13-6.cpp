// This program demonstrates a constructor.

#include <iostream.h>

class Demo
{
public:
	Demo(void); // Constructor
};

Demo::Demo(void)
{
	cout << "Welcome to the constructor!\n";
}

void main(void)
{
	cout << "This is displayed before the object\n";
	cout << "is created.\n\n";
	Demo demoObj;
	cout << "\nThis is displayed after the object.\n";
	cout << "is created.\n";
}

