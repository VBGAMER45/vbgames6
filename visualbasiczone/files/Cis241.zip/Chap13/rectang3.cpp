#include "rectang3.h"

//************************************************************
// setData copies the argument w to private member width and *
// l to private member length.                               *
//************************************************************

void Rectangle::setData(float w, float l)
{
	width = w;
	length = l;
	calcArea();
}
