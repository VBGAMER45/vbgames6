#ifndef RECTANGLE_H
#define RECTANGLE_H

// Rectangle class declaration.

class Rectangle
{
	private:
		float width;
		float length;
		float area;
		void calcArea(void) { area = width * length; }
	public:
		void setData(float, float); // Prototype
		float getWidth(void) { return width; }
		float getLength(void) { return length; }
		float getArea(void) { return area; }
};

#endif
