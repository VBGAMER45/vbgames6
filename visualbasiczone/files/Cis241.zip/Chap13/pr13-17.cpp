// This program demonstrates the IntList's 
// binary search capability.

#include <iostream.h>
#include <stdlib.h>		// For rand
#include "intlist2.h"

void main(void)
{
	IntList numbers;
	int val;

	// Store random numbers in the list. 
	for (int x = 0; x < 20; x++)
	{
		if (!numbers.set(x, rand()))
			cout << "Error storing a value.\n";
	}
	cout << endl;
	// Display the numbers
	for (int x = 0; x < 20; x++)
	{
		if (numbers.get(x, val))
			cout << val << endl;
	}
	cout << "Press ENTER to continue...";
	cin.get();
	// Sort the numbers using selectionSort
	numbers.selectionSort();
	// Display the numbers
	cout << "Here are the sorted values:\n";
	for (int x = 0; x < 20; x++)
	{
		if (numbers.get(x, val))
			cout << val << endl;
	}
	cout << endl;
}
