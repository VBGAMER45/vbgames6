#include "account.h"

bool Account::withdraw(float amount)
{
	bool status;

	if (balance < amount)
		status = false; // Not enough in the account
	else
	{
		balance -= amount;
		transactions++;
		status = true;
	}
	return status;
}
