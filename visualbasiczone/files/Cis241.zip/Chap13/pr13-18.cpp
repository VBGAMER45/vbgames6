// This program demonstrates the IntList's 
// binary search capability.

#include <iostream.h>
#include <stdlib.h>		// For rand
#include "intlist2.h"

void main(void)
{
	IntList numbers;
	int val, searchResult;

	// Store random numbers in the list. 
	for (int x = 0; x < 20; x++)
	{
		if (!numbers.set(x, rand()))
			cout << "Error storing a value.\n";
	}
	cout << endl;
	// Display the numbers
	for (x = 0; x < 20; x++)
	{
		if (numbers.get(x, val))
			cout << val << endl;
	}
	cout << "Enter one of the numbers shown above: ";
	cin >> val;
	cout << "Searching...\n";
	searchResult = numbers.binarySearch(val);
	if (searchResult == -1)
		cout << "That value was not found in the array.\n";
	else
	{
		cout << "After the array was sorted, that value\n";
		cout << "is found at subscript " << searchResult << endl;
	}
}
