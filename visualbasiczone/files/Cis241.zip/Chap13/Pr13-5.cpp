// This program demonstrates a constructor.

#include <iostream.h>

class Demo
{
public:
	Demo(void); // Constructor
};

Demo::Demo(void)
{
	cout << "Welcome to the constructor!\n";
}

void main(void)
{
	Demo demoObj;	// Declare a Demo object;

	cout << "This program demonstrates an object\n";
	cout << "with a constructor.\n";
}
