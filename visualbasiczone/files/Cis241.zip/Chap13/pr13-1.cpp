// This program demonstrates a simple class

#include <iostream.h>

// Rectangle class declaration.
class Rectangle
{
	private:
		float width;
		float length;
		float area;
	public:
		void setData(float, float);
		void calcArea(void);
		float getWidth(void);
		float getLength(void);
		float getArea(void);
};

//************************************************************
// setData copies the argument w to private member width and *
// l to private member length.                               *
//************************************************************

void Rectangle::setData(float w, float l)
{
	width = w;
	length = l;
}

//************************************************************
// calcArea multiplies the private members width and length. *
// The result is stored in the private member area.          *
//************************************************************

void Rectangle::calcArea(void)
{
	area = width * length;
}

//************************************************************
// getWidth returns the value in the private member width.   *
//************************************************************

float Rectangle::getWidth(void)
{
	return width;
}

//************************************************************
// getLength returns the value in the private member length. *
//************************************************************

float Rectangle::getLength(void)
{
	return length;
}

//************************************************************
// getarea returns the value in the private member area.     *
//************************************************************

float Rectangle::getArea(void)
{
	return area;
}

//************************************************************
// Function main                                             *
//************************************************************

void main(void)
{
	Rectangle box;
	float wide, boxLong;

	cout << "This program will calculate the area of a\n";
	cout << "rectangle. What is the width? ";
	cin >> wide;
	cout << "What is the length? ";
	cin >> boxLong;
	box.setData(wide, boxLong);
	box.calcArea();
	cout << "Here is the rectangle's data:\n";
	cout << "Width: " << box.getWidth() << endl;
	cout << "Length: " << box.getLength() << endl;
	cout << "Area: " << box.getArea() << endl;
}
