#ifndef INVITEM2_H
#define INVITEM2_H

#include <string.h>	// Needed for strcpy function call.

// InvItem class declaration
class InvItem
{
private:
	char *desc;
	int units;
public:
	InvItem(int size = 51) { desc = new char[size]; }
	InvItem(char *d) { desc = new char[strlen(d)+1]; 
	                   strcpy(desc, d); }
	~InvItem(void) { delete [] desc; }
	void setInfo(char *d, int u) { strcpy(desc, d); units = u;}
	void setUnits (int u) { units = u; }
	char *getDesc(void) { return desc; }
	int getUnits(void) { return units; }
};

#endif
