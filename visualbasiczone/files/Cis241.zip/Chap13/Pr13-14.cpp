// This program demonstrates an array of objects.

#include <iostream.h>
#include <iomanip.h>
#include "invitem3.h"

void main(void)
{
	InvItem inventory[5] = { InvItem("Adjustable Wrench", 10),
				             InvItem("Screwdriver", 20),
				             InvItem("Pliers", 35),
				             InvItem("Ratchet", 10),
				             InvItem("Socket Wrench", 7)
							};
	cout << "Inventory Item\t\tUnits On Hand\n";
	cout << "---------------------------------\n";
	for (int index = 0; index < 5; index++)
	{
		cout << setw(17) << inventory[index].getDesc();
		cout << setw(12) << inventory[index].getUnits()
		     << endl;
	   
	}
}
