#ifndef INVITEM3_H
#define INVITEM3_H

#include <string.h> // Needed for strcpy function call.


// InvItem class declaration
class InvItem
{
private:
	char *desc;
	int units;
public:
	InvItem(int size = 51) { desc = new char[size]; }
	InvItem(char *d) { desc = new char [strlen(d)+1];
					   strcpy(desc, d); }
	InvItem(char *d, int u) { desc = new char [strlen(d)+1];
				              strcpy(desc, d);
				              units = u; }
	~InvItem(void) { delete [] desc; }
	void setInfo(char *dscr, int un) { strcpy(desc, dscr); units = un;}
	void setUnits (int u) { units = u; }
	char *getDesc(void) { return desc; }
	int getUnits(void) { return units; }

};

#endif
