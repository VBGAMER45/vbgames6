// This program demonstrates a class with a contructor.

#include <iostream.h>
#include <string.h>

class InvItem
{
	private:
		char *desc;
		int units;
	public:
		InvItem(void) { desc = new char [51]; }
		void setInfo(char *dscr, int un) 
			{ strcpy(desc, dscr);
		      units = un;}
		char *getDesc(void) { return desc; }
		int getUnits(void) { return units; }
};

void main(void)
{
	InvItem stock;

	stock.setInfo("Wrench", 20);
	cout << "Item Description: " << stock.getDesc() << endl;
	cout << "Units on hand: " << stock.getUnits() << endl;
}
