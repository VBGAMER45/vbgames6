// This program must be linked with
// account.cpp and chrange.cpp

#include <iostream.h>
#include <ctype.h>
#include "account.h"
#include "chrange.h"

// Function prototypes
void displayMenu(void);
void makeDeposit(Account &);
void withdraw(Account &);

// Error message for erroneous input
const char *Msg = "Please enter a - g only: ";

void main(void)
{
     Account savings;				 // savings account object
	 CharRange input('A', 'G', Msg); // Input validation object
	 char choice;					 // User input

     cout.precision(2);
     cout.setf(ios::fixed | ios::showpoint);
	 do
     {
	   displayMenu();
	   choice = input.getChar();
	   switch(choice)
	   {
		case 'A': cout << "The current balance is $";
	 		      cout << savings.getBalance() << endl;
				  break;
		case 'B': cout << "There have been ";
				  cout << savings.getTransactions()
				       << " transactions.\n";
				  break;
		case 'C': cout << "Interest earned for this period: $";
				  cout << savings.getInterest() << endl;
				  break;
		case 'D': makeDeposit(savings);
				  break;
		case 'E': withdraw(savings);
				  break;
		case 'F': savings.calcInterest();
				  cout << "Interest added.\n";
	   }
	 } while (choice != 'G');
}

//****************************************************
// Definition of function displayMenu. This function *
// displays the user's menu on the screen.           *
//****************************************************

void displayMenu(void)
{
	  cout << "\n\na) Display the account balance\n";
	  cout << "b) Display the number of transactions\n";
	  cout << "c) Display interest earned for this period\n";
	  cout << "d) Make a deposit\n";
	  cout << "e) Make a withdrawal\n";
	  cout << "f) Add interest for this period\n";
	  cout << "g) Exit the program\n\n";
	  cout << "Enter your choice: ";
}

//*************************************************************
// Definition of function makeDeposit. This function accepts  *
// a reference to an Account object. The user is prompted for *
// the dollar amount of the deposit, and the makeDeposit      *
// member of the Account object is then called.               *
//*************************************************************

void makeDeposit(Account &acnt)
{
	float dollars;

	cout << "Enter the amount of the deposit: ";
	cin >> dollars;
	cin.ignore();
	acnt.makeDeposit(dollars);
}

//*************************************************************
// Definition of function withdraw. This function accepts     *
// a reference to an Account object. The user is prompted for *
// the dollar amount of the withdrawal, and the withdraw      *
// member of the Account object is then called.               *
//*************************************************************

void withdraw(Account &acnt)
{
	float dollars;

	cout << "Enter the amount of the withdrawal: ";
	cin >> dollars;
	cin.ignore();
	if (!acnt.withdraw(dollars))
		cout << "ERROR: Withdrawal amount too large.\n\n";
}

