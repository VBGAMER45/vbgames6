#include "rectang2.h"

//************************************************************
// SetData copies the argument w to private member width and *
// l to private member length.                               *
//************************************************************

void Rectangle::setData(float w, float l)
{
	width = w;
	length = l;
	calcArea();
}

//************************************************************
// calcArea multiplies the private members width and length. *
// The result is stored in the private member area.          *
//************************************************************

void Rectangle::calcArea(void)
{
	area = width * length;
}

//************************************************************
// getWidth returns the value in the private member width.   *
//************************************************************

float Rectangle::getWidth(void)
{
	return width;
}

//************************************************************
// getLength returns the value in the private member length. *
//************************************************************

float Rectangle::getLength(void)
{
	return length;
}

//************************************************************
// getArea returns the value in the private member area.     *
//************************************************************

float Rectangle::getArea(void)
{
	return area;
}
