#ifndef INTLIST_H
#define INTLIST_H

class IntList
{
private:
	int list[20];
	bool isValid(int);
public:
	// Constructor
	IntList(void);
	bool set(int, int);
	bool get(int, int&);
};

#endif
