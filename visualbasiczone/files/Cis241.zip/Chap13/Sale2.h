#ifndef SALE2_H
#define SALE2_H

// Sale class declaration
class Sale
{
private:
	float taxRate;
	float total;
public:
	Sale(float rate = 0.05) { taxRate = rate; }
	void calcSale(float cost)
		{ total = cost + (cost * taxRate); }
	float getTotal(void) { return total; }
};

#endif
