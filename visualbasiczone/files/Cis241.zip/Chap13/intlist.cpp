#include <iostream.h>
#include "intlist.h"

//**************************************
// Constructor.                        *
// Each element in the list is         *
// set to zero.                        *
//**************************************

IntList::IntList(void)
{ 
	for (int ndx = 0; ndx < 20; ndx++)
		list[ndx] = 0;
}

//********************************************
// isValid member function.                  *
// This private member functon returns true  *
// if the argument is a valid subscript into *
// the list. It returns false otherwise, and *
// displays an error message.                *
//********************************************

bool IntList::isValid(int element)
{
	bool status;

	if (element < 0 || element > 19)
	{
		cout << "ERROR: " << element;
		cout << " is an invalid subscript.\n";
		status = false;
	}
	else
		status = true;
	return status;
}

//********************************************
// set member function.                      *
// Stores a value in a specific element      *
// of the list. If the value passed to       *
// element is a valid subscript, the         *
// function returns true. Otherwise, it      *
// returns false.                            *
//********************************************

bool IntList::set(int element, int value)
{
	bool status;

	if (isValid(element))
	{
		list[element] = value;
		status = true;
	}
	else
		status = false;
	return status;
}

//*****************************************************
// get member function.                               *
// Retrieves the value stored in the element          *
// specified by the argument element. If the          *
// element is a valid subscript, the retrieved        *
// value is stored in value and the function          *
// returns true. If element is an  invalid subscript, *
// the function returns false.                        *
//*****************************************************

bool IntList::get(int element, int &value)
{
	bool status;

	if (isValid(element))
	{
		value = list[element];
		status = true;
	}
	else
		status = false;
	return status;
}
