// This program demonstrates a simple class

#include <iostream.h>
#include "rectang.h"  // contains Rectangle class declaration

// Don't forget to link this program with rectang.cpp!

void main(void)
{
	Rectangle box;
	float wide, boxLong;

	cout << "This program will calculate the area of a\n";
	cout << "rectangle. What is the width? ";
	cin >> wide;
	cout << "What is the length? ";
	cin >> boxLong;
	box.setData(wide, boxLong);
	box.calcArea();
	cout << "Here is the rectangle's data:\n";
	cout << "Width: " << box.getWidth() << endl;
	cout << "Length: " << box.getLength() << endl;
	cout << "Area: " << box.getArea() << endl;
}
