#ifndef ACCOUNT_H
#define ACCOUNT_H

class Account
{
private:
	float balance;
	float intRate;
	float interest;
	int transactions;
public:
	Account(float irate = 0.045, float bal = 0)
		{ balance = bal; intRate = irate; 
		  interest = 0; transactions = 0; }
	void makeDeposit(float amount)
		{ balance += amount; transactions++; }
	bool withdraw(float amount); // Defined in account.cpp
	void calcInterest(void)
		{ interest = balance * intRate; balance += interest; }
	float getBalance(void)
		{ return balance; }
	float getInterest(void)
		{ return interest; }
	int getTransactions(void)
		{ return transactions; }
};

#endif
