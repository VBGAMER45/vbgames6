// This program demonstrates a class with overloaded
// constructors

#include <iostream.h>
#include "invitem2.h"

void main(void)
{
	InvItem item1("Wrench");
	InvItem item2;

	item1.setUnits(15);
	item2.setInfo("Pliers", 25);
	cout << "The following items are in inventory:\n";
	cout << "Description: " << item1.getDesc() << "\t\t";
	cout << "Units on Hand: " << item1.getUnits() << endl;
	cout << "Description: " << item2.getDesc() << "\t\t";
	cout << "Units on Hand: " << item2.getUnits() << endl;
}
