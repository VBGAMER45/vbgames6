// This program demonstrates the charRange class.
#include <iostream.h>
#include "chrange.h" // Remember to compile & link chrange.cpp

// Error message to be displayed when the user
// enters an invalid character.
const char *Msg = "Only enter J, K, L, M, or N: ";

void main(void)
{
	// Create an object to check for characters
	// in the range J - N.
	CharRange input('J', 'N', Msg);

	cout << "Enter any of the characters J, K, L, M, or N.\n";
	cout << "Entering N will stop this program.\n";
	while (input.getChar() != 'N');
}

