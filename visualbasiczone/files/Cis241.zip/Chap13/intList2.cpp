#include <iostream.h>
#include "intlist2.h"

//********************************************
// Constructor.                              *
// Each element in the list is               *
// set to zero.                              *
//********************************************

IntList::IntList(void)
{ 
	for (int ndx = 0; ndx < 20; ndx++)
		list[ndx] = 0;
}

//********************************************
// isValid member function.                  *
// This private member functon returns true  *
// if the argument is a valid subscript into *
// the list. It returns false otherwise, and *
// displays an error message.                *
//********************************************

bool IntList::isValid(int element)
{
	if (element < 0 || element > 19)
	{
		cout << "ERROR: " << element;
		cout << " is an invalid subscript.\n";
		return false;
	}
	else
		return true;
}

//********************************************
// set member function.                      *
// Stores a value in a specific element      *
// of the list. If the value passed to       *
// element is a valid subscript, the         *
// function returns true. Otherwise, it      *
// returns false.                            *
//********************************************

bool IntList::set(int element, int value)
{
	if (isValid(element))
	{
		list[element] = value;
		return true;
	}
	else
		return false;
}

//*****************************************************
// get member function.                               *
// Retrieves the value stored in the element          *
// specified by the argument element. If the          *
// element is a valid subscript, the retrieved        *
// value is stored in value and the function          *
// returns true. If element is an  invalid subscript, *
// the function returns false.                        *
//*****************************************************

bool IntList::get(int element, int &value)
{
	if (isValid(element))
	{
		value = list[element];
		return true;
	}
	else
		return false;
}

//******************************************************
// linearSearch member function.                       *
// performs a linear search on the list for value.     *
// If value is found, its array subscript is returned. *
// Otherwise, -1 is returned indicating the value was  *
// not in the array.                                   *
//******************************************************

int IntList::linearSearch(int value)
{
	int status = -1;

	for (int count = 0; count < 20; count++)
	{
		if (list[count] == value)
		{
			status =  count;
			break;
		}
	}
	return status;
}

//**********************************************************
// binarySearch member function.                           *
// Performs a binary search on the list for value.         *
// If the value is found, its array subscript is returned. *
// Otherwise, -1 is returned indicating the value was not  *
// in the array.                                           *
//**********************************************************

int IntList::binarySearch(int value)
{
	int first = 0,		// First element
		last = 19,		// Last element
		middle,			// Mid point of serach
		position = -1;	// Position of search value
	bool found = false;	// Flag

	// First, sort the list.
	selectionSort();
	while (!found && first <= last)
	{
		middle = (first + last) / 2;	// Calculate mid point
		if (list[middle] == value)		// If value is found at mid
		{
			found = true;
			position = middle;
		}
		else if (list[middle] > value)	// If value is in lower half
			last = middle - 1;
 		else
			first = middle + 1;			// If value is in upper half
	}
	return position;
}

//********************************************
// bubbleSort member function.               *
// Performs an ascending order               *
// bubble sort on list.                      *
//********************************************

void IntList::bubbleSort(void)
{
	int swap, temp;

	do
	{
		swap = 0;
		for (int count = 0; count < 19; count++)
		{
			if (list[count] > list[count + 1])
			{
				temp = list[count];
				list[count] = list[count + 1];
				list[count + 1] = temp;
				swap = 1;
			}
		}
   } while (swap != 0);
}

//********************************************
// selectionSort member function.            *
// Performs an ascending                     *
// order selection sort on list.             *
//********************************************

void IntList::selectionSort(void)
{
	int startScan, minIndex, minValue;

	for (startScan = 0; startScan < 19; startScan++)
	{
		minIndex = startScan;
		minValue = list[startScan];
		for(int index = startScan + 1; index < 20; index++)
		{
			if (list[index] < minValue)
			{
				minValue = list[index];
				minIndex = index;
			}
      }
		list[minIndex] = list[startScan];
		list[startScan] = minValue;
	}
}
