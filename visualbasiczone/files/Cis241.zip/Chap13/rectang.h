#ifndef RECTANGLE_H
#define RECTANGLE_H

// Rectangle class declaration.
class Rectangle
{
	private:
		float width;
		float length;
		float area;
	public:
		void setData(float, float);
		void calcArea(void);
		float getWidth(void);
		float getLength(void);
		float getArea(void);
};

#endif
