#include <iostream.h>
#include <string.h>	// For strlen
#include <ctype.h>	// For toupper
#include "chrange.h"

//********************************************************
// CharRange constructor. Parameters low and high hold   *
// the lower and upper characters in the range. str      *
// points to a C-string that is an error message to      *
// display when a character outside the range is entered.*
//********************************************************

CharRange::CharRange(char low, char high, const char *str)
{
	lower = toupper(low);
	upper = toupper(high);
	errMsg = new char[strlen(str) + 1];
	strcpy(errMsg, str);
}

//************************************************************
// getChar member function. This function reads a character  *
// from the keyboard. If the character is less than the      *
// the contents of lower, or greater than the contents of    *
// upper (both private members or the CharRange class), the  *
// error message stored in the errMsg member is displayed,   *
// and another character is read. If the character is within *
// the range, it is returned from the function.              *
//************************************************************

char CharRange::getChar(void)
{
	cin.get(input);
	cin.ignore();
	input = toupper(input);
	while (input < lower || input > upper)
	{
		cout << errMsg;
		cin.get(input);
		cin.ignore();
		input = toupper(input);
	}
	return input;
}



