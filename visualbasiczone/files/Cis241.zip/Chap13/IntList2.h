#ifndef INTLIST_H
#define INTLIST_H

class IntList
{
private:
	int list[20];
	bool isValid(int);
public:
	// Constructor
	IntList(void);
	bool set(int, int);
	bool get(int, int&);
	int linearSearch(int);
	int binarySearch(int);
	void bubbleSort(void);
	void selectionSort(void);
};

#endif
