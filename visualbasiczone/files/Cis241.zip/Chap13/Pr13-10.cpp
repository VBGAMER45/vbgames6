#include <iostream.h>
#include "sale.h"

void main(void)
{
	Sale cashier(0.06);	// 6% sales tax rate
	float amnt;

	cout.precision(2);
	cout.setf(ios::fixed | ios::showpoint);	
	cout << "Enter the amount of the sale: ";
	cin >> amnt;
	cashier.calcSale(amnt);
	cout << "The total of the sale is $";
	cout << cashier.getTotal() << endl;
}
