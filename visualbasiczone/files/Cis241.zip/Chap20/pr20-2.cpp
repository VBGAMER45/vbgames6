// This program builds a binary tree with 5 nodes.
// The nodes are displayed with inorder, preorder,
// and postorder algorithms.

#include <iostream.h>
#include "IntBinaryTree.h"

void main(void)
{
	IntBinaryTree tree;

	cout << "Inserting nodes.\n";
	tree.insertNode(5);
	tree.insertNode(8);
	tree.insertNode(3);
	tree.insertNode(12);
	tree.insertNode(9);
	cout << "Inorder traversal:\n";
	tree.showNodesInOrder();
	cout << "\nPreorder traversal:\n";
	tree.showNodesPreOrder();
	cout << "\nPostorder traversal:\n";
	tree.showNodesPostOrder();
}
