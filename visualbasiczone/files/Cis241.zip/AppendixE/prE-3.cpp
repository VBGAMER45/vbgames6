// This program demonstrates the
// using namespace statement.

#include <iostream.h>
#include "nsdemo.h"

using namespace demo;

void main(void)
{
	testObject.x = 10;
	testObject.y = 20;
	testObject.z = 30;
	cout << "The values are:\n"
		 << testObject.x << " "
		 << testObject.y << " "
		 << testObject.z << endl;
}

