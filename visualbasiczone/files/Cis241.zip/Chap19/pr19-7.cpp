#include <iostream.h>
#include "FloatList2.h"

void main(void)
{
	FloatList list;

	for (int x = 0; x < 10; x++)
		list.insertNode(x);
	cout << "The number of nodes is "
	     << list.numNodes() << endl;
}

