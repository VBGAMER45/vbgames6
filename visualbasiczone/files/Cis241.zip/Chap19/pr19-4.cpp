// This program demonstrates a recursive function to 
// calculate the factorial of a number.

#include <iostream.h>

// Function prototype
int factorial(int);

void main(void)
{
	int number;

	cout << "Enter an integer value and I will display\n";
	cout << "its factorial: ";
	cin >> number;
	cout << "The factorial of " << number << " is ";
	cout << factorial(number) << endl;
}

//**************************************************************
// Definition of factorial. A recursive function to calculate  *
// the factorial of the parameter, num.                        *
//**************************************************************

int factorial(int num)
{
	if (num > 0)
		return num * factorial(num - 1);
	else
		return 1;
}
