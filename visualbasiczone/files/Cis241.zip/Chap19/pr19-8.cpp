// This program demonstrates the FloatList class's
// recursive function for displaying the list's nodes
// in reverse.

#include <iostream.h>
#include "FloatList2.h"

void main(void)
{
	FloatList list;

	for (float x = 1.5; x < 15; x += 1.1)
		list.appendNode(x);
	cout << "Here are the values in the list:\n";
	list.displayList();

	cout << "Here are the values in reverse order:\n";
	list.displayBackwards();
}
