#ifndef FLOATLIST2_H
#define FLOATLIST2_H

class FloatList
{
private:
	// Declare a structure for the list
	struct ListNode
	{
		float value;
		struct ListNode *next;
	}; 

	ListNode *head;	// List head pointer
	int countNodes(ListNode *);
	void showReverse(ListNode *); 
public:
	FloatList(void)	// Constructor
		{ head = NULL; }
	~FloatList(); // Destructor
	void appendNode(float);
	void insertNode(float);
	void deleteNode(float);
	void displayList(void);
	int numNodes(void)
		{	return countNodes(head); }
	void displayBackwards(void)
		{	showReverse(head); }
};

#endif
