// This program demonstrates a recursive function for
// counting the number of times a character appears
// in a string.

#include <iostream.h>

int numChars(char, char [], int);

void main(void)
{
	char array[] = "abcddddef";
	
	cout << "The letter d appears "
		<< numChars('d', array, 0) << " times\n";
}
	
//************************************************
// Function numChars. This recursive function    *
// counts the number of times the character      *
// search appears in the string str. The search  *
// begins at the subscript stored in subscript.  *
//************************************************

int numChars(char search, char str[], int subscript) 
{ 
	if (str[subscript] == '\0') 
		return 0;
	else
	{ 
		if (str[subscript] == search) 
			return 1 + numChars(search, str, subscript+1); 
		else 
			return numChars(search, str, subscript+1); 
	} 
}

