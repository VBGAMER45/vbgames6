// This program demonstrates a simple recursive function.

#include <iostream.h>

// Function prototype
void message(int);

void main(void)
{
	message(5);
}

//*************************************************************
// Definition of function message. If the value in times is   *
// greater than 0, the message is displayed and the function  *
// is recursively called with the argument times - 1.         *
//*************************************************************

void message(int times)
{
	cout << "Message called with " << times << " in times.\n";
	if (times > 0)
	{
		cout << "This is a recursive function.\n";
		message(times - 1);
	}
	cout << "Message returning with " << times;
	cout << " in times.\n";
}
