#include <iostream.h>  // For cout  and NULL
#include "floatlist2.h"

//************************************************
// AppendNode appends a node containing the      *
// value pased into num, to the end of the list. *
//************************************************

void FloatList::appendNode(float num)
{
	ListNode *newNode, *nodePtr;

	// Allocate a new node & store num
	newNode = new ListNode;
	newNode->value = num;
	newNode->next = NULL;

	// If there are no nodes in the list
	// make newNode the first node
	if (!head)
		head = newNode;
	else	// Otherwise, insert newNode at end
	{
		// Initialize nodePtr to head of list
		nodePtr = head;

		// Find the last node in the list
		while (nodePtr->next)
			nodePtr = nodePtr->next;

		// Insert newNode as the last node
		nodePtr->next = newNode;
	}
}

//************************************************
// DisplayList shows the value                   *
// stored in each node of the linked list        *
// pointed to by head.                           *
//************************************************

void FloatList::displayList(void)
{
	ListNode *nodePtr;

	nodePtr = head;
	while (nodePtr)
	{
		cout << nodePtr->value << endl;
		nodePtr = nodePtr->next;
	}
}

//************************************************
// The InsertNode function inserts a node with   *
// num copied to its value member.               *
//************************************************

void FloatList::insertNode(float num)
{
	ListNode *newNode, *nodePtr, *previousNode;

	// Allocate a new node & store num
	newNode = new ListNode;
	newNode->value = num;
	
	// If there are no nodes in the list
	// make newNode the first node
	if (!head)
	{
		head = newNode;
		newNode->next = NULL;
	}
	else	// Otherwise, insert newNode at end
	{
		// Initialize nodePtr to head of list
		nodePtr = head;

		// Skip all nodes whose value member is less
		// than num.
		while (nodePtr != NULL && nodePtr->value < num)
		{	
			previousNode = nodePtr;
			nodePtr = nodePtr->next;
		}

		// If the new node is to be the 1st in the list,
		// insert it before all other nodes.
		if (previousNode == NULL)
		{
			head = newNode;
			newNode->next = nodePtr;
		}
		else	// Otherwise, insert it after the prev. node.
		{
			previousNode->next = newNode;
			newNode->next = nodePtr;
		}
	}
}

//************************************************
// The DeleteNode function searches for a node   *
// with num as its value. The node, if found, is *
// deleted from the list and from memory.        *
//************************************************

void FloatList::deleteNode(float num)
{
	ListNode *nodePtr, *previousNode;

	// If the list is empty, do nothing.
	if (!head)
		return;
	
	// Determine if the first node is the one.
	if (head->value == num)
	{
		nodePtr = head->next;
		delete head;
		head = nodePtr;
	}
	else
	{
		// Initialize nodePtr to head of list
		nodePtr = head;

		// Skip all nodes whose value member is 
		// not equal to num.
		while (nodePtr != NULL && nodePtr->value != num)
		{	
			previousNode = nodePtr;
			nodePtr = nodePtr->next;
		}

		// Link the previous node to the node after
		// nodePtr, then delete nodePtr.
		previousNode->next = nodePtr->next;
		delete nodePtr;
	}
}

//************************************************
// Destructor                                    *
// This function deletes every node in the list. *
//************************************************

FloatList::~FloatList(void)
{
	ListNode *nodePtr, *nextNode;

	nodePtr = head;
	while (nodePtr != NULL)
	{
		nextNode = nodePtr->next;
		delete nodePtr;
		nodePtr = nextNode;
	}
}

//**************************************************
// countNodes is a recursive function that returns *
// the number of nodes in the list.                *
//**************************************************

int FloatList::countNodes(ListNode *nodePtr)
{
	if (nodePtr != NULL)
		return 1 + countNodes(nodePtr->next);
	else
		return 0;
}

//****************************************************
// showReverse is a recursive function that displays *
// the values stored in the list in reverse. The     *
// function is called from DisplayBackwards.         *
//****************************************************

void FloatList::showReverse(ListNode *nodePtr)
{
	if (nodePtr != NULL)
	{
		showReverse(nodePtr->next);
		cout << nodePtr->value << " ";
	}
}
