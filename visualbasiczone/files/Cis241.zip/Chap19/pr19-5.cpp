// This program demonstrates a recursive function to calculate
// the greatest common divisor (gcd) of two numbers.

#include <iostream.h>

// Function prototype
int gcd(int, int);

void main(void)
{
	int num1, num2;

	cout << "Enter two integers: ";
	cin >> num1 >> num2;
	cout << "The greatest common divisor of " << num1;
	cout << " and " << num2 << " is ";
	cout << gcd(num1, num2) << endl;
}

//*********************************************************
// Definition of gcd. This function uses recursion to     *
// calculate the greatest common divisor of two integers, *
// passed into the parameters x and y.                    *
//*********************************************************

int gcd(int x, int y)
{
	if (x % y == 0)
		return y;
	else
		return gcd(y, x % y);
}
