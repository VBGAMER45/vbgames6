// This program demonstrates the QuickSort Algorithm

#include <iostream.h>

// Function prototypes
void quickSort(int [], int, int);
int partition(int [], int, int);
void exchange(int &, int &);

void main(void)
{
	int array[10] = {7, 3, 9, 2, 0, 1, 8, 4, 6, 5};
	int x;		// Counter

	for (x = 0; x < 10; x++)
		cout << array[x] << " ";
	cout << endl;
	quickSort(array, 0, 9);
	for (x = 0; x < 10; x++)
		cout << array[x] << " ";
	cout << endl;
}

//************************************************
// quickSort uses the quicksort algorithm to     *
// sort set, from set[start] through set[end].   *
//************************************************

void quickSort(int set[], int start, int end)
{
	int pivotPoint;

	if (start < end)
	{
		// Get the pivot point.
		pivotPoint = partition(set, start, end);
		// Sort the first sub list.
		quickSort(set, start, pivotPoint - 1);
		// Sort the second sub list.
		quickSort(set, pivotPoint + 1, end);
	}
}

// Partitions array set from subscripts start to end based on  set[start] element.
// Returns the location which contains the pivot element after partitioning
// Requires use of sentinel - but could remove that need by changing condition
// on while loops to check for going past bounds
// Would be something like while(pivotValue>=set[low] && low <= end) low++;

int partition(int set[],int start,int end)
{  
	int pivotValue, low, high, pivotIndex;

	pivotValue = set[start];  //gets a pivot point
	low = start + 1;    high = end;
	while(low<high)
	{  
		while(pivotValue>=set[low])
			low++;
		while(pivotValue<set[high])
			high--;
		if(low<high)
			exchange(set[low], set[high]);  // swap set[low] with set[high]
	}
	exchange(set[start], set[high]);	// swap set[start] with set[high]
	return high;						// contains the pivot index
}

/*
//**********************************************************
// partition selects the value in the middle of the        *
// array set as the pivot. The list is rearranged so       *
// all the values less than the pivot are on its left      *
// and all the values greater than pivot are on its right. *
//**********************************************************

int partition(int set[], int start, int end)
{
	int pivotValue, pivotIndex, mid;

	mid = (start + end) / 2;
	exchange(set[start], set[mid]);
	pivotIndex = start;
	pivotValue = set[start];
	for (int scan = start + 1; scan <= end; scan++)
	{
		if (set[scan] < pivotValue)
		{
			pivotIndex++;
			exchange(set[pivotIndex], set[scan]);
		}
	}
	exchange(set[start], set[pivotIndex]);
	return pivotIndex;
} */

//**********************************************
// exchange simply exchanges the contents of   *
// value1 and value2.                          *
//**********************************************

void exchange(int &value1, int &value2)
{
	int temp = value1;
	value1 = value2;
	value2 = temp;
}

