// This program demonstrates a base class and a derived class

#include <iostream.h>
#include "test2.h"

void main(void)
{
	int questions, missed;

	cout << "How many questions are on the test? ";
	cin >> questions;
	cout << "How many questions did the student miss? ";
	cin >> missed;
        // Declare a Test object
	Test exam(questions, missed);
	cout.precision(2);
	cout.setf(ios::fixed);
	cout << "Unadjusted score: " << exam.getScore() << endl;
	cout << "Unadjusted grade: " << exam.getLetter() << endl;
	exam.adjustScore();
	cout << "Adjusted score is: " << exam.getScore() << endl;
	cout << "Adjusted grade is: " << exam.getLetter() << endl;
}
