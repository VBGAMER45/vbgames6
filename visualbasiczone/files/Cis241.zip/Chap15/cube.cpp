#include "cube.h"

//**********************************
// Definition of Cube constructor. *
//**********************************

Cube::Cube(float wide, float length, float high) : Rect(wide, length)
{
	height = high;
	volume = area * high;
}
