// This program demonstrates the behavior of a base class pointer
// when it is pointing to a derived class that overrides members
// of the base class.
// The class declarations are placed directly in the file for simplicity.

#include <iostream.h>

class Base
{
public:
	void show(void)
		{ cout << "This is from the Base class.\n"; }
};

class Derived : public Base
{
public:
	void show(void)
		{ cout << "This is from the Derived class.\n"; }
};

void main(void)
{
	Base *bptr;
	Derived dobject;

	bptr = &dobject;
	bptr->show();		// Base class pointer, ignores override
}
