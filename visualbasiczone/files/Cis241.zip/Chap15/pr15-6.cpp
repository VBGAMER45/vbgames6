// This program demonstrates that when a derived class function
// overrides a base class function, objects of the base class
// still call the base class version of the function.

#include <iostream.h>

class Base
{
public:
	void showMsg(void)
		{ cout << "This is the Base class.\n"; }
};

class Derived : public Base
{
public:
	void showMsg(void)
		{ cout << "This is the Derived class.\n"; }
};

void main(void)
{
	Base b;
	Derived d;

	b.showMsg();
	d.showMsg();
}
