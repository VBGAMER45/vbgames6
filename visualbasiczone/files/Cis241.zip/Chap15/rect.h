#ifndef RECT_H
#define RECT_H

// Rect class declaration
class Rect
{
protected:
	float width;
	float length;
	float area;
public:
	Rect(void) { width = length = area = 0.0; }
	Rect(float, float);
	float getArea(void) { return area; }
	float getLen(void) { return length; }
	float getWidth(void) { return width; }
};

#endif
