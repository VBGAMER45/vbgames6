#ifndef STUDENT_H
#define STUDENT_H
#include <string.h>	// For strcpy

class Student
{
protected:
	char name[51];
	char id[21];
	int yearAdmitted;
	int hoursCompleted;
public:
	Student(void)	// Constructor
		{ name[0] = id[0] = yearAdmitted = hoursCompleted = 0; }
	void setName(char *n)
		{ strcpy(name, n); }
	void setID(char *i)
		{ strcpy(id, i); }
	void setYearAdmitted(int y)
		{ yearAdmitted = y; }
	virtual void setHours(void) = 0;	// Pure virtual fnction
	virtual void showInfo(void) = 0;	// Pure virtual function
};

#endif

