#ifndef MILEDIS3_H
#define MILEDIS3_H

// MileDist class declaration.
class MileDist
{
protected:
	float miles;
public:
	void setDist(float d) { miles = d; }
	virtual float getDist(void) { return miles; }
	float square(void) { return getDist() * getDist(); }
};

#endif
