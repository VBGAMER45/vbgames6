#ifndef CSSTUDENT_H
#define CSSTUDENT_H
#include "student.h"

class CsStudent : public Student
{
private:
	int mathHours;	// Hours of math taken
	int csHours;	// Hours of Computer Science taken
	int genEdHours;	// Hours of general education taken
public:
	void setMathHours(int mh)
		{ mathHours = mh; }
	void setCsHours(int csh)
		{ csHours = csh; }
	void setGenEdHours(int geh)
		{ genEdHours = geh; }
	void setHours(void)
		{ 	hoursCompleted = genEdHours + mathHours + csHours; }
	void showInfo(void);	// Defined in csstudent.cpp
};

#endif
