#include "rect.h"

//**********************************
// Definition of Rect constructor. *
//**********************************

Rect::Rect(float w, float l)
{
	width = w;
	length = l;
	area = width * length;
}
