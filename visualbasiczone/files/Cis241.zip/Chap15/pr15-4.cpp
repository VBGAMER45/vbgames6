// This program demonstrates passing arguments to a base
// class constructor.

#include <iostream.h>
#include "cube.h"

void main(void)
{
	float cubeWide, cubeLong, cubeHigh;

	cout << "Enter the dimensions of a Cube:\n";
	cout << "Width: ";
	cin >> cubeWide;
	cout << "Length: ";
	cin >> cubeLong;
	cout << "Height: ";
	cin >> cubeHigh;
	Cube holder(cubeWide, cubeLong, cubeHigh);
	cout << "Here are the Cube's properties:\n";
	cout << "Width: " << holder.getWidth() << endl;
	cout << "Length: " << holder.getLen() << endl;
	cout << "Height: " << holder.getHeight() << endl;
	cout << "Base area: " << holder.getArea() << endl;
	cout << "Volume: " << holder.getVol() << endl;
}
