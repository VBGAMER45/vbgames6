// This program demonstrates a derived class with
// functions that override base class functions.
// NOTE: FTDIST.CPP must be compiled and linked with this 
// program.

#include <iostream.h>
#include <iomanip.h>
#include "ftdist.h"

void main(void)
{
	FtDist feet;
	float ft;

	cout << "Enter a distance in feet and I will convert it\n";
	cout << "to miles: ";
	cin >> ft;
	feet.setDist(ft);
	cout.precision(1);
	cout.setf(ios::fixed);
	cout << feet.getDist() << " feet equals ";
	cout << feet.getMiles() << " miles.\n";
}
