#ifndef GRADE_H
#define GRADE_H

// Grade class declaration

class Grade
{
private:
	char letter;
	float score;
	void calcGrade(void);
public:
	void setScore(float s) { score = s; calcGrade();}
	float getScore(void) {return score; }
	char getLetter(void) { return letter; }
};

#endif
