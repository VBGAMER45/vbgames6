#ifndef GRADE2_H
#define GRADE2_H

// Grade class declaration
class Grade
{
protected:
	char letter;
	float score;
	void calcGrade(void);
public:
	void setScore(float s) { score = s; calcGrade(); }
	float getScore(void) {return score; }
	char getLetter(void) { return letter; }
};

#endif
