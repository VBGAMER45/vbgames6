// This program demonstrates a base class and a derived class

#include <iostream.h>
#include "test.h"

void main(void)
{
	int questions, missed;

	cout << "How many questions are on the test? ";
	cin >> questions;
	cout << "How many questions did the student miss? ";
	cin >> missed;
    // Declare a Test object
	Test exam(questions, missed);
	cout.precision(2);
	cout << "The score is " << exam.getScore() << endl;
	cout << "The grade is " << exam.getLetter() << endl;
}
