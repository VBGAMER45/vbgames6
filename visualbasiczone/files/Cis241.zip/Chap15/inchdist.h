#ifndef INCHDIST_H
#define INCHDIST_H

#include "ftdist3.h" // Needed for FtDist class declaration.

// InchDist class declaration
class InchDist : public FtDist
{
protected:
	float inches;
public:
	void setDist(float);
	float getDist(void) { return inches; }
	float getFeet(void) { return feet; }
};

#endif
