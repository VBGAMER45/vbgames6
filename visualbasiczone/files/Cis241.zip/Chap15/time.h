#ifndef TIME_H
#define TIME_H

class Time
{
protected:
	int hour;
	int min;
	int sec;
public:
	Time(int h, int m, int s) { hour = h; min = m; sec = s; }
	int getHour(void) { return hour; }
	int getMin(void) { return min; }
	int getSec(void) { return sec; }
};

#endif
