// This program demonstrates a base class with an improperly
// overridden function.

#include <iostream.h>
#include "ftdist2.h"

void main(void)
{
	FtDist feet;
	float ft;

	cout << "Enter a distance in feet and I will convert it\n";
	cout << "to miles: ";
	cin >> ft;
	feet.setDist(ft);
	cout.precision(1);
	cout.setf(ios::fixed);
	cout << feet.getDist() << " feet equals ";
	cout << feet.getMiles() << " miles.\n";
	cout << feet.getDist() << " square feet equals ";
	cout << feet.square() << " total feet.\n";
}
