#include "test.h"

//***************************************************************
// Definition of Test class constructor                         *
// Parameters: q = Number of questions, m = number of questions *
// missed.                                                      *
//***************************************************************

Test::Test(int q, int m)
{
	float numericGrade;

	numQuestions = q;
	numMissed = m;
	pointsEach = 100.0 / numQuestions;
	numericGrade = 100.0 - (numMissed * pointsEach);
	setScore(numericGrade);
}
