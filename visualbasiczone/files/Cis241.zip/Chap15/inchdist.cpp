#include "inchdist.h"

//**************************************************
// Definition of setDist member of InchDist class. *
//**************************************************

void InchDist::setDist(float in)
{
	inches = in;
	FtDist::setDist(inches / 12);  // Call base class function
}
