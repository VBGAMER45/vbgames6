#ifndef TEST_H
#define TEST_H

#include "grade.h"  // Must include Grade class declaration.

// Test class declaration

class Test : public Grade
{
private:
	int numQuestions;
	float pointsEach;
	int numMissed;
public:
	Test(int, int);
};

#endif
