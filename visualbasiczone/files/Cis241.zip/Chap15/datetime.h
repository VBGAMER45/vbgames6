#ifndef DATETIME_H
#define DATETIME_H

#include <string.h>
#include "date.h" // For Date class declaration
#include "time.h" // For Time class declaration

class DateTime : public Date, public Time
{
protected:
	char dTString[20];
public:
	DateTime(int, int, int, int, int, int);
	void getDateTime(char *str) { strcpy(str, dTString); }
};

#endif
