#ifndef MILEDIST_H
#define MILEDIST_H

// MileDist class declaration.
class MileDist
{
protected:
	float miles;
public:
	void setDist(float d) { miles = d; }
	float getDist(void) { return miles; }
};

#endif
