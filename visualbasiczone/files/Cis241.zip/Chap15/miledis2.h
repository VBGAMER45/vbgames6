#ifndef MILEDIS2_H
#define MILEDIS2_H

// MileDist class declaration.
class MileDist
{
protected:
	float miles;
public:
	void setDist(float d) { miles = d; }
	float getDist(void) { return miles; }
	float square(void) { return getDist() * getDist(); }
};

#endif
