#ifndef FTDIST2_H
#define FTDIST2_H

#include "miledis2.h"

// FtDist class declaration
class FtDist : public MileDist
{
protected:
	float feet;
public:
	void setDist(float);
	float getDist(void) { return feet; }
	float getMiles(void) { return miles; }
};

#endif
