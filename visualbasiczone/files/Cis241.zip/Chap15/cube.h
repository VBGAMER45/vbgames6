#ifndef CUBE_H
#define CUBE_H

#include "rect.h"

// Cube class declaration
class Cube : public Rect
{
protected:
	float height;
	float volume;
public:
	Cube(float, float, float);
	float getHeight(void) { return height; }
	float getVol(void) { return volume; }
};

#endif
