// This program demonstrates the CsStudent class, which is
// derived from the abstract base class, Student.

#include <iostream.h>
#include "csstudent.h"

void main(void)
{
	CsStudent student1;
	char chInput[51];	// Input buffer for entering C-strings.
	int intInput;		// Input buffer for entering integers.

	cout << "Enter the following student information:\n";
	// Set the student's name.
	cout << "Name: ";
	cin.getline(chInput, 51);
	student1.setName(chInput);

	// Set the student's ID number.
	cout << "Student ID: ";
	cin.getline(chInput, 21);
	student1.setID(chInput);

	// Set the year admitted.
	cout << "Year admitted: ";
	cin >> intInput;
	student1.setYearAdmitted(intInput);

	// Set the # of general ed hours completed.
	cout << "Number of general ed hours completed: ";
	cin >> intInput;
	student1.setGenEdHours(intInput);

	// Set the # of math hours completed.
	cout << "Number of math hours completed: ";
	cin >> intInput;
	student1.setMathHours(intInput);

	// Set the # of computer science hours completed.
	cout << "Number of computer science hours completed: ";
	cin >> intInput;
	student1.setCsHours(intInput);

	// Total the hours entered.
	student1.setHours();

	// Display the information provided.
	cout << "\nSTUDENT INFORMATION\n";
	student1.showInfo();
}


