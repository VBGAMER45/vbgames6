#ifndef DATE_H
#define DATE_H

class Date
{
protected:
	int day;
	int month;
	int year;
public:
	Date(int d, int m, int y) { day = d; month = m; year = y; }
	int getDay(void) { return day; }
	int getMonth(void) { return month; }
	int getYear(void) { return year; }
};

#endif
