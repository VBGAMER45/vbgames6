#include "datetime.h"
#include <string.h> // For strcpy and strcat
#include <stdlib.h> // For itoa

DateTime::DateTime(int dy, int mon, int yr, int hr, int mt, int sc):Date(dy, mon, yr), Time(hr, mt, sc)
{
	char temp[10]; // Temporary work area for itoa()

	// Store the date in dTString, in the form MM/DD/YY
	strcpy(dTString, itoa(getMonth(), temp, 10));
	strcat(dTString, "/");
	strcat(dTString, itoa(getDay(), temp, 10));
	strcat(dTString, "/");
	strcat(dTString, itoa(getYear(), temp, 10));
	strcat(dTString, " ");
	// Store the time in dTString, in the form HH:MM:SS
	strcat(dTString, itoa(getHour(), temp, 10));
	strcat(dTString, ":");
	strcat(dTString, itoa(getMin(), temp, 10));
	strcat(dTString, ":");
	strcat(dTString, itoa(getSec(), temp, 10));
}
