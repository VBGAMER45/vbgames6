#ifndef FTDIST3_H
#define FTDIST3_H

#include "miledis3.h"

// FtDist class declaration
class FtDist : public MileDist
{
protected:
	float feet;
public:
	void setDist(float);
	virtual float getDist(void) { return feet; }
	float getMiles(void) { return miles; }
};

#endif
