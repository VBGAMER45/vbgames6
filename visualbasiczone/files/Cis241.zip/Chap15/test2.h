#ifndef TEST2_H
#define TEST2_H

#include "grade2.h"

// Test class declaration
class Test : public Grade
{
private:
	int numQuestions;
	float pointsEach;
	int numMissed;
public:
	Test(int, int);
	void adjustScore(void);
};

#endif
