#include <iostream.h>
#include "csstudent.h"

void CsStudent::showInfo(void)
{
	cout << "Name: " << name << endl;
	cout << "Student ID: " << id << endl;
	cout << "Year admitted: " << yearAdmitted << endl;
	cout << "Summary of hours completed:\n";
	cout << "\tGeneral Education: " << genEdHours << endl;
	cout << "\tMath: " << mathHours << endl;
	cout << "\tComputer Science: " << csHours << endl << endl;
	cout << "\tTotal Hours Completed: " << hoursCompleted << endl;
}
