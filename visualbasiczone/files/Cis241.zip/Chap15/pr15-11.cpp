// This program demonstrates a derived class derived from a
// another derived class.
// NOTE: inchdist.cpp and ftdist3.cpp must be compiled and linked
// with this program.

#include <iostream.h>
#include <iomanip.h>
#include "inchdist.h"

void main(void)
{
	InchDist inch;
	float in;

	cout << "Enter a distance in inches and I will convert\n";
	cout << "it to feet and miles: ";
	cin >> in;
	inch.setDist(in);
	cout.precision(1);
	cout.setf(ios::fixed);
	cout << inch.getDist() << " inches equals ";
	cout << inch.getFeet() << " feet.\n";
	cout << inch.getDist() << " inches equals ";
	cout << inch.getMiles() << " miles.\n";
}
