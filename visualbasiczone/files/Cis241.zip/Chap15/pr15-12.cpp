// This program demonstrates a class with multiple inheritance.
// NOTE: datetime.cpp must be compiled and linked with this
// file.

#include <iostream.h>
#include "datetime.h"

void main(void)
{
	char formatted[20];
	DateTime pastDay(2, 4, 60, 5, 32, 27);

	pastDay.getDateTime(formatted);
	cout << formatted << endl;
}
