#include "ftdist2.h"

void FtDist::setDist(float ft)
{
	feet = ft;
	MileDist::setDist(feet / 5280);  // Call base class function
}
