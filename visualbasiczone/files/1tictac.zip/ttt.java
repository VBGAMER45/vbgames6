
		
		import java.awt.*;
		import java.applet.*;
		
		import java.awt.image.*;
		
		public class ttt extends Applet {
		                          
		
		  Button newgame;
		  Image backgrd;
		  int boxes[] = new int [30];
		  int winner1,winner2;
		  boolean found,full,validresponse;
		  String xwins,ywins;
		  GridBagLayout thisLayout = new GridBagLayout();
		  GridBagConstraints c = new GridBagConstraints ();  
		
		
		  public void init () {
		    backgrd = getImage(getCodeBase(),"backgrd.gif");
		    c.fill = GridBagConstraints.BOTH;
		    c.gridx=12;
		    c.gridy=1;
		    c.gridwidth=1;
		    c.gridheight=1;
		    Button newButton = new Button ( "New game");
		    thisLayout.setConstraints(newButton,c);
		    add(newButton);
		     
		    xwins="No of wins for X:";
		    ywins="No of wins for O:";
		    reset ();
		  
		  } // init
		  
		  public boolean action( Event e, Object obj )
	      {
	      if ( "New game".equals( obj ) ) {
		  reset ();
		  }
	      
	      return true;
	      }
		
		  public void reset () {
		  xwins="No of wins for X:";
		  ywins="No of wins for O:";
		  for (int p=0;p<30;p++) boxes[p]=0;
		  winner1=0;
		  winner2=0;       
		  repaint ();
		  }
		  
		  public void paint (Graphics g) {
		  g.drawImage (backgrd,0,0,this);
		  int p;
		  for (p=0;p<27;p++) if  (boxes[p]==1) drawX (g,p);
		  for (p=0;p<27;p++) if (boxes[p]==2) drawO (g,p);
		  g.setColor (Color.black);
		  g.drawString (xwins,280,40);
		  g.drawString (ywins,280,60);
		  g.drawString ("3D tic tac toe",280,180);
		  g.drawString ("The object of the game is to get",280,220);
		  g.drawString ("as many 3 in a rows as possible",280,240);
		  g.drawString ("You win just like in tic tac toe",280,260);
		  g.drawString ("except you can also win by getting",280,280);
		  g.drawString ("3 in a row down each board",280,300);
		  }
		  
		  public void drawX (Graphics g,int where) {
		  int x,y,xo1,xo2,yo1,yo2;
		  xo1=50;
		  yo1=9;
		  xo2=98;
		  yo2=17;
		  g.setColor (Color.white);
		  x=(where-((int) (where/3)*3)) * 50;
		  y=((int ) (where/3))*50;
		  if (where<9) {
  		  g.drawLine (x,y,x+50,y+50);
		  g.drawLine (x+50,y,x,y+50);
		  }
		  if (where>8) if (where<18) {
		  g.drawLine (x+xo1,y+yo1,x+50+xo1,y+50+yo1);
		  g.drawLine (x+50+xo1,y+yo1,x+xo1,y+50+yo1);
		  }
		  if (where>17) if (where<27) {
		  g.drawLine (x+xo2,y+yo2,x+50+xo2,y+50+yo2);
		  g.drawLine (x+50+xo2,y+yo2,x+xo2,y+50+yo2);
		  }
		  
		  
		  
		  }
		  public void drawO (Graphics g,int where) {
		  int x,y,xo1,xo2,yo1,yo2;
		  xo1=50;
		  yo1=9;
		  xo2=98;
		  yo2=17;
		  g.setColor (Color.white);
		  x=(where-((int) (where/3)*3)) * 50;
		  y=((int ) (where/3))*50;
		  if (where<9) 
  		  g.drawOval (x,y,50,50);
  		  
		  if (where>8) if (where<18) 
		  g.drawOval (x+xo1,y+yo1,50,50);
		  
		  
		  if (where>17) if (where<27) 
          g.drawOval (x+xo2,y+yo2,50,50);
		  
		  
		  }

		 public boolean mouseDown( Event e, int x, int y )
       	 {
       	 int p,px,py,xo1,xo2,yo1,yo2;
		  xo1=50;
		  yo1=9;
		  xo2=98;
		  yo2=17;
		 validresponse=false;

       	 for (p=0;p<9;p++) {
       	 px=p-((int) (p/3)*3);
       	 py=(int) (p/3);
       	 if (x>px*50) if (x<(px*50)+50) if (y>py*50) if (y<(py*50)+50) 
       	 if (boxes[p]==0) {
       	 boxes[p]=1;
       	 validresponse=true;
       	 }
       	 }
       	 
       	 for (p=9;p<18;p++) {
       	 px=p-((int) (p/3)*3);
       	 py=(int) (p/3);
       	 if (x>px*50+xo1) if (x<(px*50)+50+xo1) if (y>py*50+yo1) if (y<(py*50)+50+yo1) 
       	 if (boxes[p]==0) {
       	 validresponse=true;
      	 boxes[p]=1;
       	 }
       	 }
       	 
       	 for (p=18;p<27;p++) {
       	 px=p-((int) (p/3)*3);
       	 py=(int) (p/3);
       	 if (x>px*50+xo2) if (x<(px*50)+50+xo2) if (y>py*50+yo2) if (y<(py*50)+50+yo2) 
       	 if (boxes[p]==0) {
       	 validresponse=true;
       	 boxes[p]=1;
       	 }
       	 }
       	 
       	 
       	 
       	 if (validresponse==true) computermove ();
       	 
       	 checkwin ();
       	 
       	 repaint ();
		 return true;
     	 }
     	 
     	 public void checkfull () {
     	 full=true;
     	 for (int p=0;p<27;p++) if (boxes[p]==0) full=false;
     	 }
		  
		 public void computermove () {
		 found=false;
		 if (found==false) goforcenter ();
		 if (found==false) goforwin ();
		 if (found==false) goforblock ();
		 if (found==false) putrandom ();
		 }
	      
		public void goforcenter () {
		if (boxes[13]==0) {
		boxes[13]=2;
		found=true;
		}
		}
		public void goforwin () {
		int p,three,bp,gotone;
		gotone=0;
		int first = 2;
bp=0;
three=0;
for (p=0;p<3;p=p+1) if (boxes [p]==first) three=three+1;
if (three==2) for (p=0;p<3;p=p+1) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=3;p<6;p=p+1) if (boxes [p]==first) three=three+1;
if (three==2) for (p=3;p<6;p=p+1) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=6;p<9;p=p+1) if (boxes [p]==first) three=three+1;
if (three==2) for (p=6;p<9;p=p+1) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=0;p<7;p=p+3) if (boxes [p]==first) three=three+1;
if (three==2) for (p=0;p<7;p=p+3) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=1;p<8;p=p+3) if (boxes [p]==first) three=three+1;
if (three==2) for (p=1;p<8;p=p+3) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=2;p<9;p=p+3) if (boxes [p]==first) three=three+1;
if (three==2) for (p=2;p<9;p=p+3) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=0;p<9;p=p+4) if (boxes [p]==first) three=three+1;
if (three==2) for (p=0;p<9;p=p+4) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=2;p<7;p=p+2) if (boxes [p]==first) three=three+1;
if (three==3) for (p=2;p<7;p=p+2) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
three=0;
for (p=9;p<12;p=p+1) if (boxes [p]==first) three=three+1;
if (three==2) for (p=9;p<12;p=p+1) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=12;p<15;p=p+1) if (boxes [p]==first) three=three+1;
if (three==2) for (p=12;p<15;p=p+1) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=15;p<18;p=p+1) if (boxes [p]==first) three=three+1;
if (three==2) for (p=15;p<18;p=p+1) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=9;p<16;p=p+3) if (boxes [p]==first) three=three+1;
if (three==2) for (p=9;p<16;p=p+3) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=10;p<17;p=p+3) if (boxes [p]==first) three=three+1;
if (three==2) for (p=10;p<17;p=p+3) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=11;p<18;p=p+3) if (boxes [p]==first) three=three+1;
if (three==2) for (p=11;p<18;p=p+3) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=9;p<18;p=p+4) if (boxes [p]==first) three=three+1;
if (three==2) for (p=9;p<18;p=p+4) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=11;p<16;p=p+2) if (boxes [p]==first) three=three+1;
if (three==3) for (p=11;p<16;p=p+2) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
three=0;
for (p=18;p<21;p=p+1) if (boxes [p]==first) three=three+1;
if (three==2) for (p=18;p<21;p=p+1) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=21;p<24;p=p+1) if (boxes [p]==first) three=three+1;
if (three==2) for (p=21;p<24;p=p+1) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=24;p<27;p=p+1) if (boxes [p]==first) three=three+1;
if (three==2) for (p=24;p<27;p=p+1) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=18;p<25;p=p+3) if (boxes [p]==first) three=three+1;
if (three==2) for (p=18;p<25;p=p+3) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=19;p<26;p=p+3) if (boxes [p]==first) three=three+1;
if (three==2) for (p=19;p<26;p=p+3) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=20;p<27;p=p+3) if (boxes [p]==first) three=three+1;
if (three==2) for (p=20;p<27;p=p+3) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=18;p<27;p=p+4) if (boxes [p]==first) three=three+1;
if (three==2) for (p=18;p<27;p=p+4) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=20;p<25;p=p+2) if (boxes [p]==first) three=three+1;
if (three==2) for (p=20;p<25;p=p+2) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=0;p<19;p=p+9) if (boxes [p]==first) three=three+1;
if (three==2) for (p=0;p<19;p=p+9) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=1;p<20;p=p+9) if (boxes [p]==first) three=three+1;
if (three==2) for (p=1;p<20;p=p+9) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=2;p<21;p=p+9) if (boxes [p]==first) three=three+1;
if (three==2) for (p=2;p<21;p=p+9) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=3;p<22;p=p+9) if (boxes [p]==first) three=three+1;
if (three==2) for (p=3;p<22;p=p+9) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=4;p<23;p=p+9) if (boxes [p]==first) three=three+1;
if (three==2) for (p=4;p<23;p=p+9) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=5;p<24;p=p+9) if (boxes [p]==first) three=three+1;
if (three==2) for (p=5;p<24;p=p+9) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=6;p<25;p=p+9) if (boxes [p]==first) three=three+1;
if (three==2) for (p=6;p<25;p=p+9) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=7;p<26;p=p+9) if (boxes [p]==first) three=three+1;
if (three==2) for (p=7;p<26;p=p+9) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=8;p<27;p=p+9) if (boxes [p]==first) three=three+1;
if (three==2) for (p=8;p<27;p=p+9) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=0;p<25;p=p+12) if (boxes [p]==first) three=three+1;
if (three==2) for (p=0;p<25;p=p+12) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=1;p<26;p=p+12) if (boxes [p]==first) three=three+1;
if (three==2) for (p=1;p<26;p=p+12) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=2;p<27;p=p+12) if (boxes [p]==first) three=three+1;
if (three==2) for (p=2;p<27;p=p+12) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=6;p<19;p=p+6) if (boxes [p]==first) three=three+1;
if (three==2) for (p=6;p<19;p=p+6) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=7;p<20;p=p+6) if (boxes [p]==first) three=three+1;
if (three==2) for (p=7;p<20;p=p+6) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=8;p<21;p=p+6) if (boxes [p]==first) three=three+1;
if (three==2) for (p=8;p<21;p=p+6) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=0;p<21;p=p+10) if (boxes [p]==first) three=three+1;
if (three==2) for (p=0;p<21;p=p+10) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=3;p<24;p=p+10) if (boxes [p]==first) three=three+1;
if (three==2) for (p=3;p<24;p=p+10) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=6;p<27;p=p+10) if (boxes [p]==first) three=three+1;
if (three==2) for (p=6;p<27;p=p+10) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=2;p<19;p=p+8) if (boxes [p]==first) three=three+1;
if (three==2) for (p=2;p<19;p=p+8) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=5;p<22;p=p+8) if (boxes [p]==first) three=three+1;
if (three==2) for (p=5;p<22;p=p+8) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=8;p<25;p=p+8) if (boxes [p]==first) three=three+1;
if (three==2) for (p=8;p<25;p=p+8) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=0;p<27;p=p+13) if (boxes [p]==first) three=three+1;
if (three==2) for (p=0;p<27;p=p+13) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=2;p<25;p=p+11) if (boxes [p]==first) three=three+1;
if (three==2) for (p=2;p<25;p=p+11) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=6;p<21;p=p+7) if (boxes [p]==first) three=three+1;
if (three==2) for (p=6;p<21;p=p+7) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=8;p<19;p=p+5) if (boxes [p]==first) three=three+1;
if (three==2) for (p=8;p<19;p=p+5) if (boxes [p]==0) {
bp=p;
gotone=1;
}
if (gotone==1) {
found = true;
boxes[bp]=2;
}
		}
		public void goforblock () {
		int p,three,ffirst,bp,gotone;
ffirst=1;
bp=0;
gotone=0;
three=0;
for (p=0;p<3;p=p+1) if (boxes [p]==ffirst) three=three+1;
if (three==2) for (p=0;p<3;p=p+1) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=3;p<6;p=p+1) if (boxes [p]==ffirst) three=three+1;
if (three==2) for (p=3;p<6;p=p+1) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=6;p<9;p=p+1) if (boxes [p]==ffirst) three=three+1;
if (three==2) for (p=6;p<9;p=p+1) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=0;p<7;p=p+3) if (boxes [p]==ffirst) three=three+1;
if (three==2) for (p=0;p<7;p=p+3) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=1;p<8;p=p+3) if (boxes [p]==ffirst) three=three+1;
if (three==2) for (p=1;p<8;p=p+3) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=2;p<9;p=p+3) if (boxes [p]==ffirst) three=three+1;
if (three==2) for (p=2;p<9;p=p+3) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=0;p<9;p=p+4) if (boxes [p]==ffirst) three=three+1;
if (three==2) for (p=0;p<9;p=p+4) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=2;p<7;p=p+2) if (boxes [p]==ffirst) three=three+1;
if (three==3) for (p=2;p<7;p=p+2) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=9;p<12;p=p+1) if (boxes [p]==ffirst) three=three+1;
if (three==2) for (p=9;p<12;p=p+1) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=12;p<15;p=p+1) if (boxes [p]==ffirst) three=three+1;
if (three==2) for (p=12;p<15;p=p+1) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=15;p<18;p=p+1) if (boxes [p]==ffirst) three=three+1;
if (three==2) for (p=15;p<18;p=p+1) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=9;p<16;p=p+3) if (boxes [p]==ffirst) three=three+1;
if (three==2) for (p=9;p<16;p=p+3) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=10;p<17;p=p+3) if (boxes [p]==ffirst) three=three+1;
if (three==2) for (p=10;p<17;p=p+3) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=11;p<18;p=p+3) if (boxes [p]==ffirst) three=three+1;
if (three==2) for (p=11;p<18;p=p+3) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=9;p<18;p=p+4) if (boxes [p]==ffirst) three=three+1;
if (three==2) for (p=9;p<18;p=p+4) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=11;p<16;p=p+2) if (boxes [p]==ffirst) three=three+1;
if (three==3) for (p=11;p<16;p=p+2) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
three=0;
for (p=18;p<21;p=p+1) if (boxes [p]==ffirst) three=three+1;
if (three==2) for (p=18;p<21;p=p+1) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=21;p<24;p=p+1) if (boxes [p]==ffirst) three=three+1;
if (three==2) for (p=21;p<24;p=p+1) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=24;p<27;p=p+1) if (boxes [p]==ffirst) three=three+1;
if (three==2) for (p=24;p<27;p=p+1) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=18;p<25;p=p+3) if (boxes [p]==ffirst) three=three+1;
if (three==2) for (p=18;p<25;p=p+3) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=19;p<26;p=p+3) if (boxes [p]==ffirst) three=three+1;
if (three==2) for (p=19;p<26;p=p+3) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=20;p<27;p=p+3) if (boxes [p]==ffirst) three=three+1;
if (three==2) for (p=20;p<27;p=p+3) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=18;p<27;p=p+4) if (boxes [p]==ffirst) three=three+1;
if (three==2) for (p=18;p<27;p=p+4) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;
for (p=20;p<25;p=p+2) if (boxes [p]==ffirst) three=three+1;
if (three==2) for (p=20;p<25;p=p+2) if (boxes [p]==0) {
bp=p;
gotone=1;
}
three=0;

if (gotone==1) {
found = true;
boxes[bp]=2;
}

		}
		public void putrandom () {
		int a,b;
		while (found==false) {
		a=(int) (26 * Math.random());
		if (boxes[a]==0) {
		found=true;
		boxes[a]=2;
		} //if
		checkfull ();
		if (full==true) found=true;
		} // while
		} // putrand
		
		
		void checkwin ()
{
winner1=0;
winner2=0;
int p,three;
three=0;
for (p=0;p<3;p=p+1) if (boxes [p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=3;p<6;p=p+1) if (boxes [p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=6;p<9;p=p+1) if (boxes [p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=0;p<7;p=p+3) if (boxes [p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=1;p<8;p=p+3) if (boxes [p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=2;p<9;p=p+3) if (boxes [p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=0;p<9;p=p+4) if (boxes [p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=2;p<7;p=p+2) if (boxes [p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=0;p<3;p=p+1) if (boxes [p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=3;p<6;p=p+1) if (boxes [p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=6;p<9;p=p+1) if (boxes [p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=0;p<7;p=p+3) if (boxes [p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=1;p<8;p=p+3) if (boxes [p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=2;p<9;p=p+3) if (boxes [p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=0;p<9;p=p+4) if (boxes [p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=2;p<7;p=p+2) if (boxes [p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=9;p<12;p=p+1) if (boxes [p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=12;p<15;p=p+1) if (boxes [p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=15;p<18;p=p+1) if (boxes [p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=9;p<16;p=p+3) if (boxes [p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=10;p<17;p=p+3) if (boxes [p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=11;p<18;p=p+3) if (boxes [p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=9;p<18;p=p+4) if (boxes [p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=11;p<16;p=p+2) if (boxes [p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=9;p<12;p=p+1) if (boxes [p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=12;p<15;p=p+1) if (boxes [p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=15;p<18;p=p+1) if (boxes [p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=9;p<16;p=p+3) if (boxes [p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=10;p<17;p=p+3) if (boxes [p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=11;p<18;p=p+3) if (boxes [p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=9;p<18;p=p+4) if (boxes [p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=11;p<16;p=p+2) if (boxes [p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=18;p<21;p=p+1) if (boxes [p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=21;p<24;p=p+1) if (boxes [p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=24;p<27;p=p+1) if (boxes [p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=18;p<25;p=p+3) if (boxes [p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=19;p<26;p=p+3) if (boxes [p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=20;p<27;p=p+3) if (boxes [p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=18;p<27;p=p+4) if (boxes [p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=20;p<25;p=p+2) if (boxes [p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=18;p<21;p=p+1) if (boxes [p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=21;p<24;p=p+1) if (boxes [p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=24;p<27;p=p+1) if (boxes [p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=18;p<25;p=p+3) if (boxes [p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=19;p<26;p=p+3) if (boxes [p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=20;p<27;p=p+3) if (boxes [p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=18;p<27;p=p+4) if (boxes [p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=20;p<25;p=p+2) if (boxes [p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=0;p<19;p=p+9) if (boxes[p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=1;p<20;p=p+9) if (boxes[p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=2;p<21;p=p+9) if (boxes[p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=3;p<22;p=p+9) if (boxes[p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=4;p<23;p=p+9) if (boxes[p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=5;p<24;p=p+9) if (boxes[p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=6;p<25;p=p+9) if (boxes[p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=7;p<26;p=p+9) if (boxes[p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=8;p<27;p=p+9) if (boxes[p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=0;p<25;p=p+12) if (boxes[p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=1;p<26;p=p+12) if (boxes[p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=2;p<27;p=p+12) if (boxes[p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=6;p<19;p=p+6) if (boxes[p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=7;p<20;p=p+6) if (boxes[p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=8;p<21;p=p+6) if (boxes[p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=0;p<21;p=p+10) if (boxes[p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=3;p<24;p=p+10) if (boxes[p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=6;p<27;p=p+10) if (boxes[p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=2;p<19;p=p+8) if (boxes[p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=5;p<22;p=p+8) if (boxes[p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=8;p<25;p=p+8) if (boxes[p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=0;p<27;p=p+13) if (boxes[p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=2;p<25;p=p+11) if (boxes[p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=6;p<21;p=p+7) if (boxes[p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=8;p<19;p=p+5) if (boxes[p]==1) three=three+1;
if (three==3) winner1=winner1+1;
three=0;
for (p=0;p<19;p=p+9) if (boxes[p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=1;p<20;p=p+9) if (boxes[p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=2;p<21;p=p+9) if (boxes[p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=3;p<22;p=p+9) if (boxes[p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=4;p<23;p=p+9) if (boxes[p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=5;p<24;p=p+9) if (boxes[p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=6;p<25;p=p+9) if (boxes[p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=7;p<26;p=p+9) if (boxes[p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=8;p<27;p=p+9) if (boxes[p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=0;p<25;p=p+12) if (boxes[p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=1;p<26;p=p+12) if (boxes[p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=2;p<27;p=p+12) if (boxes[p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=6;p<19;p=p+6) if (boxes[p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=7;p<20;p=p+6) if (boxes[p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=8;p<21;p=p+6) if (boxes[p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=0;p<21;p=p+10) if (boxes[p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=3;p<24;p=p+10) if (boxes[p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=6;p<27;p=p+10) if (boxes[p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=2;p<19;p=p+8) if (boxes[p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=5;p<22;p=p+8) if (boxes[p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=8;p<25;p=p+8) if (boxes[p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=0;p<27;p=p+13) if (boxes[p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=2;p<25;p=p+11) if (boxes[p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=6;p<21;p=p+7) if (boxes[p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
for (p=8;p<19;p=p+5) if (boxes[p]==2) three=three+1;
if (three==3) winner2=winner2+1;
three=0;
xwins="No of wins for X: "+winner1;
ywins="No of wins for O: "+winner2;
}
		
		} // class TTT
		
		
