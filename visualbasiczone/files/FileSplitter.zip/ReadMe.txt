I wrote this program because I often need to copy
large files from one machine and transfer them to
another.  File Splitter enables you to split any file
into smaller files that then be copied to floppy
disks and then rejoined into a copy of the original
file.  The program could use some refinement but I'll
leave that up to you.  I hope that this program will
be of some use and look forward to your comments.

Richard Morrison  
EMail--- rmorrison@snet.net        