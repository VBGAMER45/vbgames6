RPG Engine Advanced v1.3
========================

By Fling-master - HyperRealistic Games http://www.qbrpgs.com
Date: 10/06/01

Here is the first public release of the QBRPG engine that I've been
working on since the release of the RPG Wizard. It makes use of DirectQB v1.61 since its the best all around VGA QB library available. (It even beats out Future.Library as far as VGA is concerned)

This engine features true pixel scrolling, zelda free-style movement around a map, multiple NPCs all moving on a map. You can set NPCs to behave differently (i.e. they can stand still, walk around randomly, move after the player or another target, attack the player, or move around randomly until the player is close enough, then attack the player). You can also shoot at NPC's and they can shoot back! Also, like in zelda, if you hit an enemy, you will bounce backwards.

NPCs can be classified as either enemy or neutral. You cannot kill enemies. Please note that I'm not an artist, and so I've just ripped graphics from assorted games, modified some slightly, and placed 'em all into a tileset. I don't even have death animations for NPCs! When they die they just disappear!

BTW Just ignore the life meter. If you run out of life you still live... Oh and I never finished designing the map, sorry! Oh and before I forget, don't walk outside the map or let an NPC push you outside the map. It will screw up!

-Plans for future
 *Add support for the player and badguys to swing swords
 *Add script interpreter (I've already made one complete with NPC   conversation, variables, and IFs but I need to tweak it a bit before   I add it to this public release.)
 *Add an inventory (Not that hard to do)
 *Add better path-finding abilities for the NPCs
 *Make a damn game out of this!!!!

If you can draw game sprites/tiles and would like to help me make a game out of this engine, then please e-mail me!! (Address at bottom)

-Credits
 *Me - For finally taking the time to polish the engine so it could be   released. =)
 *Angelo Mottola - For DirectQB, the best VGA QB library there is.
 *Michael Hoopman - For your QB Times article on NPC's. That got me     started into programming NPCs in the first place.

Any comments, problems, suggestions, and help can be e-mailed to: flingmaster5000@hotmail.com. Or you can (sometimes) reach me on ICQ at 47980542 (no authorization required).