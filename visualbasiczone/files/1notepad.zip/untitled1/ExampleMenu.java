///////////////////////////////////////////////////////////////////////////
//Here is the code to build menus/submenus.
//Enjoy!!
///////////////////////////////////////////////////////////////////////////

package untitled1;

import java.awt.*;
import java.awt.event.*;
import com.borland.jbcl.control.*;
import com.borland.jbcl.layout.*;
import javax.swing.*;
import java.io.*;

public class ExampleMenu extends DecoratedFrame {
  XYLayout xYLayout2 = new XYLayout();
  BevelPanel bevelPanel1 = new BevelPanel();
  BorderLayout borderLayout1 = new BorderLayout();

  private File file;

  MenuBar mb = new MenuBar();
  Menu menuFile = new Menu("File");
  Menu menuEdit = new Menu("Edit");
  Menu menuView = new Menu("View");
  Menu menuHelp = new Menu("Help");

  MenuItem menuFileOpen = new MenuItem("Open");
  MenuItem menuFileClose = new MenuItem("Close");
  MenuItem menuFilePrint = new MenuItem("Print");
  MenuItem menuFileExit = new MenuItem("Exit");

  MenuItem menuEditCopy = new MenuItem("Copy");
  MenuItem menuEditPaste = new MenuItem("Paste");
  MenuItem menuHelpAbout = new MenuItem("About Application");

  //Sub Menus and their MenuItems (I got lazy on the naming conventions)
  Menu menu1 = new Menu();
  MenuItem menuItem1 = new MenuItem();
  MenuItem menuItem2 = new MenuItem();
  MenuItem menuItem3 = new MenuItem();
  MenuItem menuItem4 = new MenuItem();
  Menu menu2 = new Menu();
  MenuItem menuItem5 = new MenuItem();
  MenuItem menuItem6 = new MenuItem();
  TextArea fileArea = new TextArea();

  String currFileName = null;  // Full path with filename. null means new / untitled.
  boolean dirty = false;  // True means modified text.

  String fileText = "";
  private ObjectOutputStream output;
  MenuItem menuItem7 = new MenuItem();
  MenuItem menuFileNew = new MenuItem();
  MenuItem SaveAs = new MenuItem();



  //Construct the frame
  public ExampleMenu() {
    try  {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  //Component initialization
  private void jbInit() throws Exception  {
    this.setLayout(borderLayout1);
    this.setIconImageName("A:\\NotePadProject\\Untitled1\\DBPasswordPrompter.gif");//("c:\\WINNT\\Profiles\\JACOBSS\\Desktop\\untitled1\\DBPasswordPrompter.gif");
    this.setSize(new Dimension(400, 300));
    this.setTitle("Menu App/Personal Note-pad");
    bevelPanel1.setLayout(xYLayout2);


    menuItem1.setLabel("25X");
    menuItem1.setEnabled(false);
    menuItem2.setLabel("50x");
    menuItem2.setEnabled(false);
    menuItem3.setLabel("75x");
    menuItem3.setEnabled(false);
    menuItem4.setLabel("100x");
    menuItem4.setEnabled(false);
    menuItem5.setLabel("Horizontal");
    menuItem6.setLabel("Vertical");
    menuEditCopy.setShortcut(new MenuShortcut(67));
    menuEditCopy.setEnabled(false);
    menuEditPaste.setShortcut(new MenuShortcut(86));
    menuEditPaste.setEnabled(false);
    menuFileOpen.setShortcut(new MenuShortcut(79));
    menuFileClose.setShortcut(new MenuShortcut(66));
    menuFilePrint.setShortcut(new MenuShortcut(80));
    menuHelpAbout.setShortcut(new MenuShortcut(72));
    menu1.setLabel("Zoom");
    menu2.setLabel("Cascade Windows");
    menuFile.setFont(new java.awt.Font("Dialog", 1, 14));
    menuEdit.setFont(new java.awt.Font("Dialog", 1, 14));
    menuView.setFont(new java.awt.Font("Dialog", 1, 14));
    menuHelp.setFont(new java.awt.Font("Dialog", 1, 14));
    bevelPanel1.setBackground(Color.green);
    menuFileExit.setShortcut(new MenuShortcut(90));
    fileArea.setBackground(Color.white);
    fileArea.setText(" ");
    menuItem7.setLabel("Save");
    menuItem7.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
          {
            save_actionPerformed(e);
          }
      });
    menuItem7.setShortcut(new MenuShortcut(83));
    menuFileNew.setName("menuFileNew");
    menuFileNew.setLabel("New");
    menuFileNew.setShortcut(new MenuShortcut(78));
    SaveAs.setName("SaveAs");
    SaveAs.setLabel("Save As");
    SaveAs.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
          {
            saveAsFile_actionPerformed(e);
          }
      });
    SaveAs.setShortcut(new MenuShortcut(88));
    this.add(bevelPanel1, BorderLayout.CENTER);
    bevelPanel1.add(fileArea, new XYConstraints(8, 48, 376, -1));


    mb.add(menuFile);
    menuFile.add(menuFileNew);
    menuFileNew.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
          {
            new_actionPerformed(e);
          }
      });
    menuFile.add(menuFileOpen);
    menuFile.add(menuItem7);
    menuFile.add(SaveAs);
    menuFileOpen.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
          {
            open_actionPerformed(e);
          }
      });
    menuFile.add(menuFileClose);
    menuFileClose.disable();
    menuFile.add(menuFilePrint);
    menuFilePrint.disable();
    menuFile.addSeparator();
    menuFile.add(menuFileExit);
    menuFileExit.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
          {
            exit_actionPerformed(e);
          }
      });

    mb.add(menuEdit);
    menuEdit.add(menuEditCopy);
    menuEdit.add(menuEditPaste);

    mb.add(menuView);
    menuView.add(menu1);
    menuView.add(menu2);


    mb.add(menuHelp);
    menuHelp.add(menuHelpAbout);
    menuHelpAbout.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
          {
            about_actionPerformed(e);
          }
      });

    menu1.add(menuItem1);
    menu1.add(menuItem2);
    menu1.add(menuItem3);
    menu1.add(menuItem4);
    menu2.add(menuItem5);
    menu2.add(menuItem6);
    

    this.setMenuBar(mb);


  }

  void exit_actionPerformed(ActionEvent e)
    {
      System.exit(0);
    }

  void open_actionPerformed(ActionEvent e)
    {
      JFileChooser chooser = new JFileChooser();
      if (JFileChooser.APPROVE_OPTION == chooser.showOpenDialog(this)) {

            openFile(fileText);
            openFile(chooser.getSelectedFile().getPath());
            this.repaint();
     }
  }

  void save_actionPerformed(ActionEvent e)
    {
      String writeFile = "";
      JFileChooser chooser = new JFileChooser();
      if (JFileChooser.APPROVE_OPTION == chooser.showSaveDialog(this)) {
       saveFile(writeFile);
       }
    }

  void saveAsFile_actionPerformed(ActionEvent e)
    {
      saveAsFileDialog();
    }

  void about_actionPerformed(ActionEvent e)
    {
       ExampleMenu_AboutBox dlg = new ExampleMenu_AboutBox(this);
       Dimension dlgSize = dlg.getSize();
       Dimension frmSize = getSize();
       Point loc = getLocation();
       dlg.setLocation((frmSize.width - dlgSize.width) / 2 + loc.x,
       (frmSize.height - dlgSize.height) / 2 + loc.y);
       dlg.show();
    }

    void openFile(String FileName)
      {
        try
          {
            File file = new File(FileName);
            int size = (int)file.length();
            int chars_read = 0;
            FileReader in = new FileReader(file);
            char[] data = new char[size];
            while(in.ready())
              {
                chars_read += in.read(data, chars_read, size - chars_read);
              }
              in.close();
              fileArea.setText(new String(data,0,chars_read));
              // Cache the currently opened filename for use at save time...
              this.currFileName = FileName;
              // ...and mark the edit session as being clean
              this.dirty = false;
          }
          catch(IOException e)
            {
               JOptionPane.showMessageDialog(this, "Error opening file",
                                              "Error", JOptionPane.ERROR_MESSAGE);
            }


    }

  boolean saveFile(String fileName)
    {
      // Handle the case where we don't have a file name yet.
      if (currFileName == null)
      {
        return saveAsFileDialog();
      }
      try
        {
        // Open a file of the current name.
        File file = new File (currFileName);
        // Create an output writer that will write to that file.
        // FileWriter handles international characters encoding conversions.
        FileWriter out = new FileWriter(file);
        String text = fileArea.getText();
        out.write(text);
        out.close();
        this.dirty = false;
        return true;
        }
        catch (IOException e)
        {
        //NEED TO PUT IN A STATUS BAR
        }
        return false;

    }

    void new_actionPerformed(ActionEvent e)
      {
        fileArea.setText(" ");
      }

    boolean saveAsFileDialog()
      {
        String fileName = "";
        JFileChooser chooser = new JFileChooser();
        if (JFileChooser.APPROVE_OPTION == chooser.showSaveDialog(this))
          {
            currFileName = chooser.getSelectedFile().getPath();
            this.repaint();
            return saveFile(fileName);
          }
          else
            {
              this.repaint();
              return false;
            }
    }
}