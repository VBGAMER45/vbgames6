
//Title:        Example App with Menu/MenuBar
//Version:      
//Copyright:    Copyright (c) 1999
//Author:       Steven Jacobs
//Company:      none
//Description:  Sample app using menus/menubar/pop-up menu

package untitled1;

import java.awt.*;
import com.borland.jbcl.control.DecoratedFrame;
import javax.swing.*;
import java.awt.event.*;

public class FindFileFrame extends DecoratedFrame {
  Panel framePanel = new Panel();
  JFileChooser chooser = new JFileChooser();
  static JFrame frame;

  public FindFileFrame() {
    try  {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    this.setExitOnClose(false);
    this.add(framePanel, BorderLayout.CENTER);
    this.setTitle("File Look Up Locator");
    framePanel.add(chooser, null);
    this.setSize(new Dimension(550, 350));
    

  }

  public void actionPerformed(ActionEvent e) {
	int retval = chooser.showDialog(frame, null);
	if(retval == JFileChooser.APPROVE_OPTION) { }
	    //File theFile = chooser.getSelectedFile();
	    //if(theFile != null) {
		//if(theFile.isDirectory()) {
		    //JOptionPane.showMessageDialog(
			//frame, "You chose this directory: " +
			//chooser.getSelectedFile().getAbsolutePath()
		    //);
		//} else {
		    //JOptionPane.showMessageDialog(
			//frame, "You chose this file: " +
			//chooser.getSelectedFile().getAbsolutePath()
		    //);
		//}
		//return;
	    //}
	//}
	//JOptionPane.showMessageDialog(frame, "No file was chosen.");
    }
}
