import java.applet.*;
import java.lang.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.util.*;

public class SpGame extends Applet implements Runnable, MouseListener, MouseMotionListener, ActionListener {

private Thread thrd;
protected int mouseX = 0;
protected int mouseY = 0;
public int health = 100;
public int score = 0;
public Vector objs = new Vector(16,4);
private Image img;
private Button restartB;

private int randomInt(int greatest) {
return (int) (Math.round(Math.random()*greatest));
}

public void init() {
int i;
img = createImage(600,300);
for (i = 0; i < 20; i++) {
objs.addElement(new Star(this,randomInt(600),randomInt(300),randomInt(255)));
}
objs.addElement(new Ship(this));
objs.addElement(new EvilShip(this,600,randomInt(300)));
objs.addElement(new EvilShip(this,600,randomInt(300)));
setBackground(Color.black);
restartB = new Button("Restart");
add(restartB);
restartB.setVisible(false);
restartB.addActionListener(this);
}

public void start() {
thrd = new Thread(this);
thrd.start();
addMouseListener(this);
addMouseMotionListener(this);
}

public void stop() {
thrd = null;
}

public void paint(Graphics g) {
g.drawImage(img,0,0,null);
}

public void checkForExplosion() {
int i;
int j;
GameElement ge1;
GameElement ge2;
for (i = 0; i < objs.size(); i++) {
ge1 = (GameElement) objs.elementAt(i);
if (ge1.isShot()) {
for (j = 0; j < objs.size(); j++) {
ge2 = (GameElement) objs.elementAt(j);
if ((!ge2.isShot()) & (ge2.isEnabled())) {
if ((ge1.getX() > ge2.getX() - 32) & (ge1.getX() < ge2.getX() + 32)
  & (ge1.getY() > ge2.getY() - 2) & (ge1.getY() < ge2.getY() + 16)) {
ge1.handleCollision(ge2);
ge2.handleCollision(ge1);
}}}}}}

public void run() {
Thread thr = Thread.currentThread();
Graphics g = getGraphics();
Graphics gr = img.getGraphics();
GameElement ge;
int j = 0;
while (thrd == thr) {
gr.setColor(Color.black);
gr.fillRect(0,0,600,300);
checkForExplosion();
for (j = 0; j < objs.size(); j++) {
ge = (GameElement) objs.elementAt(j);
ge.advance();
gr.drawImage(ge.getTheImage(),ge.getX(),ge.getY(),null);
}
gr.setColor(Color.white);
gr.drawString("Health: " + health,0,12);
gr.drawString("Score: " + score,0,298);
if (health <= 0) {
gr.setFont(new Font("Courier",Font.PLAIN,96));
gr.drawString("GAME OVER",32,180);
restartB.setVisible(true);
validate();
thrd = null;
}
g.drawImage(img,0,0,null);
/*try {
thr.sleep(1000/60);
} catch (Exception e) {}*/
}
}

public void mouseClicked(MouseEvent e) {
}

public void mouseEntered(MouseEvent e) {
}

public void mouseExited(MouseEvent e) {
}

public void mousePressed(MouseEvent e) {
objs.addElement(new Shot(this,e.getX()+32,e.getY()-8,5));
showStatus("mousePressed");
}

public void mouseReleased(MouseEvent e) {
}

public void mouseDragged(MouseEvent e) {
}

public void mouseMoved(MouseEvent e) {
int j;
GameElement ge;
for (j = 0; j < objs.size(); j++) {
ge = (GameElement) objs.get(j);
ge.handleMouseMovement(e.getX(),e.getY());
}
}

public void actionPerformed(ActionEvent e) {
objs.removeAllElements();
removeAll();
score = 0;
health = 100;
init();
thrd = new Thread(this);
thrd.start();
}

}

abstract class GameElement extends Object {
public SpGame applet;

GameElement(SpGame aApplet) {
super();
applet = aApplet;
init();
}

protected GameElement() {
super();
applet = null;
init();
}

public abstract void init();
public abstract Image getTheImage();
public abstract boolean isShot();
public abstract boolean isEnabled();
public abstract void advance();
public abstract void handleCollision(GameElement objWith);
public abstract void handleMouseMovement(int x, int y);
public abstract int getX();
public abstract int getY();
}

class Ship extends GameElement {

static private Image img = null;
private int mouseX;
private int mouseY;

Ship(SpGame aApplet) {
super(aApplet);
}

public void init() {
if (img == null) {
try {
img = applet.getImage(new URL(applet.getCodeBase(),"ship.gif"));
} catch (Exception e) {}
}
}

public Image getTheImage() {
return img;
}

public boolean isShot() {
return false;
}

public boolean isEnabled() {
return true;
}

public void advance() {
if (Math.random() < 0.0005) applet.objs.addElement(new PowerUp(applet,(int) (Math.round(Math.random()*600)),(int) (Math.round(Math.random()*300))));
}

public void handleCollision(GameElement objWith) {
applet.health -= 10;
}

public void handleMouseMovement(int x, int y) {
mouseX = x;
mouseY = y-img.getHeight(null);
}

public int getX() {
return mouseX;
}

public int getY() {
return mouseY;
}

}

class Shot extends GameElement {

private int x;
private int y;
private int speed;
static private Image img = null;

Shot(SpGame aApplet, int aX, int aY, int aSpeed) {
super(aApplet);
x = aX;
y = aY;
speed = aSpeed;
}

public void init() {
if (img == null) {
try {
img = applet.getImage(new URL(applet.getCodeBase(),"shot.gif"));
} catch (Exception e) {}
}
}

public Image getTheImage() {
return img;
}

public boolean isShot() {
return true;
}

public boolean isEnabled() {
return true;
}

public void advance() {
x += speed;
if ((x > 600) | (x < -32)) {
applet.objs.removeElement(this);
}
}

public void handleCollision(GameElement objWith) {
applet.objs.removeElement(this);
}

public void handleMouseMovement(int x, int y) {
}

public int getX() {
return x;
}

public int getY() {
return y;
}

}

class EvilShip extends GameElement {

private float x;
private int y;
private float speed;
static private Image img = null;

EvilShip(SpGame aApplet, int aX, int aY) {
super(aApplet);
x = aX;
y = aY;
speed = 1;
}

public void init() {
if (img == null) {
try {
img = applet.getImage(new URL(applet.getCodeBase(),"evilship.gif"));
} catch (Exception e) {}
}
}

public Image getTheImage() {
return img;
}

public boolean isShot() {
return false;
}

public boolean isEnabled() {
return true;
}

public void advance() {
x -= speed;
if (x < -32) {
x += 632;
applet.health -= 25;
}
if (Math.random() < 0.01) {
applet.objs.addElement(new Shot(applet,Math.round(x-32),y+8,-4-Math.round(speed)));
}
}

public void handleCollision(GameElement objWith) {
x = 600;
y = (int) (Math.round(Math.random()*284));
applet.score += 100;
speed += .1;
}

public void handleMouseMovement(int x, int y) {
}

public int getX() {
return Math.round(x);
}

public int getY() {
return y;
}

}

class Star extends GameElement {

private Image img;
private int x;
private int y;
private int brightness;

Star(SpGame aApplet, int aX, int aY, int aBrightness) {
super(aApplet);
x = aX;
y = aY;
brightness = aBrightness;
}

public void init() {
}

public Image getTheImage() {
if (img == null) {
img = applet.createImage(2,2);
Graphics g = img.getGraphics();
g.setColor(new Color(brightness,brightness,brightness));
g.fillRect(0,0,1,1);
}
return img;
}

public boolean isShot() {
return false;
}

public boolean isEnabled() {
return false;
}

public void advance() {
x -= brightness / 32;
if (x < 0) x += 600;
}

public void handleCollision(GameElement objWith) {
}

public void handleMouseMovement(int x, int y) {
}

public int getX() {
return x;
}

public int getY() {
return y;
}
}

class PowerUp extends GameElement {

static private Image img = null;
private int x;
private int y;
private int counter;

PowerUp(SpGame aApplet, int aX, int aY) {
super(aApplet);
x = aX;
y = aY;
}

public void init() {
if (img == null) {
try {
img = applet.getImage(new URL(applet.getCodeBase(),"powerup.gif"));
} catch (Exception e) {}
}
}

public Image getTheImage() {
return img;
}

public boolean isShot() {
return true;
}

public boolean isEnabled() {
return true;
}

public void advance() {
counter++;
if (counter >= 1000) applet.objs.removeElement(this);
}

public void handleCollision(GameElement objWith) {
if (objWith.getClass().getName().equals("Ship")) {
applet.health += 35;
applet.objs.removeElement(this);
}
}

public void handleMouseMovement(int x, int y) {
}

public int getX() {
return x;
}

public int getY() {
return y;
}

}