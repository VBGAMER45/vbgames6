/*
				Written by:  Steven Bokser
				Contact:  slavenka@hotmail.com
	
	Use this code as you will as long as this comment is present.
*/

/*
	Class Shape provides basic functionality for all shapes
        derived from it( TShape, LShape, StickShape etc... ).
        
        Shape classes' only responsibility is to rotate and draw themselves 
        inside the PlayingField component. PlayingField is responsible for 
        keeping track of filled cells, eliminate filled rows and listening
        for keyboard events.
*/




import java.awt.Graphics;
import java.awt.Color;
import java.awt.Point;


public abstract class Shape
{
    
    /* 
    	Shape viewing angle constants
    */
    public static final int TWELVE_OCLOCK = 1;
    public static final int THREE_OCLOCK  = 2;
    public static final int SIX_OCLOCK    = 3;
    public static final int NINE_OCLOCK   = 4;


    /*
    	PlayingField where shape will be drawn
    */
    PlayingField playingField = null;    
    

    /*
    	Coordinates of the cell where shape will be drawn( in cell number, not pixels )
    */
    int row = 0;
    int col = 0;


    /*
    	Current view of the shape
    */
    int curPos = TWELVE_OCLOCK;



    /*
    	Public constructor
    */
    public Shape( PlayingField pf )
    {
    	this.playingField = pf;
    }


    /*
        Public copy constructor
    */
    public Shape( Shape s )
    {
        this.playingField = s.getPlayingField();
        setCoords( s.getRow(), s.getColumn() );
        setViewingAngle( s.getViewingAngle() );
    }
        

    /*
    	Erase previous instance of the shape and paint a new one
    */
    public void draw()
    {
        if ( playingField == null )	return;
        Graphics g = playingField.getGraphics();
        
        if ( g != null ) {
            try {
                g.setColor( getShapeColor() );
                drawShape( g );      // Paint fresh instance                   
            }
            finally {
                g.dispose();
            }
        }
    }


    /*
        Paint a single cell
    */
    protected void paintCell( Graphics g, int cellRow, int cellCol )
    {
        if ( g != null ) {
            int cellW = playingField.getCellWidth();
            int cellH = playingField.getCellHeight();
            g.fill3DRect( cellCol * cellW, cellRow * cellH, cellW - 1, cellH - 1, true );
        } 
    }
    
  
    /*
        Paint over previous figure with a background color of the playing field.
        The argument specifies cells of the figure to erase.
    */
    public void erasePreviousFigure( FilledCells fc)
    {
        if ( playingField != null && fc != null ) {
            Graphics g = playingField.getGraphics();
            if ( g != null ) {
                try {
                    g.setColor( playingField.getBackground() );
                    for ( int x = 0; x < fc.length; x++ )
                        paintCell( g, fc.cells[x][0], fc.cells[x][1] );
                }
                finally {
                    g.dispose();
                }
            }
        }
    }


    /*
    	Rotate the shape one position. If clockwise is set to true, 
        then rotate clockwise. Otherwise, rotate counter-clockwise. 
    */
    public void rotate()
    {
        int prevViewingAngle = curPos;
           
        if ( curPos != NINE_OCLOCK )        ++curPos;
        else if ( curPos == NINE_OCLOCK )   curPos = TWELVE_OCLOCK;
    
        FilledCells fc = getFilledCells();
        if ( playingField.isInvading( fc ) || playingField.outOfBounds( fc ) )
            curPos = prevViewingAngle;
    }


    /*
        Set row and column where shape will be drawn
    */
    public void setCoords( int r, int c )
    {
        int prevRow = row, prevCol = col;
        row = r;
        col = c;
        FilledCells fc = getFilledCells();
        if ( playingField.isInvading( fc ) ) {
            row = prevRow;
            col = prevCol;
        }
        else if ( playingField.outOfBounds( fc ) )
            col = prevCol;  
    }


    /*
        Return current coordinates
    */
    public int getRow()
    {
        return row;
    }


    public int getColumn()
    {
        return col;
    }


    /*
        Drop shape one row position
    */
    public void advance()
    {
        if ( !playingField.hitBottom( this ) )     ++row;
    }


    /*
        Physically draw the figure
    */
    private void drawShape( Graphics g )
    {
        int cellH = playingField.getCellHeight(),
            cellW = playingField.getCellWidth();
        int a;
        FilledCells fc = getFilledCells();

        for ( a = 0; a < fc.length; a++ )
            paintCell( g, fc.cells[a][0], fc.cells[a][1] );        
    } 


    /*
        Method that returns playing field that this shape is attached to
    */    
    public PlayingField getPlayingField()
    {
        return playingField;
    }

  
    public int getViewingAngle()
    {
        return curPos;
    }

  
    public void setViewingAngle( int i )
    {
        if ( i >= TWELVE_OCLOCK && i <= NINE_OCLOCK ) 
            curPos = i;
    }


    /*
    	Will be defined by subclasses to return the color of the shape
    */
    public abstract Color getShapeColor();

 
    /*
    	Will be defined by subclasses to return a point with coordinates 
        of the lowest cell and number of cells to its right at the same level
    */
    public abstract Cells getLowestCell();
    

    /*
        Return an array of all filled cells
    */
    public abstract FilledCells getFilledCells();

}