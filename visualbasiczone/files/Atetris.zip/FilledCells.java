/*
				Written by:  Steven Bokser
				Contact:  slavenka@hotmail.com
	
	Use this code as you will as long as this comment is present.
*/

/*
	Provides a way to identify which cells inside of the
	PlayingField are filled.
*/

class FilledCells 
{
    int length;
    int cells[][];

    public FilledCells( int length, int cells[][] )
    {
        this.length = length;
        this.cells = new int[length][2];

        for ( int x = 0; x < length; x++ ) {
            this.cells[x][0] = cells[x][0];
            this.cells[x][1] = cells[x][1];
        }
    }
}