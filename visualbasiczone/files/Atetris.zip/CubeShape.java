/*
				Written by:  Steven Bokser
				Contact:  slavenka@hotmail.com
	
	Use this code as you will as long as this comment is present.
*/

/*
	Defines a figure shaped like this
                                 
			       _ _
			      |_|_|
                              |_|_|                                         

*/



import java.awt.Graphics;
import java.awt.Color;


public class CubeShape 
    extends Shape
{
    
    /*
        Color of this shape. Feel free to change it.
    */
    public static final Color MY_COLOR = new Color( Color.cyan.darker().getRGB() );


    /*
        Public constructor
    */
    public CubeShape( PlayingField pf )
    {
        super( pf );
    }


    /*
    	Return a color of this figure
    */
    public Color getShapeColor()
    {
        return new Color( MY_COLOR.getRGB() );
    }


    /*
    	Return the coordinate of the lowest cell occupied by this fugure
        and a number of cells at same level to its right
    */
    public Cells getLowestCell()
    {
        return new Cells( row + 1, col, 2 );            	
    }   


    /*
        Return all filled cells
    */
    public FilledCells getFilledCells() 
    {
        int length = 4;
        int cells[][] = new int[length][2];	// Coordinates of the filled cells

        cells[0][0] = row;
        cells[0][1] = col;
        cells[1][0] = row;
        cells[1][1] = col + 1;
        cells[2][0] = row + 1;
        cells[2][1] = col;
        cells[3][0] = row + 1;
        cells[3][1] = col + 1;    
        
        return new FilledCells( length, cells );
    }
}