/*
				Written by:  Steven Bokser
				Contact:  slavenka@hotmail.com
	
	Use this code as you will as long as this comment is present.
*/

/*
	Defined figure shaped like this:
                
                           _ _ _ _ 
                          |_|_|_|_|
                          
*/


import java.awt.Graphics;
import java.awt.Color;

public class StickShape
    extends Shape 
{

    /*
        Color of this shape
    */
    public static final Color MY_COLOR = new Color( Color.orange.getRGB() );      


    /*
    	Public constructor. xPos and yPos are coordinates 
        where shape will be drawn.
    */
    public StickShape( PlayingField pf )
    {
        super( pf );
    }
 

    /*
    	Return color of this shape
    */
    public Color getShapeColor()
    {
        return new Color( MY_COLOR.getRGB() );
    }
 
    
    /*
    	Method getLowestCell() returns a coordinate of the lowest cell of the 
        shape and number of cells at the same level to its right
    */
    public Cells getLowestCell()
    {
        if ( curPos == TWELVE_OCLOCK || curPos == SIX_OCLOCK )    
            return new Cells( row, col, 4 );
        else if ( curPos == THREE_OCLOCK || curPos == NINE_OCLOCK )
            return new Cells( row + 3, col, 1 );

        return null;
    }


    /*
        Return coordinates of all cells
    */
    public FilledCells getFilledCells()
    {
        int length = 4;		// Number of cells
        int cells[][] = new int[length][2];	// Cell coordinates

        if ( curPos == TWELVE_OCLOCK || curPos == SIX_OCLOCK ) {
            cells[0][0] = cells[1][0] = cells[2][0] = cells[3][0] = row;
            cells[0][1] = col;
            cells[1][1] = col + 1;
            cells[2][1] = col + 2;
            cells[3][1] = col + 3;
        }
        else if ( curPos == THREE_OCLOCK || curPos == NINE_OCLOCK ) {
            cells[0][1] = cells[1][1] = cells[2][1] = cells[3][1] = col + 2;
            cells[0][0] = row;
            cells[1][0] = row + 1;
            cells[2][0] = row + 2;
            cells[3][0] = row + 3;
        }
        return new FilledCells( length, cells );
    }

}  