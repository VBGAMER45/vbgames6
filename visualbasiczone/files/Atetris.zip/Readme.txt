By:  Steven Bokser
Contact:  slavenka@hotmail.com

Refer to source.html file for information regarding each of the
classes contained in this app.

I welcome your suggestions and any feedback in general.

Enjoy and learn.