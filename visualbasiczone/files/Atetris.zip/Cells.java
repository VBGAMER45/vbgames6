/*
				Written by:  Steven Bokser
				Contact:  slavenka@hotmail.com
	
	Use this code as you will as long as this comment is present.
*/

/*
	Class Cells holds coordinate of a cell and number of cells
 	at the same level to its right
*/


public class Cells
{
    public int row, col, count;

    public Cells( int x, int y, int count )
    {
        this.row = x;
        this.col = y;
        this.count = count;
    }
}