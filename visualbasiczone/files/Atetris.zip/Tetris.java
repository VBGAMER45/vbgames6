/*
				Written by:  Steven Bokser
				Contact:  slavenka@hotmail.com
	
	Use this code as you will as long as this comment is present.
*/

/*
	This is class Tetris. It is responsible for creating
	and displaying playing field inside an applet.

	It has a thread for updating a scoreboard.

	Also, it provides a function startNewGame() but I 
	included it for purposes of communicating with JavaScript
	code located inside HTML file.
*/

import java.applet.Applet;
import java.awt.Color;
import java.awt.Label;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;


public class Tetris extends Applet implements Runnable
{
    PlayingField pf = new PlayingField();
    Label scoreBoard = new Label( "0    " );
    Label level      = new Label( "0 " );
    public boolean firstTime = true;  // First time the applet his game over status
    Thread updateScoreboardThread = null;

    public void init()
    {
        setBackground( Color.white.darker() );
        scoreBoard.setFont( new Font( "Courier", Font.BOLD, 16 ) );
        scoreBoard.setForeground( Color.blue );
        level.setFont( new Font( "Courier", Font.BOLD, 16 ) );
        level.setForeground( Color.blue );
        add( new Label( "Score:" ) );
        add( scoreBoard );
        add( new Label( "Level:" ) );
        add( level );
        add( pf );
    }

    public void run()
    {
        while ( true ) {
            scoreBoard.setText( Integer.toString( pf.getScore() ) );
            level.setText( Integer.toString( pf.getLevel() ) );
            if ( firstTime ) {
                if ( pf.gameOver() ) {   
                    displayGameOver();
                    firstTime = false;
                }
            }

            try {
                Thread.currentThread().sleep( 500 );
            }
            catch( InterruptedException e )
            {
                ;
            }
        }
    }


    public void paint( Graphics g )
    {
        if ( pf.gameOver() )    displayGameOver();
    }

 
    public void displayGameOver()
    {
        Graphics g = pf.getGraphics();
        g.setFont( new Font( "Arial", Font.BOLD, 20 ) );
        FontMetrics fm = g.getFontMetrics();
        String msg = "GAME OVER!";
        int h = pf.getSize().height, w = pf.getSize().width;
        int anchorX = ((w / 2) - (fm.stringWidth( msg ) / 2)) - 25,
            anchorY = ((h / 2) - (fm.getHeight() / 2)) - 25;
        g.setColor( Color.yellow );
        g.fill3DRect( anchorX, anchorY, fm.stringWidth( msg ) + 50, fm.getHeight() + 50, false );
        g.setColor( Color.black );
        g.drawString( msg, anchorX + 25, anchorY + 25 + fm.getHeight() );
        g.dispose();
    }


    /*
        This method only calls startNewGame() in PlayingField.
        It is included only for purposes of being able to call
        it from JavaScript code.
    */
    public boolean startNewGame()
    {
        pf.startNewGame();
        updateScoreboardThread = new Thread( this );
        updateScoreboardThread.start();
        return true;
    }

} 