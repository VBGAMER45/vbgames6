/*
				Written by:  Steven Bokser
				Contact:  slavenka@hotmail.com
	
	Use this code as you will as long as this comment is present.
*/

/*
	Defines a figure shaped like this
			 	 _______
				|_|_|_|_|
				|_|

*/



import java.awt.Graphics;
import java.awt.Color;


public class LShape 
    extends Shape
{
    
    /*
        Color of this shape. Feel free to change it.
    */
    public static final Color MY_COLOR = new Color( Color.green.getRGB() );


    /*
        Public constructor
    */
    public LShape( PlayingField pf )
    {
        super( pf );
    }


    /*
    	Return a color of this figure
    */
    public Color getShapeColor()
    {
        return new Color( MY_COLOR.getRGB() );
    }


    /*
    	Return the coordinate of the lowest cell occupied by this fugure
        and a number of cells at same level to its right
    */
    public Cells getLowestCell()
    {
        int cellW = playingField.getCellWidth(),
            cellH = playingField.getCellHeight();
        
        if      ( curPos == TWELVE_OCLOCK )  return new Cells( row + 1, col, 1 );
        else if ( curPos == THREE_OCLOCK )   return new Cells( row + 2, col + 1, 1 );
        else if ( curPos == SIX_OCLOCK )     return new Cells( row + 1, col, 3 );
        else if ( curPos == NINE_OCLOCK )    return new Cells( row + 2, col, 2 );

        return null;	
    }   


    /*
        Return all filled cells
    */
    public FilledCells getFilledCells() 
    {
        int length = 4;
        int cells[][] = new int[length][2];	// Coordinates of the filled cells

        if ( curPos == TWELVE_OCLOCK ) {
            cells[0][0] = row;
            cells[0][1] = col;
            cells[1][0] = row;
            cells[1][1] = col + 1;
            cells[2][0] = row;
            cells[2][1] = col + 2;
            cells[3][0] = row + 1;
            cells[3][1] = col;
        } 
        else if ( curPos == THREE_OCLOCK ) {
            cells[0][0] = row;
            cells[0][1] = col;
            cells[1][0] = row;
            cells[1][1] = col + 1;
            cells[2][0] = row + 1;
            cells[2][1] = col + 1;
            cells[3][0] = row + 2;
            cells[3][1] = col + 1;
        }
        else if ( curPos == SIX_OCLOCK ) {
            cells[0][0] = row;
            cells[0][1] = col + 2;
            cells[1][0] = row + 1;
            cells[1][1] = col;
            cells[2][0] = row + 1;
            cells[2][1] = col + 1;
            cells[3][0] = row + 1;
            cells[3][1] = col + 2;
        }
        else if ( curPos == NINE_OCLOCK ) {
            cells[0][0] = row;
            cells[0][1] = col;
            cells[1][0] = row + 1;
            cells[1][1] = col;
            cells[2][0] = row + 2;
            cells[2][1] = col;
            cells[3][0] = row + 2;
            cells[3][1] = col + 1;
        }

        return new FilledCells( length, cells );
    }
}