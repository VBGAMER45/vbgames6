/*
				Written by:  Steven Bokser
				Contact:  slavenka@hotmail.com
	
	Use this code as you will as long as this comment is present.
*/

/*
        This file defines class PlayingField which is an extension of
        Canvas component. Its responsibilities are:

			(1) Listen to keyPressed event and carry out one
                            of the following actions depending on a key:
              
                                       a. Move figure to left or right
                                       b. Rotate the figure
                                       c. Drop the figure
 
			(2) Track filled cells and rows. If a whole row 
                            has been filled up, eliminate it.

			(3) Check that the height of the pile does not exceed
                            the limit.

			(4) Check when a figure has hit the bottom.
*/

/*
	It is very straightforward to define your own, custom shapes. You can
        add as many as you want. 

	The steps are:
		
 		(1) Write your own class that extends Shape.
                (2) Make sure that your custom class defines
                    three methods: 

	                                    public void getShapeColor()

                    This method just returns the color you want the shape painted.
         
					    public Cells getLowestCell()

     		    This method returns the lowest cell for the current position of
                    the shape and the number of cells at the same level including this one.

                                            public FilledCells getFilledCells()

                    This method returns all filled cells for the current position.

    		(3) In the pickShape() method of the PlayingField class, add the name
                    of your custom class to the shapes[] array. Now, just add a line
                    to the 'if' block like this:
 
		      else if ( curPos == NEXTNUMBERINSEQUENCE )    return YOURCLASSNAME( this );
  
                    where the NEXTNUMBERINSEQUENCE is the number from the previous 'else if'
                    statement. and YOURCLASSNAME is the name of the class file containing the
                    shape.

	That's it. Now just test the game to make sure that the cells are in right places and
        if they're not then it means that you made a mistake in 'getFilledCells()' method, so 
        just go back and check.				
*/



import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.*;


public class PlayingField 
    extends Canvas
    implements Runnable
{

//*********************************** Variables ************************************************

    /*
        Some useful constants
    */
    public static final int POINTS_LAND = 10;		// Points for landing a figure
    public static final int POINTS_PER_ROW = 500;  // Points for filling up one row
    public static final int POINTS_PER_FOUR_ROWS = 3000;  // Points for filling up four rows in a row
   

    /*
        Speeds for each level in milliseconds. There are thirteen levels.
    */
    public final static int levelSpeeds[] = { 900, 800, 700, 600, 500, 450, 400, 350, 
                                              300, 250, 200, 150, 100, 80 };  

    /*
    	Rows and Columns to divide playing field into.
        You can change it to make playing field be able to 
        contain more figures or less. 
       
        NOTE: These should be set before the game starts by calling 
              setDimensions() method.
     
	DEFAULT SETTINGS ARE: rows = 20, cols = 10
    */
    protected int rows;
    protected int cols;


    /*
    	Width and height of each cell.
    */
    protected int cellW;
    protected int cellH;    	
  
    
    /*
    	Array of cells holding boolean values. A value of true
    	indicates that a cell is filled.
    */
    protected boolean cells[][];


    /*
        Array to hold the color of each cell to enable correct repainting
    */
    protected Color cellColors[][];


    /*
        Number of points scored
    */
    protected int score;


    /*
        Current shape
    */
    protected Shape sh = null;


    /*
        Thread on which the game will be played
    */
    protected Thread gameThread = null;


    /*
        Current level
    */
    private int level;        


    /*
        Number of milliseconds to pause gameThread
    */
    int milliseconds = 10;


    /*
        Cheat code
    */
    private String cheatCode;

//*********************************** Methods ***************************************************
    
    /*
    	Public constructor
    */
    public PlayingField()
    {
        setBackground( Color.black ); 
        setDimensions( 20, 10 );	// Set default dimensions
        cellW = 200 / 10;
        cellH = 400 / 20;
        addKeyListener( new PlayingFieldKeyListener() );
    }


    /*
    	Set all cells to empty
    */
    private void resetCells()
    {
        for ( int x = 0; x < rows; x++ ) { 
            for ( int y = 0; y < cols; y++ ) { 
                cells[x][y] = false;
                cellColors[x][y] = Color.black;
            }
        }
    }


    /*
    	Returns true if at least one column in a playing field 
        has been filled up
    */
    public boolean gameOver()
    {
        int c;     // Current column
        for ( c = 0; c < cols; c++ ) 
            if ( cells[0][c] )    return true;
        return false;
    }


    /*
    	Returns true if shape cannot move down any further
    */
    public boolean hitBottom( Shape s)
    {
        FilledCells f = s.getFilledCells();
        Cells l  = s.getLowestCell();

        // If the figure has hit the bottom of the playing field
        if ( l.row >= rows - 1 ) {
            fillCells( f );
            checkRowsForCompletion();
            return true;
        }

        // If the figure is on top of a filled cell
        for ( int x = 0; x < f.length; x++ ) {       
            if ( cells[f.cells[x][0] + 1][f.cells[x][1]] == true ) {
                fillCells( f );
                checkRowsForCompletion();
                return true;
            }
        }

        return false;	// Haven't hit the bottom yet
    }


    /*
        Check if the figure is occupying an already filled cell
    */
    public boolean isInvading( FilledCells fc )
    {
        // Check that the figure does not move into a filled cell
        for ( int r = 0; r < rows; r++ ) 
            for ( int c = 0; c < cols; c++ ) 
                if ( cells[r][c] == true ) 
                    for ( int x = 0; x < fc.length; x++ ) 
                        if ( fc.cells[x][0] == r && fc.cells[x][1] == c )
                            return true;  
        
        // Check that the figure does not go below last row
        for ( int a = 0; a < fc.length; a++ )
            if ( fc.cells[a][0] >= rows )
                return true;

        return false;
    }
        

    /*
        Check if the figure is out of bounds horizontaly
    */
    public boolean outOfBounds( FilledCells fc ) 
    {
        for ( int x = 0; x < fc.length; x++ ) 
            if ( fc.cells[x][1] < 0 || fc.cells[x][1] >= cols )
                return true;
        return false;      
    }
  

    /*
    	Return width of each cell
    */
    public int getCellWidth() 
    {
        return cellW;    
    }


    /*
        Return height of each cell
    */
    public int getCellHeight()
    {
        return cellH;
    }


    /* 
        Returns number of rows
    */
    public int getNumberOfRows()
    {
        return rows;
    }


    /*
        Returns number of columns
    */
    public int getNumberOfColumns()
    {
        return cols;
    }


    /*
    	Set how many rows and columns playing field will have
    */
    public void setDimensions( int r, int c )
    {
        rows = r;
        cols = c;
        cells = new boolean[rows][cols];
        cellColors = new Color[rows][cols];
        resetCells();
    }
        
    
    /*
        Overridden getPreferredSize() method
    */
    public Dimension getPreferredSize()
    {
        return new Dimension( 200, 400 );
    }

 
    /*
        Randomly pick the shape
    */
    public Shape pickShape()
    {
        String shapes[] = { "LShape", "StickShape", "StairShape", "BackwardStairShape", 
                            "CubeShape", "TShape", "BackwardLShape" };
        int numShapes = shapes.length;
        int pickedShape = (int)(Math.random() * numShapes);
        //((Applet)getParent()).showStatus( "Random number is: " + pickedShape );
            
        if      ( pickedShape == 0 )    return new LShape( this );
        else if ( pickedShape == 1 )	return new StickShape( this );
        else if ( pickedShape == 2 )    return new StairShape( this );
        else if ( pickedShape == 3 )    return new BackwardStairShape( this );
        else if ( pickedShape == 4 )    return new CubeShape( this );
        else if ( pickedShape == 5 )    return new TShape( this );
        else if ( pickedShape == 6 )    return new BackwardLShape( this );

        return null;
    }

 
    /*
        Start the game
    */
    public void startNewGame()
    {
        score = 0;
        level = 0;
        cheatCode = "";
        resetCells();	// All cells are empty initially
        Graphics g = getGraphics();
        g.setColor( getBackground() );
        g.fillRect( 0, 0, getSize().width - 1, getSize().height - 1 );
        g.dispose();
        gameThread = null;
        gameThread = new Thread( this );
        gameThread.start();
    }


    /*
    	Game loop
    */
    public void run()
    {
        Cells lowestCell = null;

	while( !gameOver() ) {
            sh = null;
            sh = pickShape();               
            sh.setCoords( 0, cols / 2 );
            sh.draw();
            milliseconds = levelSpeeds[level];
            while( !hitBottom( sh ) ) {
                sh.erasePreviousFigure( sh.getFilledCells() );	// Erase previous instance
                sh.advance();
       		sh.draw();		// Paint new instance   
                pauseGame( milliseconds );	// Wait before dropping one more level
            }
            score += POINTS_LAND;
            checkLevel();
        }
    }
          

    public void fillCells( FilledCells fc )
    {
        if ( fc == null )    return;
        for ( int x = 0; x < fc.length; x++ ) {
            cells[fc.cells[x][0]][fc.cells[x][1]] = true; 
            cellColors[fc.cells[x][0]][fc.cells[x][1]] = sh.getShapeColor();
        }
    }


    public void paint( Graphics g )
    {
        for ( int r = 0; r < rows; r++ ) {
            for ( int c = 0; c < cols; c++ ) {
                if ( cells[r][c] ) {
                    g.setColor( cellColors[r][c]  );
                    paintCell( g, r, c );
                }
            }
        }
    }


    public void paintCell( Graphics g, int cellRow, int cellCol )
    {
        if ( g != null ) 
            g.fill3DRect( cellCol * cellW, cellRow * cellH, cellW - 1, cellH - 1, true ); 
    }


    /*
        Listens to keyboard events generated by the player and responds
        to them accordingly
    */
    class PlayingFieldKeyListener extends KeyAdapter
    {
        public void keyPressed( KeyEvent e )
        {
            if ( sh == null || milliseconds == 10 ) {
                e.consume();
                return;
            }

            int keyCode = e.getKeyCode();
            
            switch ( keyCode ) { 
         	case( 37 ): 		// Left key 
                    sh.erasePreviousFigure( sh.getFilledCells() );
                    sh.setCoords( sh.getRow(), sh.getColumn() - 1 );
                    sh.draw();
                    break;
                case( 38 ):	 	// Up key
                    sh.erasePreviousFigure( sh.getFilledCells() );
                    sh.rotate(); 
                    sh.draw();
                    break;
                case( 39 ):		// Right key
                    sh.erasePreviousFigure( sh.getFilledCells() );
                    sh.setCoords( sh.getRow(), sh.getColumn() + 1 );
                    sh.draw();
                    break;
                case( 40 ):	       	// Down key
                    milliseconds = 10; 
                    break;
                default:
                    cheatCode += e.getKeyChar();
                    if ( cheatCode.equals( "lev6" ) )     score = 42000;
                    if ( cheatCode.length() >= 4 )         cheatCode = "";
                    break;
            }
        }
    }

    
    /*
        Pause game thread for specified number of milliseconds
    */    
    public void pauseGame( int millis )
    { 
        try {
            gameThread.sleep( millis );
        }
        catch ( InterruptedException e ) {;}
    }


    /*
        Returns the score
    */
    public int getScore()
    {
        return score;
    }
 

    /*
        Check if any rows have been completely filled and remove them
    */
    private synchronized void checkRowsForCompletion()
    {
        int firstCompletedRow = - 1, lastCompletedRow = -1;

        for ( int r = 0; r < rows; r++ ) {
            boolean rowCompleted = true;	// Assume the current row is completed
            for ( int c = 0; c < cols; c++ ) {
                if ( cells[r][c] == false )    
                    rowCompleted = false;
            }
            if ( rowCompleted ) {
                if ( firstCompletedRow == -1 ) 
                    firstCompletedRow = lastCompletedRow = r;
 		else
                    lastCompletedRow = r;
	    }
        }
        if ( firstCompletedRow != - 1 ) {
            removeRows( firstCompletedRow, lastCompletedRow ); 

            int completedRows = lastCompletedRow - firstCompletedRow + 1;

            if ( completedRows < 4 )      score += (completedRows * POINTS_PER_ROW);
            else if ( completedRows == 4 )  score += POINTS_PER_FOUR_ROWS;
        }
    }

    
    /*
       Remove rows specified by startRow and endRow 
    */
    private void removeRows( int startRow, int endRow )
    {

        for ( int r = startRow; r <= endRow; r++ ) {

	    // Empty this row
            for ( int c = 0; c < cols; c++ ) {
                cells[r][c] = false;
            }
            
        
	    // Move all rows on top one level down
            for ( int x = r - 1; x >= 0; x-- ) {
                for ( int y = 0; y < cols; y++ ) {
                    cells[x + 1][y] = cells[x][y];
                    cellColors[x + 1][y] = new Color( cellColors[x][y].getRGB() );
                    cells[x][y] = false;
                }
            }
        }
        repaint();	// Paint new layout
    }
               

    /*
        Method that checks if it's time to advance to the next level
    */
    private void checkLevel() 
    {
        int pts = 7000;	// Points needed to advance to next level

        for ( int x = 13; x >= 0; x-- ) {
            if ( score >= x * pts ) {   
                level = x;
                return;
            }
        }               
    }


    /*
        Set level
    */
    public void setLevel( int l )
    {
        level = (l >= 0 && l < 13) ? l : level;
    }


    /*
        Return current level
    */
    public int getLevel()
    {
        return level;
    }

}      
