// ColorListBox.cpp : implementation file
//

#include "stdafx.h"
#include "ColorListBox.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CColorListBox::CColorListBox()
{
	m_nHighlight		= HIGHLIGHT_ROW;
	m_nSelected			= 0;
	m_crBackGround		= RGB(0,0,0);
	m_crText			= RGB(0,255,0);
	m_crTextHighlight	= RGB(0,255,0);
	m_crHighlight		= RGB(0,0,255);
	m_crTextSelected	= RGB(255,255,255);
}

CColorListBox::~CColorListBox()
{
}

/////////////////////////////////////////////////////////////////////////////
// CColorListBox

BEGIN_MESSAGE_MAP(CColorListBox, CListBox)
	//{{AFX_MSG_MAP(CColorListBox)
	ON_WM_LBUTTONDBLCLK()
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CColorListBox message handlers

void CColorListBox::AddEntry(char *label, COLORREF color, int nIndex /* 0 */)
{
	int index = InsertString(nIndex, label);
	SetItemData(index,color);
}

void CColorListBox::MeasureItem(LPMEASUREITEMSTRUCT lpMIS)
{
// all items are of fixed size
// must use LBS_OWNERDRAWVARIABLE for this to work

	int nItem = lpMIS->itemID;
	CPaintDC dc(this);
	CString sLabel;
	CRect rcLabel;

	GetText( nItem, sLabel );
	GetItemRect(nItem, rcLabel);

// Using the flags below, calculate the required rectangle for 
// the text and set the item height for this specific item based
// on the return value (new height).

	int itemHeight = dc.DrawText( sLabel, -1, rcLabel, DT_WORDBREAK | DT_CALCRECT );
	lpMIS->itemHeight = itemHeight;
}

void CColorListBox::DrawItem(LPDRAWITEMSTRUCT lpDIS)
{
	CDC* pDC = CDC::FromHandle(lpDIS->hDC);

	CString sLabel;
	GetText(lpDIS->itemID, sLabel);

	// item selected
	if ((lpDIS->itemState & ODS_SELECTED) &&
		(lpDIS->itemAction & (ODA_SELECT | ODA_DRAWENTIRE)))
	{
		// draw color box
		CBrush colorBrush(m_crHighlight);
		CRect colorRect = lpDIS->rcItem;

		// draw label background
		CBrush labelBrush(m_crHighlight);
		CRect labelRect = lpDIS->rcItem;
		pDC->FillRect(&labelRect,&labelBrush);

		// draw label text
		COLORREF colorTextSave;
		COLORREF colorBkSave;

		if(lpDIS->itemID == m_nSelected)
			colorTextSave = pDC->SetTextColor(m_crTextSelected);
		else
			colorTextSave = pDC->SetTextColor(m_crTextHighlight);
		
		colorBkSave = pDC->SetBkColor(m_crHighlight);
		pDC->DrawText( sLabel, -1, &lpDIS->rcItem, DT_WORDBREAK );

		pDC->SetTextColor(colorTextSave);
		pDC->SetBkColor(colorBkSave);

		return;
	}

	// item brought into box
	if (lpDIS->itemAction & ODA_DRAWENTIRE)
	{
		CBrush brush(m_crBackGround);
		CRect rect = lpDIS->rcItem;
		pDC->SetTextColor(m_crText);
		pDC->SetBkColor(m_crBackGround);
		pDC->FillRect(&rect,&brush);
		pDC->DrawText( sLabel, -1, &lpDIS->rcItem, DT_WORDBREAK );

		return;
	}

	// item deselected
	if (!(lpDIS->itemState & ODS_SELECTED) &&
		(lpDIS->itemAction & ODA_SELECT))
	{
		CRect rect = lpDIS->rcItem;
		CBrush brush(m_crBackGround);
		pDC->SetBkColor(m_crBackGround);
		pDC->SetTextColor(m_crText);
		pDC->FillRect(&rect,&brush);
		pDC->DrawText( sLabel, -1, &lpDIS->rcItem, DT_WORDBREAK );

		return;
	}
	
}

void CColorListBox::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	m_nSelected = GetCurSel();
	Invalidate();	
	CListBox::OnLButtonDblClk(nFlags, point);
}

BOOL CColorListBox::OnEraseBkgnd(CDC* pDC) 
{
	CRect rcClient;
	GetClientRect(&rcClient);
	pDC->FillSolidRect(&rcClient,m_crBackGround);	
	return TRUE;
}
