// TitlebarMap.cpp: implementation of the CTitlebarMap class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Winamp UI.h"
#include "TitlebarMap.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTitlebarMap::CTitlebarMap()
{
	m_ImageMap[0].SetRect(27, 0, 302, 15);	//TitleBar
	m_ImageMap[1].SetRect(27, 15, 302, 30);	//Inactive TitleBar
	m_ImageMap[2].SetRect(27, 29, 302, 43);	//TitleBar Windowshade
	m_ImageMap[3].SetRect(27, 42, 302, 56);	//Inactive TitleBar Windowshade
	m_ImageMap[4].SetRect(27, 57, 302, 72);	//TitleBar Alternate
	m_ImageMap[5].SetRect(27, 72, 302, 87);	//Inactive TitleBar Alternate
}

CTitlebarMap::~CTitlebarMap()
{

}
