// EQMap.h: interface for the CEQMap class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EQMAP_H__41AA4B20_20C2_11D3_8F2D_CCFD02A4AE5A__INCLUDED_)
#define AFX_EQMAP_H__41AA4B20_20C2_11D3_8F2D_CCFD02A4AE5A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#define MAIN				0
#define TITLEBAR			1
#define INACTIVE_TITLEBAR	2
#define PREAMP_BAR			3
#define ON					4
#define ON_PRESSED			5
#define ON_INACTIVE			6
#define AUTO				7
#define AUTO_PRESSED		8
#define AUTO_INACTIVE		9
#define EQ_BAR_1			10
#define EQ_BAR_2			11
#define EQ_BAR_3			12
#define EQ_BAR_4			13
#define EQ_BAR_5			14
#define EQ_BAR_6			15
#define EQ_BAR_7			16
#define EQ_BAR_8			17
#define EQ_BAR_9			18
#define EQ_BAR_10			19
#define EQ_BAR_11			20
#define EQ_BAR_12			21
#define EQ_BAR_13			22
#define EQ_BAR_14			23
#define EQ_BAR_15			24
#define EQ_BAR_16			25
#define EQ_BAR_17			26
#define EQ_BAR_18			27
#define EQ_BAR_19			28
#define EQ_BAR_20			29
#define EQ_BAR_21			30
#define EQ_BAR_22			31
#define EQ_BAR_23			32
#define EQ_BAR_24			33
#define EQ_BAR_25			34
#define EQ_BAR_26			35
#define EQ_BAR_27			36
#define EQ_BAR_28			37
#define CLOSE				38
#define CLOSE_PRESSED		39
#define SLIDER				40
#define SLIDER_PRESSED		41
#define PRESET				42
#define PRESET_PRESSED		43

#include "imagemap.h"

class CEQMap : public CImageMap
{
public:
	CEQMap();
	virtual ~CEQMap();

};

#endif // !defined(AFX_EQMAP_H__41AA4B20_20C2_11D3_8F2D_CCFD02A4AE5A__INCLUDED_)
