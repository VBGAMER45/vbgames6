******************************
* Winamp User Interface Development *
******************************

Release 0.1 21st July 1999
======================

Tested on Windows 98, Windows NT 4 & 5
Compiles well in VC++ 5 & 6
Tested for memory leaks with Rational Purify 6

Known Issues 
---------------
Everything except the minibrowser is NOT completed so don't look too closely at that code. The minibrowser is completed as far as I know with the following caveats:-

- The browser window (IE3/4  IWebBrowser2) embedded in the minibrowser is embedded incorrectly. If you click in the browser, the minibrowser loses focus. Also the browser window appears on top of the minibrowser so you can see the edges of it.

- The bitmap rendering is flickering horribly, and is far too slow. Any suggestions would be most welcome on this subject from you GDI masters out there.

- I have only coded the docking for the left edge of the minibrowser against the right edge of the main window. If anyone has a better way of doing it than the way I have suggested then please let me know becuase it looks to me that I am going to need a ton of code to finish it completely for each window.

- The loading of skins from disk is supported but only for 256 colour bitmaps and only in the Skins sub-directory of the executable. It is obviously fairly easy to change that but I have other things to fix first.

- The 'Update Links' menu option doesn't do anything because it needs some winsock code which is a bit beyond the scope of this project.

- The 'Open Location' dialog box doesn't have an icon in the corner at the moment. Does anyone know how to do this?

But apart from all that there are no other problems (as if those weren't bad enough).

As always, comments suggestions, bug fixes etc should be pointed at the website or the mailing list

Web Site
---------

http://lyme.virtualave.net/winampui/index.htm

Mailing List
------------
http://www.onelist.com to join. 

Look for a list named 'winampui' or follow the link from my web site.

Email me direct at spib@bigfoot.com

Cheers

James