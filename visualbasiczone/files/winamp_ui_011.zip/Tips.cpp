// Tips.cpp : implementation file
//

#include "stdafx.h"
#include "Winamp UI.h"
#include "Tips.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTips property page

IMPLEMENT_DYNCREATE(CTips, CPropertyPage)

CTips::CTips() : CPropertyPage(CTips::IDD)
{
	//{{AFX_DATA_INIT(CTips)
	m_strTips = _T("");
	//}}AFX_DATA_INIT
}

CTips::~CTips()
{
}

void CTips::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTips)
	DDX_Text(pDX, IDC_TIPS, m_strTips);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTips, CPropertyPage)
	//{{AFX_MSG_MAP(CTips)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTips message handlers
