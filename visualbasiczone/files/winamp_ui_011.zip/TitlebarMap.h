// TitlebarMap.h: interface for the CTitlebarMap class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TITLEBARMAP_H__37A7B1A1_3CF4_11D3_8F2D_C8A9236E6462__INCLUDED_)
#define AFX_TITLEBARMAP_H__37A7B1A1_3CF4_11D3_8F2D_C8A9236E6462__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define ACTIVE					0
#define INACTIVE				1
#define WINDOWSHADE				2
#define INACTIVE_WINDOWSHADE	3
#define ACTIVE_ALTERNATE		4
#define INACTIVE_ALTERNATE		5

#include "ImageMap.h"

class CTitlebarMap : public CImageMap  
{
public:
	CTitlebarMap();
	virtual ~CTitlebarMap();

};

#endif // !defined(AFX_TITLEBARMAP_H__37A7B1A1_3CF4_11D3_8F2D_C8A9236E6462__INCLUDED_)
