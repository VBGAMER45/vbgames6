// PEMap.h: interface for the CPEMap class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PEMAP_H__37A7B1A0_3CF4_11D3_8F2D_C8A9236E6462__INCLUDED_)
#define AFX_PEMAP_H__37A7B1A0_3CF4_11D3_8F2D_C8A9236E6462__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define TITLEBAR_LEFT_CORNER			0
#define TITLEBAR_MIDDLE					1
#define TITLEBAR_FILL					2
#define TITLEBAR_RIGHT_CORNER			3
#define INACTIVE_TITLEBAR_LEFT_CORNER	4
#define INACTIVE_TITLEBAR_MIDDLE		5
#define INACTIVE_TITLEBAR_FILL			6
#define INACTIVE_TITLEBAR_RIGHT_CORNER	7
#define BOTTOM_LEFT						8
#define BOTTOM_RIGHT					9
#define BOTTOM_FILL						10
#define LEFT_EDGE						11
#define RIGHT_EDGE						12

#include "ImageMap.h"

class CPEMap : public CImageMap  
{
public:
	CPEMap();
	virtual ~CPEMap();

};

#endif // !defined(AFX_PEMAP_H__37A7B1A0_3CF4_11D3_8F2D_C8A9236E6462__INCLUDED_)
