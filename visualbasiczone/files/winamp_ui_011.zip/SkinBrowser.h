#if !defined(AFX_SKINBROWSER_H__A826CE91_40F5_11D3_A8BB_0050043A01C0__INCLUDED_)
#define AFX_SKINBROWSER_H__A826CE91_40F5_11D3_A8BB_0050043A01C0__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// SkinBrowser.h : header file
//

#include "SkinManager.h"
#include "DirDialog.h"
/////////////////////////////////////////////////////////////////////////////
// CSkinBrowser dialog

class CSkinBrowser : public CDialog
{
// Construction
public:
	CSkinBrowser(CWnd* pParent = NULL);   // standard constructor
	CSkinManager	m_manager;

// Dialog Data
	//{{AFX_DATA(CSkinBrowser)
	enum { IDD = IDD_SKIN_BROWSER };
	CListBox	m_List;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSkinBrowser)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	// Generated message map functions
	//{{AFX_MSG(CSkinBrowser)
	virtual BOOL OnInitDialog();
	afx_msg void OnDownload();
	afx_msg void OnSetskinsdir();
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SKINBROWSER_H__A826CE91_40F5_11D3_A8BB_0050043A01C0__INCLUDED_)
