#if !defined(AFX_WINAMPABOUTDLG_H__5A0DD908_3D3E_11D3_8F2D_BBF880D09861__INCLUDED_)
#define AFX_WINAMPABOUTDLG_H__5A0DD908_3D3E_11D3_8F2D_BBF880D09861__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WinampAboutDlg.h : header file
//

#include "Credits.h"
#include "Links.h"
#include "Shareware.h"
#include "Tips.h"
#include "WinampAbout.h"
/////////////////////////////////////////////////////////////////////////////
// CWinampAboutDlg

class CWinampAboutDlg : public CPropertySheet
{
	DECLARE_DYNAMIC(CWinampAboutDlg)

// Construction
public:
	CWinampAboutDlg(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	CWinampAboutDlg(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);

// Attributes
public:	
	CCredits		m_Credits;
	CLinks			m_Links;
	CShareware		m_Shareware;
	CTips			m_Tips;
	CWinampAbout	m_About;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWinampAboutDlg)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CWinampAboutDlg();

	// Generated message map functions
protected:
	//{{AFX_MSG(CWinampAboutDlg)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WINAMPABOUTDLG_H__5A0DD908_3D3E_11D3_8F2D_BBF880D09861__INCLUDED_)
