// Credits.cpp : implementation file
//

#include "stdafx.h"
#include "Winamp UI.h"
#include "Credits.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCredits property page

IMPLEMENT_DYNCREATE(CCredits, CPropertyPage)

CCredits::CCredits() : CPropertyPage(CCredits::IDD)
{
	//{{AFX_DATA_INIT(CCredits)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CCredits::~CCredits()
{
}

void CCredits::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCredits)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCredits, CPropertyPage)
	//{{AFX_MSG_MAP(CCredits)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCredits message handlers
