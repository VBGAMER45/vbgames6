// AboutDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Winamp UI.h"
#include "AboutDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg

IMPLEMENT_DYNAMIC(CAboutDlg, CPropertySheet)

CAboutDlg::CAboutDlg(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
/*	AddPage(&m_About);
	AddPage(&m_Credits);
	AddPage(&m_Shareware);
	AddPage(&m_Tips);
	AddPage(&m_Links);*/
}

CAboutDlg::CAboutDlg(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
}

CAboutDlg::~CAboutDlg()
{
}


BEGIN_MESSAGE_MAP(CAboutDlg, CPropertySheet)
	//{{AFX_MSG_MAP(CAboutDlg)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg message handlers
