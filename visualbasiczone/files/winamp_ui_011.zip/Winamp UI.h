// Winamp UI.h : main header file for the WINAMP UI application
//

#if !defined(AFX_WINAMPUI_H__E55696D8_382C_11D3_B660_00C04F6801E7__INCLUDED_)
#define AFX_WINAMPUI_H__E55696D8_382C_11D3_B660_00C04F6801E7__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

#include "WinampMainWnd.h"

/////////////////////////////////////////////////////////////////////////////
// CWinampUIApp:
// See Winamp UI.cpp for the implementation of this class
//

class CWinampUIApp : public CWinApp
{
public:
	CWinampUIApp();




// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWinampUIApp)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CWinampUIApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WINAMPUI_H__E55696D8_382C_11D3_B660_00C04F6801E7__INCLUDED_)
