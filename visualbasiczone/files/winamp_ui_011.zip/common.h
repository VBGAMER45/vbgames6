#define SNAP_SIZE	10
#define SNAP_OFFSET	10
#define WM_DOCKED		WM_USER + 10
