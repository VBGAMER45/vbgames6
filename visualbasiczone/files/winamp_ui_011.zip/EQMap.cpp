// EQMap.cpp: implementation of the CEQMap class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "EQMap.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define WAVEWIN_XPOS				90
#define WAVEWIN_YPOS				20
#define WAVEWIN_LEFT				0
#define WAVEWIN_TOP					294
#define WAVEWIN_WIDTH				113
#define WAVEWIN_HEIGHT				19

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CEQMap::CEQMap()
{
	m_ImageMap[0].SetRect(0, 0, 275, 116);		//Main Bitmap

	m_ImageMap[1].SetRect(0, 134, 275, 148);	//TitleBar
	m_ImageMap[2].SetRect(0, 149, 275, 163);	//Inactive TitleBar

	m_ImageMap[3].SetRect(13, 164, 27, 224);	//Preamp Bar

	m_ImageMap[4].SetRect(10, 119, 33, 131);	//On Button
	m_ImageMap[5].SetRect(69, 119, 92, 131);	//On Button (pressed)
	m_ImageMap[6].SetRect(128, 119, 151, 131);	//On Button (Inactive)

	m_ImageMap[7].SetRect(34, 119, 67, 131);	//Auto Button
	m_ImageMap[8].SetRect(93, 119, 126, 131);	//Auto Button (pressed)
	m_ImageMap[9].SetRect(152, 119, 185, 131);	//Auto Button (Inactive)

	m_ImageMap[10].SetRect(13, 164, 27, 228);	//EQ Bar 1
	m_ImageMap[11].SetRect(28, 164, 42, 228);	//EQ Bar 2
	m_ImageMap[12].SetRect(43, 164, 57, 228);	//EQ Bar 3
	m_ImageMap[13].SetRect(58, 164, 72, 228);	//EQ Bar 4
	m_ImageMap[14].SetRect(73, 164, 87, 228);	//EQ Bar 5
	m_ImageMap[15].SetRect(88, 164, 102, 228);	//EQ Bar 6
	m_ImageMap[16].SetRect(103, 164, 117, 228);	//EQ Bar 7
	m_ImageMap[17].SetRect(118, 164, 132, 228);	//EQ Bar 8
	m_ImageMap[18].SetRect(133, 164, 147, 228);	//EQ Bar 9
	m_ImageMap[19].SetRect(148, 164, 162, 228);	//EQ Bar 10
	m_ImageMap[20].SetRect(163, 164, 177, 228);	//EQ Bar 11
	m_ImageMap[21].SetRect(178, 164, 192, 228);	//EQ Bar 12
	m_ImageMap[22].SetRect(193, 164, 207, 228);	//EQ Bar 13
	m_ImageMap[23].SetRect(208, 164, 222, 228);	//EQ Bar 14
	m_ImageMap[24].SetRect(13, 229, 27, 293);	//EQ Bar 15
	m_ImageMap[25].SetRect(28, 229, 42, 293);	//EQ Bar 16
	m_ImageMap[26].SetRect(43, 229, 57, 293);	//EQ Bar 17
	m_ImageMap[27].SetRect(58, 229, 72, 293);	//EQ Bar 18
	m_ImageMap[28].SetRect(73, 229, 87, 293);	//EQ Bar 19
	m_ImageMap[29].SetRect(88, 229, 102, 293);	//EQ Bar 20
	m_ImageMap[30].SetRect(103, 229, 117, 293);	//EQ Bar 21
	m_ImageMap[31].SetRect(118, 229, 132, 293);	//EQ Bar 22
	m_ImageMap[32].SetRect(133, 229, 147, 293);	//EQ Bar 23
	m_ImageMap[33].SetRect(148, 229, 162, 293);	//EQ Bar 24
	m_ImageMap[34].SetRect(163, 229, 177, 293);	//EQ Bar 25
	m_ImageMap[35].SetRect(178, 229, 192, 293);	//EQ Bar 26
	m_ImageMap[36].SetRect(193, 229, 207, 293);	//EQ Bar 27
	m_ImageMap[37].SetRect(208, 229, 222, 293);	//EQ Bar 28

	m_ImageMap[38].SetRect(0, 117, 9, 125);	//Close
	m_ImageMap[39].SetRect(0, 126, 9, 133);	//Close Pressed
	m_ImageMap[40].SetRect(0, 164, 11, 175);	//Slider
	m_ImageMap[41].SetRect(0, 176, 11, 187);	//Slider Pressed
	m_ImageMap[42].SetRect(224, 164, 268, 175);	//Presets
	m_ImageMap[43].SetRect(224, 176, 268, 188);	//Presets Pressed

	/*m_InterfaceMap[0].SetRect(0, 0, 275, 116);		//Main Bitmap

	m_InterfaceMap[1].SetRect(0, 134, 275, 148);	//TitleBar
	m_InterfaceMap[2].SetRect(0, 149, 275, 163);	//Inactive TitleBar

	m_InterfaceMap[3].SetRect(13, 164, 27, 224);	//Preamp Bar

	m_InterfaceMap[4].SetRect(10, 119, 33, 131);	//On Button
	m_InterfaceMap[5].SetRect(69, 119, 92, 131);	//On Button (pressed)
	m_InterfaceMap[6].SetRect(128, 119, 151, 131);	//On Button (Inactive)

	m_InterfaceMap[7].SetRect(34, 119, 67, 131);	//Auto Button
	m_InterfaceMap[8].SetRect(93, 119, 126, 131);	//Auto Button (pressed)
	m_InterfaceMap[9].SetRect(152, 119, 185, 131);	//Auto Button (Inactive)

	m_InterfaceMap[10].SetRect(13, 164, 27, 228);	//EQ Bar 1
	m_InterfaceMap[11].SetRect(28, 164, 42, 228);	//EQ Bar 2
	m_InterfaceMap[12].SetRect(43, 164, 57, 228);	//EQ Bar 3
	m_InterfaceMap[13].SetRect(58, 164, 72, 228);	//EQ Bar 4
	m_InterfaceMap[14].SetRect(73, 164, 87, 228);	//EQ Bar 5
	m_InterfaceMap[15].SetRect(88, 164, 102, 228);	//EQ Bar 6
	m_InterfaceMap[16].SetRect(103, 164, 117, 228);	//EQ Bar 7
	m_InterfaceMap[17].SetRect(118, 164, 132, 228);	//EQ Bar 8
	m_InterfaceMap[18].SetRect(133, 164, 147, 228);	//EQ Bar 9
	m_InterfaceMap[19].SetRect(148, 164, 162, 228);	//EQ Bar 10
	m_InterfaceMap[20].SetRect(163, 164, 177, 228);	//EQ Bar 11
	m_InterfaceMap[21].SetRect(178, 164, 192, 228);	//EQ Bar 12
	m_InterfaceMap[22].SetRect(193, 164, 207, 228);	//EQ Bar 13
	m_InterfaceMap[23].SetRect(208, 164, 222, 228);	//EQ Bar 14
	m_InterfaceMap[24].SetRect(13, 229, 27, 293);	//EQ Bar 15
	m_InterfaceMap[25].SetRect(28, 229, 42, 293);	//EQ Bar 16
	m_InterfaceMap[26].SetRect(43, 229, 57, 293);	//EQ Bar 17
	m_InterfaceMap[27].SetRect(58, 229, 72, 293);	//EQ Bar 18
	m_InterfaceMap[28].SetRect(73, 229, 87, 293);	//EQ Bar 19
	m_InterfaceMap[29].SetRect(88, 229, 102, 293);	//EQ Bar 20
	m_InterfaceMap[30].SetRect(103, 229, 117, 293);	//EQ Bar 21
	m_InterfaceMap[31].SetRect(118, 229, 132, 293);	//EQ Bar 22
	m_InterfaceMap[32].SetRect(133, 229, 147, 293);	//EQ Bar 23
	m_InterfaceMap[33].SetRect(148, 229, 162, 293);	//EQ Bar 24
	m_InterfaceMap[34].SetRect(163, 229, 177, 293);	//EQ Bar 25
	m_InterfaceMap[35].SetRect(178, 229, 192, 293);	//EQ Bar 26
	m_InterfaceMap[36].SetRect(193, 229, 207, 293);	//EQ Bar 27
	m_InterfaceMap[37].SetRect(208, 229, 222, 293);	//EQ Bar 28

	m_InterfaceMap[38].SetRect(0, 117, 9, 125);	//Close
	m_InterfaceMap[39].SetRect(0, 126, 9, 133);	//Close Pressed
	m_InterfaceMap[40].SetRect(0, 164, 11, 175);	//Slider
	m_InterfaceMap[41].SetRect(0, 176, 11, 187);	//Slider Pressed
	m_InterfaceMap[42].SetRect(224, 164, 268, 175);	//Presets
	m_InterfaceMap[43].SetRect(224, 176, 268, 188);	//Presets Pressed*/
}

CEQMap::~CEQMap()
{

}
