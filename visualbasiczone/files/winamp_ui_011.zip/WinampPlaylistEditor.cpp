// WinampPlaylistEditor.cpp : implementation file
//

#include "stdafx.h"
#include "Winamp UI.h"
#include "WinampPlaylistEditor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWinampPlaylistEditor dialog


CWinampPlaylistEditor::CWinampPlaylistEditor()
{
	//{{AFX_DATA_INIT(CWinampPlaylistEditor)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_pInterface		= new CBitmapEx();
	m_bFocus			= FALSE;
	m_bDragging			= FALSE;
	m_bResizing			= FALSE;
}

CWinampPlaylistEditor::~CWinampPlaylistEditor()
{
	delete m_pInterface;
}

BEGIN_MESSAGE_MAP(CWinampPlaylistEditor, CWnd)
	//{{AFX_MSG_MAP(CWinampPlaylistEditor)
	ON_WM_CREATE()
	ON_WM_PAINT()
	ON_WM_KILLFOCUS()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_SETFOCUS()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWinampPlaylistEditor message handlers

BOOL CWinampPlaylistEditor::Create(CWnd* pParent) 
{
	CMenu menu;
	
	CString classname = AfxRegisterWndClass(CS_DBLCLKS);
	return CreateEx(WS_EX_LEFT | WS_EX_LTRREADING | WS_EX_RIGHTSCROLLBAR | WS_EX_ACCEPTFILES, 
					classname, "Winamp Playlist Editor", 
					WS_VISIBLE | WS_CLIPSIBLINGS | WS_POPUP, 
					0,0,500,500, pParent->GetSafeHwnd(), menu);
}

int CWinampPlaylistEditor::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if(!m_pInterface->LoadBitmap("Skins\\pledit.bmp"))
		m_pInterface->LoadBitmap(IDB_PLEDIT);
	
	SetWindowPos(NULL, 0, 0, 275, 116, SWP_NOACTIVATE | SWP_SHOWWINDOW);
	
	return 0;
}

void CWinampPlaylistEditor::OnPaint() 
{
	DrawInterface();	
}

void CWinampPlaylistEditor::DrawInterface(BOOL bPaint)
{
	CRect rc, rcClient, rcWnd;
	GetClientRect(&rcClient);
	GetWindowRect(&rcWnd);
	rc = rcClient;

	int bottom	= rc.bottom;
	int top		= rc.top;
	int left	= rc.left;
	int right	= rc.right;
	int height	= bottom - top;
	int width	= right - left;


	CDC* pDC = GetDC();
	pDC->FillSolidRect(rcClient, RGB(255,255,255));

	int FillsNeeded = rcWnd.Width() - (m_map.OffSet(TITLEBAR_LEFT_CORNER).Width() + m_map.OffSet(TITLEBAR_RIGHT_CORNER).Width());
	FillsNeeded = FillsNeeded / m_map.OffSet(TITLEBAR_FILL).Width();
	if(m_bFocus)
	{
		m_pInterface->Draw(FALSE, this, 0, 0, m_map.OffSet(TITLEBAR_LEFT_CORNER));
		for(int i = 0; i <= FillsNeeded; i++)
			m_pInterface->Draw(FALSE, this, m_map.OffSet(TITLEBAR_LEFT_CORNER).Width() + (m_map.OffSet(TITLEBAR_FILL).Width() * i) , 0, m_map.OffSet(TITLEBAR_FILL));

		m_pInterface->Draw(FALSE, this, (rcWnd.Width() / 2) - (m_map.OffSet(TITLEBAR_MIDDLE).Width() / 2), 0, m_map.OffSet(TITLEBAR_MIDDLE));
		m_pInterface->Draw(FALSE, this, (rcWnd.Width() - m_map.OffSet(TITLEBAR_RIGHT_CORNER).Width()), 0, m_map.OffSet(TITLEBAR_RIGHT_CORNER));
	}
	else
	{
		m_pInterface->Draw(FALSE, this, 0, 0, m_map.OffSet(INACTIVE_TITLEBAR_LEFT_CORNER));
		for(int i = 0; i <= FillsNeeded; i++)
			m_pInterface->Draw(FALSE, this, m_map.OffSet(TITLEBAR_LEFT_CORNER).Width() + (m_map.OffSet(TITLEBAR_FILL).Width() * i) , 0, m_map.OffSet(INACTIVE_TITLEBAR_FILL));

		m_pInterface->Draw(FALSE, this, (rcWnd.Width() / 2) - (m_map.OffSet(TITLEBAR_MIDDLE).Width() / 2), 0, m_map.OffSet(INACTIVE_TITLEBAR_MIDDLE));
		m_pInterface->Draw(FALSE, this, (rcWnd.Width() - m_map.OffSet(TITLEBAR_RIGHT_CORNER).Width()), 0, m_map.OffSet(INACTIVE_TITLEBAR_RIGHT_CORNER));
	}

	FillsNeeded = (height - (m_map.OffSet(TITLEBAR_LEFT_CORNER).Height() + m_map.OffSet(BOTTOM_LEFT).Height())) / m_map.OffSet(LEFT_EDGE).Height();
	int y = 0;
	for(int i = 0; i <= FillsNeeded; i++)
	{
		y = m_map.OffSet(TITLEBAR_LEFT_CORNER).Height() + (m_map.OffSet(LEFT_EDGE).Height() * i);
		m_pInterface->Draw(bPaint, this, 0, y, m_map.OffSet(LEFT_EDGE));
		m_pInterface->Draw(bPaint, this, width - m_map.OffSet(RIGHT_EDGE).Width(), y, m_map.OffSet(RIGHT_EDGE));
	}

	m_pInterface->Draw(bPaint, this, 0, height - m_map.OffSet(BOTTOM_LEFT).Height(), m_map.OffSet(BOTTOM_LEFT));
	
	FillsNeeded = (rcWnd.Width() - (m_map.OffSet(BOTTOM_LEFT).Width() + m_map.OffSet(BOTTOM_RIGHT).Width())) / m_map.OffSet(BOTTOM_FILL).Width();
	for(i = 0; i <= FillsNeeded; i++)
		m_pInterface->Draw(FALSE, this, m_map.OffSet(BOTTOM_LEFT).Width() + (m_map.OffSet(BOTTOM_FILL).Width() * i) , height - m_map.OffSet(BOTTOM_RIGHT).Height(), m_map.OffSet(BOTTOM_FILL));
	m_pInterface->Draw(bPaint, this, width - m_map.OffSet(BOTTOM_RIGHT).Width(), height - m_map.OffSet(BOTTOM_RIGHT).Height(), m_map.OffSet(BOTTOM_RIGHT));


}

void CWinampPlaylistEditor::OnKillFocus(CWnd* pNewWnd) 
{
	CWnd::OnKillFocus(pNewWnd);
	
	m_bFocus = FALSE;
	DrawInterface();	
}

void CWinampPlaylistEditor::OnSetFocus(CWnd* pOldWnd) 
{
	CWnd::OnSetFocus(pOldWnd);
	m_bFocus = TRUE;
	DrawInterface();	
}

void CWinampPlaylistEditor::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CRect rcWnd, rcTemp;
	GetClientRect(&rcWnd);

	rcTemp = rcWnd;
	rcTemp.left = rcTemp.right - 20;
	rcTemp.top = rcTemp.bottom - 20;
	

	//Resizing
	if(rcTemp.PtInRect(point))
	{
		SetCapture();
		m_bResizing = TRUE;
		m_ptResizeFrom = point;
	}

	rcTemp = rcWnd;
	rcTemp.bottom = rcTemp.top + 20;

	//Dragging
	if(rcTemp.PtInRect(point))
	{
		SetCapture();
		m_bDragging = TRUE;
		m_ptDragFrom = point;
	}

	rcTemp = rcWnd;
	rcTemp.right = rcTemp.right - 3;
	rcTemp.left = rcTemp.right - 7;
	rcTemp.top = rcTemp.top + 3;
	rcTemp.bottom = rcTemp.top + 7;

	//Close Window
	if(rcTemp.PtInRect(point))
	{
		DestroyWindow();
	}
	
	CWnd::OnLButtonDown(nFlags, point);
}

void CWinampPlaylistEditor::OnLButtonUp(UINT nFlags, CPoint point) 
{
	if(m_bResizing)
	{
		ReleaseCapture();
		m_bResizing = FALSE;
	}

	if(m_bDragging)
	{
		ReleaseCapture();
		m_bDragging = FALSE;
	}
	
	CWnd::OnLButtonUp(nFlags, point);
}

void CWinampPlaylistEditor::OnMouseMove(UINT nFlags, CPoint point) 
{
	CRect rcWnd;
	GetWindowRect(&rcWnd);

	ChooseCursor(point);

	//Fixed Resizing Code
	if(m_bResizing && nFlags & MK_LBUTTON)
	{
		//Resize in X direction outwards
		if(point.x >= (m_ptResizeFrom.x + RESIZE_WIDTH))
		{
			rcWnd.right += RESIZE_WIDTH;
			if(rcWnd.Width() >= MIN_WIDTH)
			{
				SetWindowPos(NULL, rcWnd.left, rcWnd.top, rcWnd.Width(), rcWnd.Height(), SWP_SHOWWINDOW);
				m_ptResizeFrom.x += RESIZE_WIDTH;
			}
		}
		//Resize in X direction inwards
		else if(point.x <= (m_ptResizeFrom.x - RESIZE_WIDTH))
		{
			rcWnd.right -= RESIZE_WIDTH;
			if(rcWnd.Width() >= MIN_WIDTH)
			{
				SetWindowPos(NULL, rcWnd.left, rcWnd.top, rcWnd.Width(), rcWnd.Height(), SWP_SHOWWINDOW);
				m_ptResizeFrom.x -= RESIZE_WIDTH;
			}
		}
		//Resize in Y direction downwards
		else if(point.y >= (m_ptResizeFrom.y + RESIZE_HEIGHT))
		{
			rcWnd.bottom += RESIZE_HEIGHT;
			if(rcWnd.Height() >= MIN_HEIGHT)
			{
				SetWindowPos(NULL, rcWnd.left, rcWnd.top, rcWnd.Width(), rcWnd.Height(), SWP_SHOWWINDOW);
				m_ptResizeFrom.y += RESIZE_HEIGHT;
			}
		}
		//Resize in Y direction upwards
		else if(point.y <= (m_ptResizeFrom.y - RESIZE_HEIGHT))
		{
			rcWnd.bottom -= RESIZE_HEIGHT;
			if(rcWnd.Height() >= MIN_HEIGHT)
			{
				SetWindowPos(NULL, rcWnd.left, rcWnd.top, rcWnd.Width(), rcWnd.Height(), SWP_SHOWWINDOW);
				m_ptResizeFrom.y -= RESIZE_HEIGHT;
			}
		}
	}

	if(m_bDragging && nFlags & MK_LBUTTON)
	{
		int xdiff = point.x - m_ptDragFrom.x;
		int ydiff = point.y - m_ptDragFrom.y;

		SetWindowPos(NULL, rcWnd.left + xdiff, rcWnd.top + ydiff, rcWnd.Width(), rcWnd.Height(), SWP_SHOWWINDOW);
	}	

	CWnd::OnMouseMove(nFlags, point);
}


void CWinampPlaylistEditor::ChooseCursor(CPoint point)
{
	HCURSOR hCursor;
	CRect rcWnd, rcTemp;
	GetClientRect(&rcWnd);
	
	rcTemp = rcWnd;
	rcTemp.left = rcTemp.right - 20;
	rcTemp.top = rcTemp.bottom - 20;
	if(rcTemp.PtInRect(point) || m_bResizing)
	{
		hCursor = AfxGetApp()->LoadCursor(IDC_RESIZE);
		SetCursor(hCursor);
		return;
	}

	rcTemp = rcWnd;
	rcTemp.right = rcTemp.right - 3;
	rcTemp.left = rcTemp.right - 7;
	rcTemp.top = rcTemp.top + 3;
	rcTemp.bottom = rcTemp.top + 7;
	if(rcTemp.PtInRect(point))
	{
		hCursor = AfxGetApp()->LoadCursor(IDC_CLOSE);
		SetCursor(hCursor);
		return;
	}
	
	rcTemp = rcWnd;
	rcTemp.bottom = rcTemp.top + 20;
	if(rcTemp.PtInRect(point) || m_bDragging)
	{
		hCursor = AfxGetApp()->LoadCursor(IDC_DRAG);
		SetCursor(hCursor);
		return;
	}
	
	//Default
	hCursor = AfxGetApp()->LoadCursor(IDC_DEFAULT_ARROW);
	SetCursor(hCursor);	
}

void CWinampPlaylistEditor::OnSize(UINT nType, int cx, int cy) 
{
	CWnd::OnSize(nType, cx, cy);
	
	DrawInterface();	
}
