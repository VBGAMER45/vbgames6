// MainMap.cpp: implementation of the CMainm_nCoordinates class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MainMap.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMainMap::CMainMap()
{
	m_ImageMap[0].SetRect(0, 20, 275, 116);					//Main
}

CMainMap::~CMainMap()
{

}
