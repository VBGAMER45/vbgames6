// PEMap.cpp: implementation of the CPEMap class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Winamp UI.h"
#include "PEMap.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPEMap::CPEMap()
{
	m_ImageMap[0].SetRect(0,   0, 25, 20);	//TitleBar Left Corner
	m_ImageMap[1].SetRect(26,  0, 126, 20);	//TitleBar Middle
	m_ImageMap[2].SetRect(127, 0, 152, 20);	//TitleBar Fill
	m_ImageMap[3].SetRect(153, 0, 178, 20);	//TitleBar Right Corner
	m_ImageMap[4].SetRect(0,   21, 25, 41);	//TitleBar Left Corner
	m_ImageMap[5].SetRect(26,  21, 126, 41);	//TitleBar Middle
	m_ImageMap[6].SetRect(127, 21, 152, 41);	//TitleBar Fill
	m_ImageMap[7].SetRect(153, 21, 178, 41);	//TitleBar Right Corner
	m_ImageMap[8].SetRect(0, 72, 125, 110);	//Bottom Left Corner
	m_ImageMap[9].SetRect(126, 72, 276, 110);	//Bottom rIGHT Corner
	m_ImageMap[10].SetRect(179, 0, 204, 38);	//Bottom Filler
	m_ImageMap[11].SetRect(0, 42, 25, 71);	//Left Edge
	m_ImageMap[12].SetRect(26, 42, 51, 71);	//Right Edge
}

CPEMap::~CPEMap()
{

}
