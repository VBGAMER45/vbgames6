// Links.cpp : implementation file
//

#include "stdafx.h"
#include "Winamp UI.h"
#include "Links.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLinks property page

IMPLEMENT_DYNCREATE(CLinks, CPropertyPage)

CLinks::CLinks() : CPropertyPage(CLinks::IDD)
{
	//{{AFX_DATA_INIT(CLinks)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CLinks::~CLinks()
{
}

void CLinks::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLinks)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLinks, CPropertyPage)
	//{{AFX_MSG_MAP(CLinks)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLinks message handlers
