#include "stdafx.h"
#include "common.h"
