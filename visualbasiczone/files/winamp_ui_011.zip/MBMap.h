// MBMap.h: interface for the CMBMap class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MBMAP_H__9B064CC0_388A_11D3_8F2D_E2D7E9D4B765__INCLUDED_)
#define AFX_MBMAP_H__9B064CC0_388A_11D3_8F2D_E2D7E9D4B765__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#define TITLEBAR_LEFT_CORNER			0
#define TITLEBAR_MIDDLE					1
#define TITLEBAR_FILL					2
#define TITLEBAR_RIGHT_CORNER			3
#define INACTIVE_TITLEBAR_LEFT_CORNER	4
#define INACTIVE_TITLEBAR_MIDDLE		5
#define INACTIVE_TITLEBAR_FILL			6
#define INACTIVE_TITLEBAR_RIGHT_CORNER	7
#define BOTTOM_LEFT						8
#define BOTTOM_RIGHT					9
#define BOTTOM_FILL						10
#define LEFT_EDGE						11
#define RIGHT_EDGE						12
#define CLOSE_BUTTON					13
#define BACK_DOWN						14
#define FORWARD_DOWN					15
#define STOP_DOWN						16
#define REFRESH_DOWN					17
#define OPEN_DOWN						18
#define BACK_UP							19
#define FORWARD_UP						20
#define STOP_UP							21
#define REFRESH_UP						22
#define OPEN_UP							23

#include "ImageMap.h"

class CMBMap : public CImageMap  
{
public:
	CMBMap();
	virtual ~CMBMap();
};

#endif // !defined(AFX_MBMAP_H__9B064CC0_388A_11D3_8F2D_E2D7E9D4B765__INCLUDED_)
