// SkinManager.h: interface for the CSkinManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SkinManager_H__018CE6D7_1E42_11D3_B643_00C04F6801E7__INCLUDED_)
#define AFX_SkinManager_H__018CE6D7_1E42_11D3_B643_00C04F6801E7__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#define MAX_SKINS	128

class CSkin
{
public:
    CSkin();
    virtual ~CSkin();

    virtual void SetPath(CString path){m_strPath = path;}
    virtual CString GetPath(){return m_strPath;}

    virtual void SetName(CString name){m_strName = name;}
    virtual const CString GetName() const {return m_strName;}

	const CSkin& operator=(const CSkin &source);
	const CSkin& operator=(const CSkin* source);

protected:
    CString		m_strPath;
    CString		m_strName;
};

class CSkinList
{
public:
	CSkinList();
	~CSkinList();

	void Add(CSkin* skin);
	CSkin* GetAt(int index);
	int GetCount(){return m_nCount;}

protected:
	CSkin	m_skins[MAX_SKINS];
	int		m_nCount;
};

class CSkinManager  
{
public:
	CSkinManager();
	virtual ~CSkinManager();

	void EnumerateSkins();
	virtual void Add(CSkin* skin);

	virtual CSkin* GetItem(int index);
	virtual int GetNumItems();

    void SetStartDir(CString startdir){m_strStartDir = startdir;}
    CString GetStartDir(){return m_strStartDir;}
    
	void SetSearchString(CString search){m_searchString = search;}
    CString GetSearchString(){return m_searchString;}

private:
    CString m_strStartDir;
    CString m_searchString;
   	CSkinList m_elements;
};

#endif // !defined(AFX_SkinManager_H__018CE6D7_1E42_11D3_B643_00C04F6801E7__INCLUDED_)
