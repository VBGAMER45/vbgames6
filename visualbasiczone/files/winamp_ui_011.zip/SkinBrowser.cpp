// SkinBrowser.cpp : implementation file
//

#include "stdafx.h"
#include "Winamp UI.h"
#include "SkinBrowser.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSkinBrowser dialog


CSkinBrowser::CSkinBrowser(CWnd* pParent /*=NULL*/)
	: CDialog(CSkinBrowser::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSkinBrowser)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_WBO_BOLT_INACTIVE);
}


void CSkinBrowser::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSkinBrowser)
	DDX_Control(pDX, IDC_LIST, m_List);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSkinBrowser, CDialog)
	//{{AFX_MSG_MAP(CSkinBrowser)
	ON_BN_CLICKED(IDC_DOWNLOAD, OnDownload)
	ON_BN_CLICKED(IDC_SETSKINSDIR, OnSetskinsdir)
	ON_BN_CLICKED(IDC_CLOSE, OnClose)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSkinBrowser message handlers

BOOL CSkinBrowser::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	m_manager.SetStartDir("c:\\progra~1\\devstudio\\myprojects\\Skin Browser\\Debug\\Skins");
	m_manager.EnumerateSkins();
	
	for(int i = 0; i < m_manager.GetNumItems(); i++)
	{
		m_List.AddString(m_manager.GetItem(i)->GetName());
	}	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CSkinBrowser::OnDownload() 
{
	ShellExecute(m_hWnd, "open", "http://www.winamp.com/winamp/skins", NULL, NULL,SW_SHOWNORMAL);
}

void CSkinBrowser::OnSetskinsdir() 
{
	CDirDialog	dlg;
	dlg.SetWindowTitle("Select Winamp Skin Directory");

	if(dlg.DoBrowse() == IDOK)
	{
		m_manager.SetStartDir(dlg.GetPathname());
	}
}

void CSkinBrowser::OnClose() 
{
	OnOK();
}
