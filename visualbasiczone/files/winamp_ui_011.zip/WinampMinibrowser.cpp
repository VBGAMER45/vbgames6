// WinampMinibrowser.cpp : implementation file
//

#include "stdafx.h"
#include "Winamp UI.h"
#include "WinampMinibrowser.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWinampMinibrowser dialog


CWinampMinibrowser::CWinampMinibrowser()
{
	//{{AFX_DATA_INIT(CWinampMinibrowser)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_pInterface		= new CBitmapEx();
	m_bFocus			= FALSE;
	m_bDragging			= FALSE;
	m_bResizing			= FALSE;
	m_bDocked			= FALSE;
	
	m_pBrowserWnd		= NULL;
	m_pParent			= NULL;
	m_pBrowser			= NULL;
	
	m_strLocation		= "";
	
	m_ptResizeFrom		= 0;
	m_ptDragFrom		= 0;
	
	LOGFONT lf;
	memset(&lf, 0, sizeof(LOGFONT));       // zero out structure
	lf.lfHeight = 13;                      // request a 13-pixel-height font
	strcpy(lf.lfFaceName, "Arial");        // request a face name "Arial"
	VERIFY(m_Font.CreateFontIndirect(&lf));  // create the font
}

CWinampMinibrowser::~CWinampMinibrowser()
{
	delete m_pInterface;
	m_Font.DeleteObject();
}


BEGIN_MESSAGE_MAP(CWinampMinibrowser, CWnd)
	//{{AFX_MSG_MAP(CWinampMinibrowser)
	ON_WM_KILLFOCUS()
	ON_WM_LBUTTONDOWN()
	ON_WM_PAINT()
	ON_WM_SETFOCUS()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_CREATE()
	ON_WM_RBUTTONUP()
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	ON_COMMAND(ID_MBCONTEXT_OPENLOCATION, OnMbcontextOpenlocation)
	ON_COMMAND(IDM_SKIN_BROWSER, OnSkinBrowser)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWinampMinibrowser message handlers

BOOL CWinampMinibrowser::Create(CWnd* pParent)
{
	CMenu menu;

	m_pParent = pParent;
	
	CString classname = AfxRegisterWndClass(CS_DBLCLKS);
	return CreateEx(WS_EX_LEFT | WS_EX_LTRREADING | WS_EX_RIGHTSCROLLBAR, 
					classname, "Winamp Minibrowser", 
					WS_CLIPSIBLINGS | WS_POPUP, 
					0,0,500,500, pParent->GetSafeHwnd(), menu);
}

int CWinampMinibrowser::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	//To load a bitmap from disk
	if(!m_pInterface->LoadBitmap("Skins\\mb.bmp"))
		m_pInterface->LoadBitmap(IDB_MB);

	SetWindowPos(NULL, 0, 0, 275, 348, SWP_NOACTIVATE | SWP_SHOWWINDOW);

	//Web Browser 
	CRect rcClient, rect;
	GetClientRect(&rcClient);
	rect = rcClient;
	rect.top += m_map.OffSet(TITLEBAR_FILL).Height();
	rect.bottom -= m_map.OffSet(BOTTOM_FILL).Height() - 3;
	rect.left += m_map.OffSet(LEFT_EDGE).Width();
	rect.right -= m_map.OffSet(RIGHT_EDGE).Width() - 3;
	
	m_pBrowserWnd = new CWnd;
	if(m_pBrowserWnd->CreateControl(CLSID_WebBrowser, "", WS_VISIBLE | WS_CHILD, rect, this, 1234) == TRUE) 	
	{ 
		IUnknown *pUnk = m_pBrowserWnd->GetControlUnknown();  
		pUnk->QueryInterface(IID_IWebBrowser2, (void **)&m_pBrowser);
		SetLocation("file:///C:/Program Files/Winamp/winampmb.htm"); 
	}	 
	return 0;
}

void CWinampMinibrowser::DrawInterface(BOOL bPaint)
{
	CRect rc, rcClient, rcWnd;
	GetClientRect(&rcClient);
	GetWindowRect(&rcWnd);
	rc = rcClient;

	int bottom	= rc.bottom;
	int top		= rc.top;
	int left	= rc.left;
	int right	= rc.right;
	int height	= bottom - top;
	int width	= right - left;


	CDC* pDC = GetDC();
	//pDC->FillSolidRect(rcClient, RGB(255,255,255));

	//Webbrowser Stuff
	CRect rcWB = rcClient;
	rcWB.top += m_map.OffSet(TITLEBAR_FILL).Height();
	rcWB.bottom -= m_map.OffSet(BOTTOM_FILL).Height() + 18;
	rcWB.left += m_map.OffSet(LEFT_EDGE).Width();
	rcWB.right -= m_map.OffSet(RIGHT_EDGE).Width() + 10;

	if(::IsWindow(m_pBrowserWnd->GetSafeHwnd()))
		m_pBrowserWnd->SetWindowPos(&wndBottom, rcWB.left, rcWB.top, rcWB.right, rcWB.bottom, SWP_SHOWWINDOW);

	//Draw Bitmaps
	int FillsNeeded = rcWnd.Width() - (m_map.OffSet(TITLEBAR_LEFT_CORNER).Width() + m_map.OffSet(TITLEBAR_RIGHT_CORNER).Width());
	FillsNeeded = FillsNeeded / m_map.OffSet(TITLEBAR_FILL).Width();
	if(m_bFocus)
	{
		m_pInterface->Draw(FALSE, this, 0, 0, m_map.OffSet(TITLEBAR_LEFT_CORNER));
		for(int i = 0; i <= FillsNeeded; i++)
			m_pInterface->Draw(FALSE, this, m_map.OffSet(TITLEBAR_LEFT_CORNER).Width() + (m_map.OffSet(TITLEBAR_FILL).Width() * i) , 0, m_map.OffSet(TITLEBAR_FILL));

		m_pInterface->Draw(FALSE, this, (rcWnd.Width() / 2) - (m_map.OffSet(TITLEBAR_MIDDLE).Width() / 2), 0, m_map.OffSet(TITLEBAR_MIDDLE));
		m_pInterface->Draw(FALSE, this, (rcWnd.Width() - m_map.OffSet(TITLEBAR_RIGHT_CORNER).Width()), 0, m_map.OffSet(TITLEBAR_RIGHT_CORNER));
	}
	else
	{
		m_pInterface->Draw(FALSE, this, 0, 0, m_map.OffSet(INACTIVE_TITLEBAR_LEFT_CORNER));
		for(int i = 0; i <= FillsNeeded; i++)
			m_pInterface->Draw(FALSE, this, m_map.OffSet(TITLEBAR_LEFT_CORNER).Width() + (m_map.OffSet(TITLEBAR_FILL).Width() * i) , 0, m_map.OffSet(INACTIVE_TITLEBAR_FILL));

		m_pInterface->Draw(FALSE, this, (rcWnd.Width() / 2) - (m_map.OffSet(TITLEBAR_MIDDLE).Width() / 2), 0, m_map.OffSet(INACTIVE_TITLEBAR_MIDDLE));
		m_pInterface->Draw(FALSE, this, (rcWnd.Width() - m_map.OffSet(TITLEBAR_RIGHT_CORNER).Width()), 0, m_map.OffSet(INACTIVE_TITLEBAR_RIGHT_CORNER));
	}

	FillsNeeded = (height - (m_map.OffSet(TITLEBAR_LEFT_CORNER).Height() + m_map.OffSet(BOTTOM_LEFT).Height())) / m_map.OffSet(LEFT_EDGE).Height();
	int y = 0;
	for(int i = 0; i <= FillsNeeded; i++)
	{
		y = m_map.OffSet(TITLEBAR_LEFT_CORNER).Height() + (m_map.OffSet(LEFT_EDGE).Height() * i);
		m_pInterface->Draw(bPaint, this, 0, y, m_map.OffSet(LEFT_EDGE));
		m_pInterface->Draw(bPaint, this, width - m_map.OffSet(RIGHT_EDGE).Width(), y, m_map.OffSet(RIGHT_EDGE));
	}

	m_pInterface->Draw(bPaint, this, 0, height - m_map.OffSet(BOTTOM_LEFT).Height(), m_map.OffSet(BOTTOM_LEFT));
	
	FillsNeeded = (rcWnd.Width() - (m_map.OffSet(BOTTOM_LEFT).Width() + m_map.OffSet(BOTTOM_RIGHT).Width())) / m_map.OffSet(BOTTOM_FILL).Width();
	for(i = 0; i <= FillsNeeded; i++)
		m_pInterface->Draw(FALSE, this, m_map.OffSet(BOTTOM_LEFT).Width() + (m_map.OffSet(BOTTOM_FILL).Width() * i) , height - m_map.OffSet(BOTTOM_RIGHT).Height(), m_map.OffSet(BOTTOM_FILL));
	m_pInterface->Draw(bPaint, this, width - m_map.OffSet(BOTTOM_RIGHT).Width(), height - m_map.OffSet(BOTTOM_RIGHT).Height(), m_map.OffSet(BOTTOM_RIGHT));


	DrawText();
}

void CWinampMinibrowser::DrawText()
{
	CRect rcClient;
	GetClientRect(&rcClient);

	CDC* pDC = GetDC();
	//Draw Location Text
	CRect rcText(m_map.OffSet(BOTTOM_LEFT).Width() - 32, rcClient.Height() - 27, rcClient.Width() - 25 , rcClient.Height() - 12);
	pDC->SetBkColor(RGB(0, 0, 0));
	pDC->SetTextColor(RGB(0, 255, 0));
	CFont* def_font = static_cast<CFont*>(pDC->SelectObject(&m_Font));
	pDC->ExtTextOut(rcText.left, rcText.top, ETO_CLIPPED | ETO_OPAQUE , rcText, m_strLocation, NULL);
	pDC->SelectObject(def_font);
}

void CWinampMinibrowser::OnPaint() 
{
	DrawInterface();	
	// Do not call CWnd::OnPaint() for painting messages
}

void CWinampMinibrowser::OnKillFocus(CWnd* pNewWnd) 
{
	CWnd::OnKillFocus(pNewWnd);
	m_bFocus = FALSE;
	DrawInterface();
}

void CWinampMinibrowser::OnSetFocus(CWnd* pNewWnd) 
{
	CWnd::OnSetFocus(pNewWnd);
	m_bFocus = TRUE;
	DrawInterface();
}

void CWinampMinibrowser::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CRect rcWnd, rcTemp;
	GetClientRect(&rcWnd);

	//Close Window
	rcTemp = rcWnd;
	rcTemp.right = rcTemp.right - 3;
	rcTemp.left = rcTemp.right - 7;
	rcTemp.top = rcTemp.top + 3;
	rcTemp.bottom = rcTemp.top + 7;
	if(rcTemp.PtInRect(point))
	{
		m_pInterface->Draw(FALSE, this, rcTemp.left, rcTemp.top, m_map.OffSet(CLOSE_BUTTON));
	}

	//Back
	rcTemp = rcWnd;
	rcTemp.left = rcTemp.left + 9;
	rcTemp.top = rcTemp.bottom - 29;
	rcTemp.right = rcTemp.left + m_map.OffSet(BACK_DOWN).Width();
	rcTemp.bottom = rcTemp.top + m_map.OffSet(BACK_DOWN).Height();
	if(rcTemp.PtInRect(point))
	{
		m_pInterface->Draw(FALSE, this, rcTemp.left,  rcTemp.top, m_map.OffSet(BACK_DOWN));
	}

	//Forward
	rcTemp = rcWnd;
	rcTemp.left = rcTemp.left + 24;
	rcTemp.top = rcTemp.bottom - 29;
	rcTemp.right = rcTemp.left + m_map.OffSet(FORWARD_DOWN).Width();
	rcTemp.bottom = rcTemp.top + m_map.OffSet(FORWARD_DOWN).Height();
	if(rcTemp.PtInRect(point))
	{
		m_pInterface->Draw(FALSE, this, rcTemp.left, rcTemp.top, m_map.OffSet(FORWARD_DOWN));
	}

	//Stop
	rcTemp = rcWnd;
	rcTemp.left = rcTemp.left + 39;
	rcTemp.top = rcTemp.bottom - 29;
	rcTemp.right = rcTemp.left + m_map.OffSet(STOP_DOWN).Width();
	rcTemp.bottom = rcTemp.top + m_map.OffSet(STOP_DOWN).Height();
	if(rcTemp.PtInRect(point))
	{
		m_pInterface->Draw(FALSE, this, rcTemp.left, rcTemp.top, m_map.OffSet(STOP_DOWN));
	}

	//Refresh
	rcTemp = rcWnd;
	rcTemp.left = rcTemp.left + 56;
	rcTemp.top = rcTemp.bottom - 29;
	rcTemp.right = rcTemp.left + m_map.OffSet(REFRESH_DOWN).Width();
	rcTemp.bottom = rcTemp.top + m_map.OffSet(REFRESH_DOWN).Height();
	if(rcTemp.PtInRect(point))
	{
		m_pInterface->Draw(FALSE, this, rcTemp.left, rcTemp.top, m_map.OffSet(REFRESH_DOWN));
	}

	//Open Location
	rcTemp = rcWnd;
	rcTemp.left = rcTemp.left + 70;
	rcTemp.top = rcTemp.bottom - 29;
	rcTemp.right = rcTemp.left + m_map.OffSet(OPEN_DOWN).Width();
	rcTemp.bottom = rcTemp.top + m_map.OffSet(OPEN_DOWN).Height();
	if(rcTemp.PtInRect(point))
	{
		m_pInterface->Draw(FALSE, this, rcTemp.left, rcTemp.top, m_map.OffSet(OPEN_DOWN));
	}

	//Resizing
	rcTemp = rcWnd;
	rcTemp.left = rcTemp.right - 20;
	rcTemp.top = rcTemp.bottom - 20;
	if(rcTemp.PtInRect(point))
	{
		SetCapture();
		m_bResizing = TRUE;
		m_ptResizeFrom = point;
	}

	//Dragging
	rcTemp = rcWnd;
	rcTemp.bottom = rcTemp.top + 20;
	if(rcTemp.PtInRect(point))
	{
		SetCapture();
		m_bDragging = TRUE;
		m_ptDragFrom = point;
	}
	
	CWnd::OnLButtonDown(nFlags, point);
}

void CWinampMinibrowser::OnLButtonUp(UINT nFlags, CPoint point) 
{
	CRect rcWnd, rcTemp;
	GetClientRect(&rcWnd);

	rcTemp = rcWnd;
	rcTemp.right = rcTemp.right - 3;
	rcTemp.left = rcTemp.right - 7;
	rcTemp.top = rcTemp.top + 3;
	rcTemp.bottom = rcTemp.top + 7;

	//Close Window
	if(rcTemp.PtInRect(point))
	{
		ShowWindow(SW_HIDE);
	}

	//Back
	rcTemp = rcWnd;
	rcTemp.left = rcTemp.left + 8;
	rcTemp.top = rcTemp.bottom - 30;
	rcTemp.right = rcTemp.left + m_map.OffSet(BACK_UP).Width();
	rcTemp.bottom = rcTemp.top + m_map.OffSet(BACK_UP).Height();
	if(rcTemp.PtInRect(point))
	{
		m_pInterface->Draw(FALSE, this, rcTemp.left,  rcTemp.top, m_map.OffSet(BACK_UP));
		m_pBrowser->GoBack();
	}

	//Forward
	rcTemp = rcWnd;
	rcTemp.left = rcTemp.left + 23;
	rcTemp.top = rcTemp.bottom - 30;
	rcTemp.right = rcTemp.left + m_map.OffSet(FORWARD_UP).Width();
	rcTemp.bottom = rcTemp.top + m_map.OffSet(FORWARD_UP).Height();
	if(rcTemp.PtInRect(point))
	{
		m_pInterface->Draw(FALSE, this, rcTemp.left, rcTemp.top, m_map.OffSet(FORWARD_UP));
		m_pBrowser->GoForward();
	}

	//Stop
	rcTemp = rcWnd;
	rcTemp.left = rcTemp.left + 38;
	rcTemp.top = rcTemp.bottom - 30;
	rcTemp.right = rcTemp.left + m_map.OffSet(STOP_UP).Width();
	rcTemp.bottom = rcTemp.top + m_map.OffSet(STOP_UP).Height();
	if(rcTemp.PtInRect(point))
	{
		m_pInterface->Draw(FALSE, this, rcTemp.left, rcTemp.top, m_map.OffSet(STOP_UP));
		m_pBrowser->Stop();
	}

	//Refresh
	rcTemp = rcWnd;
	rcTemp.left = rcTemp.left + 55;
	rcTemp.top = rcTemp.bottom - 30;
	rcTemp.right = rcTemp.left + m_map.OffSet(REFRESH_UP).Width();
	rcTemp.bottom = rcTemp.top + m_map.OffSet(REFRESH_UP).Height();
	if(rcTemp.PtInRect(point))
	{
		m_pInterface->Draw(FALSE, this, rcTemp.left, rcTemp.top, m_map.OffSet(REFRESH_UP));
		m_pBrowser->Refresh();
	}

	//Open Location
	rcTemp = rcWnd;
	rcTemp.left = rcTemp.left + 69;
	rcTemp.top = rcTemp.bottom - 30;
	rcTemp.right = rcTemp.left + m_map.OffSet(OPEN_UP).Width();
	rcTemp.bottom = rcTemp.top + m_map.OffSet(OPEN_UP).Height();
	if(rcTemp.PtInRect(point))
	{
		m_pInterface->Draw(FALSE, this, rcTemp.left, rcTemp.top, m_map.OffSet(OPEN_UP));

		CMenu menu;
		VERIFY(menu.LoadMenu(IDR_MENU));
		POINT pp;
		GetCursorPos(&pp);
		menu.GetSubMenu(5)->TrackPopupMenu(TPM_LEFTALIGN | TPM_LEFTBUTTON,pp.x,pp.y,this);
	}
	
	if(m_bResizing)
	{
		ReleaseCapture();
		m_bResizing = FALSE;
	}

	if(m_bDragging)
	{
		ReleaseCapture();
		m_bDragging = FALSE;
	}

	
	
	CWnd::OnLButtonUp(nFlags, point);
}

void CWinampMinibrowser::OnMouseMove(UINT nFlags, CPoint point) 
{
	CRect rcWnd;
	GetWindowRect(&rcWnd);

	ChooseCursor(point);

	//Fixed Resizing Code
	if(m_bResizing && nFlags & MK_LBUTTON)
	{
		//Resize in X direction outwards
		if(point.x >= (m_ptResizeFrom.x + RESIZE_WIDTH))
		{
			rcWnd.right += RESIZE_WIDTH;
			if(rcWnd.Width() >= MIN_WIDTH)
			{
				SetWindowPos(NULL, rcWnd.left, rcWnd.top, rcWnd.Width(), rcWnd.Height(), SWP_SHOWWINDOW);
				m_ptResizeFrom.x += RESIZE_WIDTH;
			}
		}
		//Resize in X direction inwards
		else if(point.x <= (m_ptResizeFrom.x - RESIZE_WIDTH))
		{
			rcWnd.right -= RESIZE_WIDTH;
			if(rcWnd.Width() >= MIN_WIDTH)
			{
				SetWindowPos(NULL, rcWnd.left, rcWnd.top, rcWnd.Width(), rcWnd.Height(), SWP_SHOWWINDOW);
				m_ptResizeFrom.x -= RESIZE_WIDTH;
			}
		}
		//Resize in Y direction downwards
		else if(point.y >= (m_ptResizeFrom.y + RESIZE_HEIGHT))
		{
			rcWnd.bottom += RESIZE_HEIGHT;
			if(rcWnd.Height() >= MIN_HEIGHT)
			{
				SetWindowPos(NULL, rcWnd.left, rcWnd.top, rcWnd.Width(), rcWnd.Height(), SWP_SHOWWINDOW);
				m_ptResizeFrom.y += RESIZE_HEIGHT;
			}
		}
		//Resize in Y direction upwards
		else if(point.y <= (m_ptResizeFrom.y - RESIZE_HEIGHT))
		{
			rcWnd.bottom -= RESIZE_HEIGHT;
			if(rcWnd.Height() >= MIN_HEIGHT)
			{
				SetWindowPos(NULL, rcWnd.left, rcWnd.top, rcWnd.Width(), rcWnd.Height(), SWP_SHOWWINDOW);
				m_ptResizeFrom.y -= RESIZE_HEIGHT;
			}
		}
	}

	//Dragging & Docking Code
	if(m_bDragging && nFlags & MK_LBUTTON)
	{
		CRect rcParent;
		m_pParent->GetWindowRect(&rcParent);

		int xdiff = point.x - m_ptDragFrom.x;
		int ydiff = point.y - m_ptDragFrom.y;

		int NewLeftEdge = rcWnd.left + xdiff;
		int NewTopEdge = rcWnd.top + ydiff;

		//If we are in the Docked region
		if((NewLeftEdge <= rcParent.right + SNAP_OFFSET) && (NewLeftEdge >= rcParent.right - SNAP_OFFSET))
		{
			if(!m_bDocked)
				SetWindowPos(NULL, rcParent.right, rcWnd.top + ydiff, rcWnd.Width(), rcWnd.Height(), SWP_SHOWWINDOW);
			else
			{
				if((NewTopEdge <= rcParent.top + SNAP_OFFSET) && (NewTopEdge >= rcParent.top - SNAP_OFFSET))
					SetWindowPos(NULL, rcWnd.left, rcParent.top, rcWnd.Width(), rcWnd.Height(), SWP_SHOWWINDOW);
				else if((NewTopEdge <= rcParent.bottom + SNAP_OFFSET) && (NewTopEdge >= rcParent.bottom - SNAP_OFFSET))
					SetWindowPos(NULL, rcWnd.left, rcParent.bottom, rcWnd.Width(), rcWnd.Height(), SWP_SHOWWINDOW);
				else
					SetWindowPos(NULL, rcWnd.left, NewTopEdge, rcWnd.Width(), rcWnd.Height(), SWP_SHOWWINDOW);
			}
			m_bDocked = TRUE;
		}
		//Carry on dragging
		else 
		{
			SetWindowPos(NULL, NewLeftEdge, NewTopEdge, rcWnd.Width(), rcWnd.Height(), SWP_SHOWWINDOW);
			m_bDocked = FALSE;
		}
		Invalidate();
	}	

	CWnd::OnMouseMove(nFlags, point);
}


void CWinampMinibrowser::ChooseCursor(CPoint point)
{
	HCURSOR hCursor;
	CRect rcWnd, rcTemp;
	GetClientRect(&rcWnd);
	
	rcTemp = rcWnd;
	rcTemp.left = rcTemp.right - 20;
	rcTemp.top = rcTemp.bottom - 20;
	if(rcTemp.PtInRect(point) || m_bResizing)
	{
		hCursor = AfxGetApp()->LoadCursor(IDC_RESIZE);
		SetCursor(hCursor);
		return;
	}

	rcTemp = rcWnd;
	rcTemp.right = rcTemp.right - 3;
	rcTemp.left = rcTemp.right - 7;
	rcTemp.top = rcTemp.top + 3;
	rcTemp.bottom = rcTemp.top + 7;
	if(rcTemp.PtInRect(point))
	{
		hCursor = AfxGetApp()->LoadCursor(IDC_CLOSE);
		SetCursor(hCursor);
		return;
	}
	
	rcTemp = rcWnd;
	rcTemp.bottom = rcTemp.top + 20;
	if(rcTemp.PtInRect(point) || m_bDragging)
	{
		hCursor = AfxGetApp()->LoadCursor(IDC_DRAG);
		SetCursor(hCursor);
		return;
	}
	
	//Default
	hCursor = AfxGetApp()->LoadCursor(IDC_DEFAULT_ARROW);
	SetCursor(hCursor);	
}

void CWinampMinibrowser::OnRButtonUp(UINT nFlags, CPoint point) 
{
	
	//Default
	CMenu menu;
	VERIFY(menu.LoadMenu(IDR_MENU));

	CMenu* pPopup = menu.GetSubMenu(0);
	ASSERT(pPopup != NULL);

	POINT pp;
	GetCursorPos(&pp);
	pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_LEFTBUTTON,pp.x,pp.y,this);
	pPopup->DestroyMenu();


	CWnd::OnRButtonUp(nFlags, point);
}

void CWinampMinibrowser::OnSize(UINT nType, int cx, int cy) 
{
	CWnd::OnSize(nType, cx, cy);
	
	DrawInterface();	
}

BOOL CWinampMinibrowser::OnEraseBkgnd( CDC* pDC )
{
	return TRUE;
}

BOOL CWinampMinibrowser::SetLocation(CString Location)
{
	m_strLocation = Location;
	BSTR bUrl = m_strLocation.AllocSysString(); 
	COleVariant vNull; 

	HRESULT hr = m_pBrowser->Navigate(bUrl, &vNull, &vNull, &vNull, &vNull);

	if(hr)
		return TRUE;
	else
		return FALSE;
}

void CWinampMinibrowser::OnMbcontextOpenlocation() 
{
	CMBOpenLocation	dlg;
	
	if(dlg.DoModal() == IDOK)
	{
		SetLocation(dlg.m_strLocation);
		DrawText();
	}

}

void CWinampMinibrowser::OnSkinBrowser() 
{
	CSkinBrowser dlg;
	dlg.DoModal();
	
}
