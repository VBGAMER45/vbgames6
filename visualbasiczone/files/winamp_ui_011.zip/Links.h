#if !defined(AFX_LINKS_H__5A0DD905_3D3E_11D3_8F2D_BBF880D09861__INCLUDED_)
#define AFX_LINKS_H__5A0DD905_3D3E_11D3_8F2D_BBF880D09861__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Links.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CLinks dialog

class CLinks : public CPropertyPage
{
	DECLARE_DYNCREATE(CLinks)

// Construction
public:
	CLinks();
	~CLinks();

// Dialog Data
	//{{AFX_DATA(CLinks)
	enum { IDD = IDD_LINKS };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CLinks)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CLinks)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LINKS_H__5A0DD905_3D3E_11D3_8F2D_BBF880D09861__INCLUDED_)
