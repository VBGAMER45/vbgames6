// WinampAbout.cpp : implementation file
//

#include "stdafx.h"
#include "Winamp UI.h"
#include "WinampAbout.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWinampAbout property page

IMPLEMENT_DYNCREATE(CWinampAbout, CPropertyPage)

CWinampAbout::CWinampAbout() : CPropertyPage(CWinampAbout::IDD)
{
	//{{AFX_DATA_INIT(CWinampAbout)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CWinampAbout::~CWinampAbout()
{
}

void CWinampAbout::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWinampAbout)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWinampAbout, CPropertyPage)
	//{{AFX_MSG_MAP(CWinampAbout)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWinampAbout message handlers
