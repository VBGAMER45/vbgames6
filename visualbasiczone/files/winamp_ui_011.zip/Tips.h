#if !defined(AFX_TIPS_H__5A0DD904_3D3E_11D3_8F2D_BBF880D09861__INCLUDED_)
#define AFX_TIPS_H__5A0DD904_3D3E_11D3_8F2D_BBF880D09861__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Tips.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTips dialog

class CTips : public CPropertyPage
{
	DECLARE_DYNCREATE(CTips)

// Construction
public:
	CTips();
	~CTips();

// Dialog Data
	//{{AFX_DATA(CTips)
	enum { IDD = IDD_TIPS };
	CString	m_strTips;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CTips)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CTips)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TIPS_H__5A0DD904_3D3E_11D3_8F2D_BBF880D09861__INCLUDED_)
