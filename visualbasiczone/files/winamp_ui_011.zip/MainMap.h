// MainMap.h: interface for the CMainMap class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINMAP_H__018CE6D9_1E42_11D3_B643_00C04F6801E7__INCLUDED_)
#define AFX_MAINMAP_H__018CE6D9_1E42_11D3_B643_00C04F6801E7__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "ImageMap.h"

#define	MAIN				0
#define TITLEBAR			1

class CMainMap : public CImageMap
{
public:
	CMainMap();
	virtual ~CMainMap();

};

#endif // !defined(AFX_MAINMAP_H__018CE6D9_1E42_11D3_B643_00C04F6801E7__INCLUDED_)
