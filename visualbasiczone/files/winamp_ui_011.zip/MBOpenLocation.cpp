// MBOpenLocation.cpp : implementation file
//

#include "stdafx.h"
#include "Winamp UI.h"
#include "MBOpenLocation.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMBOpenLocation dialog


CMBOpenLocation::CMBOpenLocation(CWnd* pParent /*=NULL*/)
	: CDialog(CMBOpenLocation::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMBOpenLocation)
	m_strLocation = _T("");
	//}}AFX_DATA_INIT
}


void CMBOpenLocation::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMBOpenLocation)
	DDX_Text(pDX, IDC_LOCATION, m_strLocation);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMBOpenLocation, CDialog)
	//{{AFX_MSG_MAP(CMBOpenLocation)
	ON_BN_CLICKED(IDC_OPEN, OnOpen)
	ON_BN_CLICKED(IDC_CANCEL, OnCancel)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMBOpenLocation message handlers

void CMBOpenLocation::OnOpen() 
{
	OnOK();
	
}

void CMBOpenLocation::OnCancel() 
{
	CDialog::OnCancel();
}
