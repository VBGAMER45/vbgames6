// WinampEqualizer.cpp : implementation file
//

#include "stdafx.h"
#include "Winamp UI.h"
#include "WinampEqualizer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWinampEqualizer
CWinampEqualizer::CWinampEqualizer()
{
	//{{AFX_DATA_INIT(CWinampEqualizer)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_pInterface		= new CBitmapEx();
	m_bFocus			= FALSE;
	m_bDragging			= FALSE;
}

CWinampEqualizer::~CWinampEqualizer()
{
	delete m_pInterface;
}

BEGIN_MESSAGE_MAP(CWinampEqualizer, CWnd)
	//{{AFX_MSG_MAP(CWinampEqualizer)
	ON_WM_LBUTTONDOWN()
	ON_WM_PAINT()
	ON_WM_KILLFOCUS()
	ON_WM_SETFOCUS()
	ON_WM_CREATE()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWinampEqualizer message handlers
BOOL CWinampEqualizer::Create(CWnd* pParent)
{
	CMenu menu;
	
	CString classname = AfxRegisterWndClass(CS_DBLCLKS);
	return CreateEx(WS_EX_LEFT | WS_EX_LTRREADING | WS_EX_RIGHTSCROLLBAR, 
					classname, "Winamp Equalizer", 
					WS_VISIBLE | WS_CLIPSIBLINGS | WS_POPUP, 
					0,0,500,500, pParent->GetSafeHwnd(), menu);
}

int CWinampEqualizer::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if(!m_pInterface->LoadBitmap("Skins\\eqmain.bmp"))
		m_pInterface->LoadBitmap(IDB_EQMAIN);
	
	SetWindowPos(NULL, 0,0,m_map.OffSet(MAIN).Width(),m_map.OffSet(MAIN).Height(),SWP_SHOWWINDOW);
	
	return 0;
}

void CWinampEqualizer::DrawInterface(BOOL bPaint)
{
	m_pInterface->Draw(bPaint, this, MAIN_X, MAIN_Y, m_map.OffSet(MAIN));
	
	if(m_bFocus)
		m_pInterface->Draw(bPaint, this, TITLEBAR_X, TITLEBAR_Y, m_map.OffSet(TITLEBAR));
	else
		m_pInterface->Draw(bPaint, this, TITLEBAR_X, TITLEBAR_Y, m_map.OffSet(INACTIVE_TITLEBAR));

	m_pInterface->Draw(bPaint, this, CLOSE_X, CLOSE_Y, m_map.OffSet(CLOSE));
	
	m_pInterface->Draw(bPaint, this, PREAMP_BAR_X, PREAMP_BAR_Y, m_map.OffSet(PREAMP_BAR));
	m_pInterface->Draw(bPaint, this, SLIDER_PREAMP_X, SLIDER_Y, m_map.OffSet(SLIDER));

	m_pInterface->Draw(bPaint, this, ON_X, ON_Y, m_map.OffSet(ON));
	m_pInterface->Draw(bPaint, this, AUTO_X, AUTO_Y, m_map.OffSet(AUTO));
	m_pInterface->Draw(bPaint, this, PRESET_X, PRESET_Y, m_map.OffSet(PRESET));

	m_pInterface->Draw(bPaint, this, EQ_X , EQ_Y, m_map.OffSet(EQ_BAR_1));
	m_pInterface->Draw(bPaint, this, EQ_X + EQ_OFFSET, EQ_Y, m_map.OffSet(EQ_BAR_4));
	m_pInterface->Draw(bPaint, this, EQ_X + (2 * EQ_OFFSET), EQ_Y, m_map.OffSet(EQ_BAR_7));
	m_pInterface->Draw(bPaint, this, EQ_X + (3 * EQ_OFFSET), EQ_Y, m_map.OffSet(EQ_BAR_10));
	m_pInterface->Draw(bPaint, this, EQ_X + (4 * EQ_OFFSET), EQ_Y, m_map.OffSet(EQ_BAR_13));
	m_pInterface->Draw(bPaint, this, EQ_X + (5 * EQ_OFFSET), EQ_Y, m_map.OffSet(EQ_BAR_15));
	m_pInterface->Draw(bPaint, this, EQ_X + (6 * EQ_OFFSET), EQ_Y, m_map.OffSet(EQ_BAR_18));
	m_pInterface->Draw(bPaint, this, EQ_X + (7 * EQ_OFFSET), EQ_Y, m_map.OffSet(EQ_BAR_21));
	m_pInterface->Draw(bPaint, this, EQ_X + (8 * EQ_OFFSET), EQ_Y, m_map.OffSet(EQ_BAR_25));
	m_pInterface->Draw(bPaint, this, EQ_X + (9 * EQ_OFFSET), EQ_Y, m_map.OffSet(EQ_BAR_28));

	m_pInterface->Draw(bPaint, this, SLIDER_EQ_X , SLIDER_Y, m_map.OffSet(SLIDER));
	m_pInterface->Draw(bPaint, this, SLIDER_EQ_X + SLIDER_EQ_OFFSET, SLIDER_Y, m_map.OffSet(SLIDER));
	m_pInterface->Draw(bPaint, this, SLIDER_EQ_X + (2 * SLIDER_EQ_OFFSET), SLIDER_Y, m_map.OffSet(SLIDER));
	m_pInterface->Draw(bPaint, this, SLIDER_EQ_X + (3 * SLIDER_EQ_OFFSET), SLIDER_Y, m_map.OffSet(SLIDER));
	m_pInterface->Draw(bPaint, this, SLIDER_EQ_X + (4 * SLIDER_EQ_OFFSET), SLIDER_Y, m_map.OffSet(SLIDER));
	m_pInterface->Draw(bPaint, this, SLIDER_EQ_X + (5 * SLIDER_EQ_OFFSET), SLIDER_Y, m_map.OffSet(SLIDER));
	m_pInterface->Draw(bPaint, this, SLIDER_EQ_X + (6 * SLIDER_EQ_OFFSET), SLIDER_Y, m_map.OffSet(SLIDER));
	m_pInterface->Draw(bPaint, this, SLIDER_EQ_X + (7 * SLIDER_EQ_OFFSET), SLIDER_Y, m_map.OffSet(SLIDER));
	m_pInterface->Draw(bPaint, this, SLIDER_EQ_X + (8 * SLIDER_EQ_OFFSET), SLIDER_Y, m_map.OffSet(SLIDER));
	m_pInterface->Draw(bPaint, this, SLIDER_EQ_X + (9 * SLIDER_EQ_OFFSET), SLIDER_Y, m_map.OffSet(SLIDER));
}

void CWinampEqualizer::OnPaint() 
{
	DrawInterface();	
}

void CWinampEqualizer::OnKillFocus(CWnd* pNewWnd) 
{
	CWnd::OnKillFocus(pNewWnd);
	m_bFocus = FALSE;
	DrawInterface();
}

void CWinampEqualizer::OnSetFocus(CWnd* pNewWnd) 
{
	CWnd::OnSetFocus(pNewWnd);
	m_bFocus = TRUE;
	DrawInterface();
}

void CWinampEqualizer::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CRect rcWnd, rcTemp;
	GetClientRect(&rcWnd);

	rcTemp = rcWnd;
	rcTemp.bottom = rcTemp.top + 20;

	//Dragging
	if(rcTemp.PtInRect(point))
	{
		SetCapture();
		m_bDragging = TRUE;
		m_ptDragFrom = point;
	}

	rcTemp = rcWnd;
	rcTemp.right = rcTemp.right - 3;
	rcTemp.left = rcTemp.right - 7;
	rcTemp.top = rcTemp.top + 3;
	rcTemp.bottom = rcTemp.top + 7;

	//Close Window
	if(rcTemp.PtInRect(point))
	{
		DestroyWindow();
	}
	
	CWnd::OnLButtonDown(nFlags, point);
}

void CWinampEqualizer::OnLButtonUp(UINT nFlags, CPoint point) 
{
	if(m_bDragging)
	{
		ReleaseCapture();
		m_bDragging = FALSE;
	}
	
	CWnd::OnLButtonUp(nFlags, point);
}

void CWinampEqualizer::OnMouseMove(UINT nFlags, CPoint point) 
{
	CRect rcWnd;
	GetWindowRect(&rcWnd);

	ChooseCursor(point);

	if(m_bDragging && nFlags & MK_LBUTTON)
	{
		int xdiff = point.x - m_ptDragFrom.x;
		int ydiff = point.y - m_ptDragFrom.y;

		SetWindowPos(NULL, rcWnd.left + xdiff, rcWnd.top + ydiff, rcWnd.Width(), rcWnd.Height(), SWP_SHOWWINDOW);
	}	

	CWnd::OnMouseMove(nFlags, point);
}


void CWinampEqualizer::ChooseCursor(CPoint point)
{
	HCURSOR hCursor;
	CRect rcWnd, rcTemp;
	GetClientRect(&rcWnd);
	
	rcTemp = rcWnd;
	rcTemp.right = rcTemp.right - 3;
	rcTemp.left = rcTemp.right - 7;
	rcTemp.top = rcTemp.top + 3;
	rcTemp.bottom = rcTemp.top + 7;
	if(rcTemp.PtInRect(point))
	{
		hCursor = AfxGetApp()->LoadCursor(IDC_CLOSE);
		SetCursor(hCursor);
		return;
	}
	
	rcTemp = rcWnd;
	rcTemp.bottom = rcTemp.top + 20;
	if(rcTemp.PtInRect(point) || m_bDragging)
	{
		hCursor = AfxGetApp()->LoadCursor(IDC_DRAG);
		SetCursor(hCursor);
		return;
	}
	
	//Default
	hCursor = AfxGetApp()->LoadCursor(IDC_DEFAULT_ARROW);
	SetCursor(hCursor);	
}
