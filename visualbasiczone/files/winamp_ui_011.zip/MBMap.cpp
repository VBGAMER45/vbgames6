// MBMap.cpp: implementation of the CMBMap class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Winamp UI.h"
#include "MBMap.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMBMap::CMBMap()
{
	m_ImageMap[0].SetRect(0,   0, 25, 20);	//TitleBar Left Corner
	m_ImageMap[1].SetRect(26,  0, 126, 20);	//TitleBar Middle
	m_ImageMap[2].SetRect(127, 0, 152, 20);	//TitleBar Fill
	m_ImageMap[3].SetRect(153, 0, 178, 20);	//TitleBar Right Corner
	m_ImageMap[4].SetRect(0,   21, 25, 41);	//TitleBar Left Corner
	m_ImageMap[5].SetRect(26,  21, 126, 41);	//TitleBar Middle
	m_ImageMap[6].SetRect(127, 21, 152, 41);	//TitleBar Fill
	m_ImageMap[7].SetRect(153, 21, 178, 41);	//TitleBar Right Corner
	m_ImageMap[8].SetRect(0, 42, 125, 80);	//Bottom Left Corner
	m_ImageMap[9].SetRect(0, 81, 125, 119);	//Bottom rIGHT Corner
	m_ImageMap[10].SetRect(127, 81, 152, 119);	//Bottom Filler
	m_ImageMap[11].SetRect(127, 42, 138, 71);	//Left Edge
	m_ImageMap[12].SetRect(139, 42, 147, 71);	//Right Edge
	m_ImageMap[13].SetRect(148, 42, 157, 51);	//Close Pressed
	m_ImageMap[14].SetRect(158, 42, 173, 59);	//Back Pressed
	m_ImageMap[15].SetRect(173, 42, 188, 59);	//Forward Pressed
	m_ImageMap[16].SetRect(188, 42, 205, 59);	//Stop Pressed
	m_ImageMap[17].SetRect(205, 42, 219, 59);	//Refresh Pressed
	m_ImageMap[18].SetRect(219, 42, 233, 59);	//Open Pressed
	m_ImageMap[19].SetRect(158, 42, 173, 60);	//Back Up
	m_ImageMap[20].SetRect(173, 42, 188, 60);	//Forward Up
	m_ImageMap[21].SetRect(188, 42, 205, 60);	//Stop Up
	m_ImageMap[22].SetRect(205, 42, 219, 60);	//Refresh Up
	m_ImageMap[23].SetRect(219, 42, 233, 60);	//Open Up
}

CMBMap::~CMBMap()
{

}
