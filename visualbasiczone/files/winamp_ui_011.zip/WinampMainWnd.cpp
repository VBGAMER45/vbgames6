// WinampMainWnd.cpp : implementation file
//

#include "stdafx.h"
#include "Winamp UI.h"
#include "WinampMainWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWinampMainWnd dialog


CWinampMainWnd::CWinampMainWnd(CWnd* pParent /*=NULL*/)
	: CDialog(CWinampMainWnd::IDD, pParent)
{
	//{{AFX_DATA_INIT(CWinampMainWnd)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	m_pMain				= new CBitmapEx();
	m_pTitlebar			= new CBitmapEx();
	m_pEQWnd			= new CWinampEqualizer();
	m_pPEWnd			= new CWinampPlaylistEditor();
	m_pMBWnd			= new CWinampMinibrowser();
	m_strTitleSource	= "Winamp 2.24 *** ";
	m_nCapLength		= 20;
	m_nCapPos			= 0;
	m_hIcon				= AfxGetApp()->LoadIcon(IDR_WBO_BOLT_INACTIVE);
}

CWinampMainWnd::~CWinampMainWnd()
{
	if (::IsWindow(m_pEQWnd->GetSafeHwnd()))
            m_pEQWnd->DestroyWindow();
	if (::IsWindow(m_pPEWnd->GetSafeHwnd()))
            m_pPEWnd->DestroyWindow();
	if (::IsWindow(m_pMBWnd->GetSafeHwnd()))
            m_pMBWnd->DestroyWindow();
        
	delete m_pMain;
	delete m_pTitlebar;
	delete m_pEQWnd;
	delete m_pPEWnd;
	delete m_pMBWnd;	
}

void CWinampMainWnd::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWinampMainWnd)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWinampMainWnd, CDialog)
	//{{AFX_MSG_MAP(CWinampMainWnd)
	ON_WM_MOVE()
	ON_WM_PAINT()
	ON_WM_KILLFOCUS()
	ON_WM_SETFOCUS()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_RBUTTONUP()
	ON_WM_TIMER()
	ON_COMMAND(IDM_ABOUT, OnAbout)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWinampMainWnd message handlers

BOOL CWinampMainWnd::OnInitDialog() 
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	m_pEQWnd->Create(this);
	m_pPEWnd->Create(this);
	m_pMBWnd->Create(this);

	if(!m_pMain->LoadBitmap("Skins\\main.bmp"))
		m_pMain->LoadBitmap(IDB_MAIN);
	if(!m_pMain->LoadBitmap("Skins\\titlebar.bmp"))
		m_pTitlebar->LoadBitmap(IDB_TITLEBAR);

	SetWindowPos(NULL,100,100,m_pMain->GetWidth(),m_pMain->GetHeight(),SWP_SHOWWINDOW);

	SetTimer(1, 200, NULL);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CWinampMainWnd::OnMove(int x, int y) 
{
	CDialog::OnMove(x, y);
	WINDOWPLACEMENT wp;
	GetWindowPlacement(&wp);

	int bottom	= wp.rcNormalPosition.bottom;
	int top		= wp.rcNormalPosition.top;
	int left	= wp.rcNormalPosition.left;
	int right	= wp.rcNormalPosition.right;
	int height	= bottom - top;
	int width	= right - left;

	CRect rcMB, rcEQ, rcPE;
	if (::IsWindow(m_pEQWnd->GetSafeHwnd()))
		m_pEQWnd->GetWindowRect(&rcEQ);
	if (::IsWindow(m_pPEWnd->GetSafeHwnd()))
		m_pPEWnd->GetWindowRect(&rcPE);
	if (::IsWindow(m_pMBWnd->GetSafeHwnd()))
		m_pMBWnd->GetWindowRect(&rcMB);
	
	if (::IsWindow(m_pEQWnd->GetSafeHwnd()))
		m_pEQWnd->SetWindowPos(NULL, left, bottom, rcEQ.Width(), rcEQ.Height(), SWP_NOACTIVATE | SWP_SHOWWINDOW);
	if (::IsWindow(m_pPEWnd->GetSafeHwnd()))
		m_pPEWnd->SetWindowPos(NULL, left, bottom + rcPE.Height(), rcPE.Width(), rcPE.Height(), SWP_NOACTIVATE | SWP_SHOWWINDOW);
	if (::IsWindow(m_pMBWnd->GetSafeHwnd()))
		m_pMBWnd->SetWindowPos(NULL, right, top, rcMB.Width(), rcMB.Height(),  SWP_NOACTIVATE | SWP_SHOWWINDOW);	
	
}


void CWinampMainWnd::OnPaint() 
{	
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		DrawInterface();
	}
}

void CWinampMainWnd::DrawInterface(BOOL bPaint /* = FALSE */)
{
	m_pMain->Draw(bPaint, this, 0, 0, m_map.OffSet(MAIN));

//	if(m_bFocus)
//		m_pTitlebar->Draw(bPaint, this, 0, 0, m_Titlemap.OffSet(ACTIVE));
//	else
//		m_pTitlebar->Draw(bPaint, this, 0, 0, m_Titlemap.OffSet(INACTIVE));
}

void CWinampMainWnd::OnKillFocus(CWnd* pNewWnd) 
{
	CDialog::OnKillFocus(pNewWnd);
	m_bFocus = FALSE;
	DrawInterface();
}

void CWinampMainWnd::OnSetFocus(CWnd* pNewWnd) 
{
	CDialog::OnSetFocus(pNewWnd);
	m_bFocus = TRUE;
	DrawInterface();
}

void CWinampMainWnd::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CRect rcWnd, rcTemp;
	GetClientRect(&rcWnd);

	rcTemp = rcWnd;
	rcTemp.bottom = rcTemp.top + 20;

	//Dragging
	if(rcTemp.PtInRect(point))
	{
		SetCapture();
		m_bDragging = TRUE;
		m_ptDragFrom = point;
	}

	rcTemp = rcWnd;
	rcTemp.right = rcTemp.right - 3;
	rcTemp.left = rcTemp.right - 7;
	rcTemp.top = rcTemp.top + 3;
	rcTemp.bottom = rcTemp.top + 7;

	//Close Window
	if(rcTemp.PtInRect(point))
	{
		DestroyWindow();
	}
	
	CDialog::OnLButtonDown(nFlags, point);
}

void CWinampMainWnd::OnLButtonUp(UINT nFlags, CPoint point) 
{
	if(m_bDragging)
	{
		ReleaseCapture();
		m_bDragging = FALSE;
	}
	
	CDialog::OnLButtonUp(nFlags, point);
}

void CWinampMainWnd::OnMouseMove(UINT nFlags, CPoint point) 
{
	CRect rcWnd;
	GetWindowRect(&rcWnd);

	ChooseCursor(point);

	if(m_bDragging && nFlags & MK_LBUTTON)
	{
		int xdiff = point.x - m_ptDragFrom.x;
		int ydiff = point.y - m_ptDragFrom.y;

		SetWindowPos(NULL, rcWnd.left + xdiff, rcWnd.top + ydiff, rcWnd.Width(), rcWnd.Height(), SWP_SHOWWINDOW);
	}	

	CDialog::OnMouseMove(nFlags, point);
}


void CWinampMainWnd::ChooseCursor(CPoint point)
{
	HCURSOR hCursor;
	CRect rcWnd, rcTemp;
	GetClientRect(&rcWnd);
	
	rcTemp = rcWnd;
	rcTemp.right = rcTemp.right - 3;
	rcTemp.left = rcTemp.right - 7;
	rcTemp.top = rcTemp.top + 3;
	rcTemp.bottom = rcTemp.top + 7;
	if(rcTemp.PtInRect(point))
	{
		hCursor = AfxGetApp()->LoadCursor(IDC_CLOSE);
		SetCursor(hCursor);
		return;
	}
	
	rcTemp = rcWnd;
	rcTemp.bottom = rcTemp.top + 20;
	if(rcTemp.PtInRect(point) || m_bDragging)
	{
		hCursor = AfxGetApp()->LoadCursor(IDC_DRAG);
		SetCursor(hCursor);
		return;
	}
	
	//Default
	hCursor = AfxGetApp()->LoadCursor(IDC_DEFAULT_ARROW);
	SetCursor(hCursor);	
}

void CWinampMainWnd::OnRButtonUp(UINT nFlags, CPoint point) 
{

	
	DoMainMenu();


	CDialog::OnRButtonUp(nFlags, point);
}

void CWinampMainWnd::OnTimer(UINT nIDEvent) 
{
	if(nIDEvent == 1)
	{
		//Scroll Window Text
		m_strTitle = m_strTitleSource.Mid(m_nCapPos);

		if(m_nCapPos != 0)
			m_strTitle += m_strTitleSource.Left(m_strTitleSource.GetLength() - m_strTitle.GetLength());

		if(m_nCapPos++ == m_strTitleSource.GetLength())
			m_nCapPos = 0;

		SetWindowText(m_strTitle);
		
	}
	CDialog::OnTimer(nIDEvent);
}

void CWinampMainWnd::DoMainMenu()
{
	//Default
	CMenu menu;
	VERIFY(menu.LoadMenu(IDR_MENU));
	POINT pp;
	GetCursorPos(&pp);
	menu.GetSubMenu(0)->TrackPopupMenu(TPM_LEFTALIGN | TPM_LEFTBUTTON,pp.x,pp.y,this);
}

void CWinampMainWnd::OnAbout() 
{
	CWinampAboutDlg dlg("NullSoft Winamp - About", this);
	dlg.DoModal();
}
