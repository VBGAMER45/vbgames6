// Winamp UI.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Winamp UI.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWinampUIApp

BEGIN_MESSAGE_MAP(CWinampUIApp, CWinApp)
	//{{AFX_MSG_MAP(CWinampUIApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWinampUIApp construction

CWinampUIApp::CWinampUIApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CWinampUIApp object

CWinampUIApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CWinampUIApp initialization

BOOL CWinampUIApp::InitInstance()
{
	// Standard initialization

	AfxEnableControlContainer();

	CWinampMainWnd m_MainWnd;
	m_pMainWnd = &m_MainWnd;

	int nResponse = m_MainWnd.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	return FALSE;
	
/*
	m_pMBWnd	= new CWinampMinibrowser();

	m_pMainWnd = m_pMBWnd;
	
	if(!m_pMBWnd->CreateEx(WS_EX_LEFT | WS_EX_LTRREADING | WS_EX_RIGHTSCROLLBAR | WS_EX_WINDOWEDGE | WS_EX_ACCEPTFILES,
		"Test App", "Test App", 
		WS_VISIBLE | WS_CLIPSIBLINGS | WS_BORDER | WS_OVERLAPPED | WS_DLGFRAME | WS_SYSMENU | WS_MINIMIZEBOX, 
		0,0,500,500, NULL, (HMENU)1234))
	{
        AfxMessageBox("Failed to create main window");
		return FALSE;
	}*/

	return TRUE;
}

int CWinampUIApp::ExitInstance() 
{
	
	return CWinApp::ExitInstance();
}
