#if !defined(AFX_WINAMPEQUALIZER_H__E55696FC_382C_11D3_B660_00C04F6801E7__INCLUDED_)
#define AFX_WINAMPEQUALIZER_H__E55696FC_382C_11D3_B660_00C04F6801E7__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// WinampEqualizer.h : header file
//
#define MAIN_X			0
#define MAIN_Y			0
#define TITLEBAR_X		0
#define TITLEBAR_Y		0
#define PREAMP_BAR_X	21
#define PREAMP_BAR_Y	37
#define ON_X			15
#define ON_Y			18
#define AUTO_X			39
#define AUTO_Y			18

#define EQ_X			78
#define EQ_Y			37
#define EQ_OFFSET		18

#define CLOSE_X				264
#define CLOSE_Y				4

#define SLIDER_PREAMP_X		23
#define SLIDER_Y			63
#define SLIDER_EQ_X			80
#define SLIDER_EQ_OFFSET	18

#define PRESET_X			214
#define PRESET_Y			18

#include "BitmapEx.h"
#include "EQMap.h"
#include "common.h"
/////////////////////////////////////////////////////////////////////////////
// CWinampEqualizer dialog

class CWinampEqualizer : public CWnd
{
// Construction
public:
	CWinampEqualizer();   // standard constructor
	~CWinampEqualizer();

	BOOL Create(CWnd* pParent);
	void DrawInterface(BOOL bPaint = FALSE);
	void ChooseCursor(CPoint point);

protected:
	CBitmapEx*	m_pInterface;
	CEQMap		m_map;

	BOOL		m_bFocus;
	BOOL		m_bDragging;
	CPoint		m_ptDragFrom;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWinampEqualizer)
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CWinampEqualizer)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnPaint();
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnSetFocus( CWnd* pOldWnd );
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WINAMPEQUALIZER_H__E55696FC_382C_11D3_B660_00C04F6801E7__INCLUDED_)
