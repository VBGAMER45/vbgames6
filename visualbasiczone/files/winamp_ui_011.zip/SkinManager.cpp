// SkinManager.cpp: implementation of the CSkinManager class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SkinManager.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSkinManager::CSkinManager()
{
	m_strStartDir = "";
}

CSkinManager::~CSkinManager()
{
}

void CSkinManager::Add(CSkin* info)
{
    if (info)
	{
		m_elements.Add(info);
	}

}

CSkin* CSkinManager::GetItem(int index)
{
    return m_elements.GetAt(index);
}

int CSkinManager::GetNumItems()
{
    return m_elements.GetCount();
}

void CSkinManager::EnumerateSkins()
{
	int SkinsFound = 0;
                
	if ( m_strStartDir.Right(1) != "\\" )
		m_strStartDir += "\\";
  
	CFileFind findDirectories;
	BOOL bWorking = findDirectories.FindFile(m_strStartDir + "*");
  
	while (bWorking)
	{
		bWorking = findDirectories.FindNextFile();
    
		if ( findDirectories.IsDirectory() == TRUE &&
				findDirectories.IsDots() == FALSE )
		{
			CSkin* skin = new CSkin;
            skin->SetPath(findDirectories.GetFilePath());
            skin->SetName(findDirectories.GetFileName());
            Add(skin);
			SkinsFound++;
			delete skin;
		}
	}
             
}




//*********************************************
//* CSKin
//*********************************************

CSkin::CSkin()
{
    m_strPath = "";
    m_strName = "";
}

CSkin::~CSkin()
{

}

const CSkin& CSkin::operator=(const CSkin &source)
{
	if(&source != this)
	{
		m_strPath			= source.m_strPath;
		m_strName			= source.m_strName;
	}	
	return *this;
}

const CSkin& CSkin::operator=(const CSkin* source)
{
	if(source != this)
	{
		m_strPath			= source->m_strPath;
		m_strName			= source->m_strName;
	}	
	return *this;
}

CSkinList::CSkinList()
{
	m_nCount = 0;
}

CSkinList::~CSkinList()
{

}

void CSkinList::Add(CSkin* skin)
{
	m_skins[m_nCount] = skin;
	m_nCount++;
}

CSkin* CSkinList::GetAt(int index)
{
	return &m_skins[index];
}
