#if !defined(AFX_WINAMPPLAYLISTEDITOR_H__E55696FE_382C_11D3_B660_00C04F6801E7__INCLUDED_)
#define AFX_WINAMPPLAYLISTEDITOR_H__E55696FE_382C_11D3_B660_00C04F6801E7__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// WinampPlaylistEditor.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CWinampPlaylistEditor
#include "common.h"
#include "PEMap.h"

class CWinampPlaylistEditor : public CWnd
{
// Construction
public:
	CWinampPlaylistEditor();   // standard constructor
	~CWinampPlaylistEditor();

	BOOL Create(CWnd* pParent);
	void ChooseCursor(CPoint point);
	void DrawInterface(BOOL bPaint = FALSE);

protected:
	CBitmapEx*	m_pInterface;
	CPEMap		m_map;

	BOOL		m_bFocus;

	BOOL		m_bResizing;
	CPoint		m_ptResizeFrom;

	BOOL		m_bDragging;
	CPoint		m_ptDragFrom;

	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWinampPlaylistEditor)
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CWinampPlaylistEditor)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnPaint();
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnSetFocus( CWnd* pOldWnd );
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WINAMPPLAYLISTEDITOR_H__E55696FE_382C_11D3_B660_00C04F6801E7__INCLUDED_)
