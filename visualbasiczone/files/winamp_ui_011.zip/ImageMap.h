// ImageMap.h: interface for the CImageMap class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IMAGEMAP_H__018CE6D8_1E42_11D3_B643_00C04F6801E7__INCLUDED_)
#define AFX_IMAGEMAP_H__018CE6D8_1E42_11D3_B643_00C04F6801E7__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


#define MAX_AREAS	50

class CImageMap  
{
public:
	CImageMap();

	virtual ~CImageMap();
	CRect OffSet(int Index){return m_ImageMap[Index];}

protected:
	CRect m_ImageMap[MAX_AREAS];
};

#endif // !defined(AFX_IMAGEMAP_H__018CE6D8_1E42_11D3_B643_00C04F6801E7__INCLUDED_)
