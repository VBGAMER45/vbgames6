Game Map Editor
1998 Version 1.0

By Paul Pagel


CONTENTS
--------------------------------------------------------------------
1. Introduction
2. Legal stuff
3. Menus and commands
4. Using the editor
5. Using tile sets and overlays
6. File formats
7. Other notes


1. INTRODUCTION
--------------------------------------------------------------------
Game Map Editor was designed to assist in the building of game worlds, primarily for RPGs.  However, the design should be flexible enough to work for any type of game that uses a tiled map with a minimum of modification.

Note: If reading this file in Notepad, make sure Edit->Word Wrap is checked.


2. LEGAL DISCLAIMER
--------------------------------------------------------------------
This program and source code may be freely modified and distributed, provided that this notice and the above credits are included in their entirety.  This program is provided 'as is' with no guarantee of merchantibility, either explicit or implied.  The author will in no way be held responsible for any damages incurred from the use or misuse of this software.


3. MENUS AND COMMANDS
--------------------------------------------------------------------
[File]
This menu is used to load, save, and modify the current map data.  The default extension for map files is *.map. See the 'File formats' section for a description of the map file format.

[Tiles]  
This menu is used to load, save, and modify the ground-level/floor tile set. The default extension for tile set files is *.tls. See below for a description of the tile set file format.

[Overlay]
This menu is used to load, save, and modify the overlay tile set. Overlay tiles are transparently overlaid on top of the ground-level  tiles. The mask color determines which color will be transparent. The default extension for overlay set files is *.tls, and their format is identical to that used by floor tile sets.

[Settings]
This menu is used to toggle various program settings based on the user's preference.

[Help]
Used to access information about the Game Map Editor program.


4. USING THE EDITOR
--------------------------------------------------------------------
[Map Window]
The large picture box (picMap) is contains the current view of the map. It may be scrolled using the up/down/left/right buttons by the lower right hand corner. Clicking the left mouse button places the currently selected floor tile into the map at the cursor's current position.  Right-clicking places the current overlay tile at that position.

[Current Map Frame]
This frame contains information about the current map, including it's filename, x and y dimensions (032x032), map number, and current cursor position.  Clicking the [...] button is identical to the File->Open menu command.  The [Properties] button allows the user to change the current map number and dimensions. If the map is resized to a dimension smaller than the original, all data in the rows or columns greater than the new dimensions are lost.

[Tile Set Frame]
This frame contains information about the current tile set, including it's filename, a list of all current tiles, and a graphical preview of the currently-selected tile. Clicking on the list selects the current tile.  Clicking the [Modify] button allows the user to insert or delete tiles from the current tile set, and to modify each tile's Key and Behavior values. (See 'Using tile sets and overlays' for more info.)

[Overlay Set Frame]
This frame operates identically to the Tile Set frame. The only difference is the 'Mask Color' setting. This determines what color will be transparent when the overlay tile is drawn.  Clicking on the Mask Color will toggle it between white and black. Due to a limitation with Windows, these are the only colors that work correctly as color masks.


5. USING TILE SETS AND OVERLAYS
--------------------------------------------------------------------
Game Map Editor comes with several tiles pre-loaded. These are intended for demonstration purposes, but you are free to use them if you so desire.  To change the pre-loaded tile selection, right-click on the imlFloorTiles ImageList control at the bottom of frmMain, then select 'Properties' and click on the 'Images' tab. The Key field is used for the tile Key property, and the Tag field is used for the tile Behavior property.

To add new tiles to the current tile set, click the [Modify] button or menu entry.  If one or more tiles are present you may click on a tile in the upper display window to select it. (The inserted tile will be added to right of the highlighted tile.) Click the [Insert] button and choose the tile picture file you want added. For best results, use 24-bit color bmp images. Then enter the Key value you wish to use for this tile. The Key must be unique within the tile set, and once it is entered it cannot be changed without deleting the tile.

The [Delete] button deletes the currently highlighted tile, or the first one in the list if none are highlighted.

The Behavior field can contain any value that you wish - string or numeric. It should provide a way to tell what each tile's function is. The behavior combo box is automatically loaded with a list of all behaviors found in the current tile set. You may add behaviors not in the list by typing them in the text field of the combo box. 

To work properly, all tiles in the tile set must be square and have the same dimensions.  The default is 32x32 pixels.  Change the TILE_SIZE constant in MGlobals to match whatever size you want to use. You may also need to manually change the scale dimensions of picHidden to match your desired tile size.

The same rules apply to overlay pictures. The defaults are stored in the imlOverlay ImageList control on frmMain. Make sure that all the mask colors for an overlay set are the same - either white or black. Even minor differences in shade from the mask color will not work correctly.


6. FILE FORMATS
--------------------------------------------------------------------
[*.map]
The map file is currently an ASCII file and may be viewed with any text editor such as Notepad. (This may change in future versions.)

File header info:
MapNumber, Map Size X (#columns), Map Size Y (#rows), # of Layers (currently either 1 or 2)
TileSetName (MyTiles.tls),TileSetFileName (C:\MyTileDirectory\MyTiles.tls)
OverlayName, OverlayFilename 

Ground-level map data is written as a grid corresponding to the actual map display (x,y).  Each map position value corresponds to the number of the tile in the tile set.  Suppose the third tile in the tile set list is a chest, and the map data looks like this:

1 1 3
1 1 1
1 2 1

This map would have a chest in the upper right-hand corner.

The overlay information is stored in the same fashion.  A value of zero indicates no overlay tile is present, while any numbers correspond to the list number of the overlay tile.


[*.tls]
The tls file is also currently an ASCII file and may be viewed with any text editor such as Notepad. (This may change in future versions.)

The first value in a tile set file is the number of tiles in the file. Each tile has its own section in the file in the following format.

X Size, Y size
Tile Key value
Tile Behavior (Tag) value
(x,y pixel color values grid)

The x,y pixel color values are written in a grid format and contain the Long Integer color value for each pixel in the bitmap. While this is not the quickest and most efficient way to store graphical data, it is very flexible and easy to modify.


7. OTHER NOTES
--------------------------------------------------------------------
This program is NOT designed to be the Mother of All Editors. If it doesn't provide the functionality you're looking for, chances are that you can modify it to meet your needs.

Please notify me of any bugs found. Also drop me a line if you have any constructive comments, or have made a game using the editor.

Feel free to post this program on any websites or BBS's, provided that this file is included in its entirety. A courtesy notice of use would be appreciated.


Paul Pagel
pagel@clarityconnect.com
