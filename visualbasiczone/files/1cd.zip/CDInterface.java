//** File:
//     CDInterface.java
//** Author:
//     Greg Schenzel
//** Programming Language:
//     Microsoft J++ (Win32 Java / English)
//** Purpose:
//     Welcome! This file is the Java class
// 'CDInterface'. It has functions that simplify
// the audio playing process, such as 'Play' or
// 'Stop' that replace low-level commands such as
// 'mciSendCommand'.

import com.ms.wfc.app.*;
import com.ms.wfc.core.*;
import com.ms.wfc.ui.*;

public class CDInterface {

    // finds the CD audio device, and returns a
	// handle. this handle should be returned to
	// subsequent functions as p1 or wDeviceID.
	public static int deviceINIT() {
 //		MCI_OPEN_PARMS mciOpenParms = new MCI_OPEN_PARMS();
 //       mciOpenParms.lpstrDeviceType = "cdaudio";
 //       mciOpenParms.lpstrAlias = "myalias";
 //       for (int iDrive = 0; iDrive < 26; ++iDrive) {
 //           mciOpenParms.wDeviceID = 0;
 //           mciOpenParms.lpstrElementName = (new Character((char)('A' + iDrive))).toString() + ":";

 //           int mciProblems = mciSendCommand(0, MCI_OPEN, MCI_OPEN_TYPE | MCI_OPEN_SHAREABLE | MCI_OPEN_ELEMENT | MCI_OPEN_ALIAS, mciOpenParms);
 //           if (mciProblems == 0) return mciOpenParms.wDeviceID;
 //       }
 //       return -1;

		MCI_OPEN_PARMS mciopen = new MCI_OPEN_PARMS();
		mciopen.wDeviceID = 0;
		mciopen.lpstrDeviceType = "cdaudio";

		int mciProblems = mciSendCommand(0, MCI_OPEN, MCI_OPEN_TYPE | MCI_OPEN_SHAREABLE, mciopen);
		if (mciProblems != 0) {
			showMciError(mciProblems);
			return -1;
		}
		return mciopen.wDeviceID;
	}

	public static void deviceEXIT(int p1) {
		StopMedia(p1);
	}

	public static int deviceUPDATE(int p1, Edit e, int currentTrack, boolean MediaPlaying, boolean MediaPaused) {
        int mciProblems;

        if (MediaPlaying) {
			int totalTracks = GetTotalTracks(p1);
            int tmpTrack = GetCurrentTrack(p1);
            if (tmpTrack != currentTrack) {
				    String mediaTrack = "Track " + tmpTrack;

                    // The last track on CD is being
					//played, so stop when it's over.
                    if (currentTrack == totalTracks) { 
                        currentTrack = 1;
                        e.setText(" " + currentTrack + " ");
                        StopMedia(p1);
                    }
                    else { 
                        currentTrack = tmpTrack;
                        e.setText(" " + tmpTrack + " ");
                    }
            }

			SetTimeFormat(p1);
			MCI_STATUS_PARMS mciStatusParms = new MCI_STATUS_PARMS();
            mciStatusParms.dwItem = MCI_STATUS_POSITION;
            mciProblems = mciSendCommand(p1, MCI_STATUS, MCI_STATUS_ITEM, mciStatusParms);
	        if (mciProblems != 0) {
		        showMciError(mciProblems);
	        }
			else {
				// no problems, so update the display.
				String fullBin = Integer.toBinaryString(mciStatusParms.dwReturn);
				if (fullBin.length() < 32)
					for (int count = 1; count < (33-fullBin.length()); count++)
						fullBin = "0" + fullBin;
				String track   = Integer.valueOf(fullBin.substring(fullBin.length() - 8, fullBin.length() - 0), 2).toString();
				String min     = Integer.valueOf(fullBin.substring(fullBin.length() - 16, fullBin.length() - 8), 2).toString();
				String sec     = Integer.valueOf(fullBin.substring(fullBin.length() - 24, fullBin.length() - 16), 2).toString();
				if (min.length() == 1) min = "0" + min;
				if (sec.length() == 1) sec = "0" + sec;
				e.setText("Track " + track +
						  String.valueOf((char)13) +
						  String.valueOf((char)10) +
						  min + ":" + sec);
			}
		}
		return currentTrack;
	}

	public static boolean isMediaPresent(int p1) {
		MCI_STATUS_PARMS mciStatusParms = new MCI_STATUS_PARMS();
        mciStatusParms.dwItem = MCI_STATUS_MEDIA_PRESENT;
        int mciProblems = mciSendCommand(p1, MCI_STATUS, MCI_STATUS_ITEM, mciStatusParms);
		if (mciProblems != 0) {
		    showMciError(mciProblems);
	    }
		if (mciStatusParms.dwReturn == 0)
			return false;
		return true;
	}

	public static void Play(int p1, int track, boolean MediaPlaying, boolean MediaPaused) {
		int mciProblems;
		if (MediaPaused == false) {
			// start play
			SetTimeFormat(p1);
			mciProblems = PlayMedia(p1, track);
			if (mciProblems >= 0) {
				// working
			}
		}
		else {
			// resume play
			mciProblems = mciSendCommand(p1, MCI_RESUME, MCI_NOTIFY, new MCI_PLAY_PARMS());
			if (mciProblems != 0)
				showMciError(mciProblems);
   		}
	}

	public static void Stop(int p1, boolean MediaPlaying, boolean MediaPaused) {
		if (MediaPlaying || MediaPaused)
			StopMedia(p1);
	}

	public static void Pause(int p1, boolean MediaPlaying, boolean MediaPaused) {
		if (MediaPlaying || MediaPaused) {
            int mciProblems = mciSendCommand(p1, MCI_PAUSE, MCI_NOTIFY, new MCI_PLAY_PARMS());
            if (mciProblems != 0)
				showMciError(mciProblems);
		}
	}

	public static void Eject(int p1, boolean MediaPlaying, boolean MediaPaused) {
		if (MediaPlaying == false && MediaPaused == false) {
			int mciProblems = mciSendCommand(p1, MCI_SET, MCI_SET_DOOR_OPEN, new MCI_SET_PARMS());
			if (mciProblems != 0)
				showMciError(mciProblems);
		}
	}

	public static void BackTrack(int p1, boolean MediaPlaying, boolean MediaPaused) {
		if (MediaPlaying || MediaPaused) {
	        int currentTrack = GetCurrentTrack(p1);
			int totalTracks = GetTotalTracks(p1);

		    // If current track equals 1, skip to
			//total track, else decrement track.
	        if (currentTrack == 1)
		        currentTrack = totalTracks;
			else
				--currentTrack;
	        StopMedia(p1);
			PlayMedia(p1, currentTrack);
		}
	}

	public static void ForwardTrack(int p1, boolean MediaPlaying, boolean MediaPaused) {
		if (MediaPlaying || MediaPaused) {
	        int currentTrack = GetCurrentTrack(p1);
			int totalTracks = GetTotalTracks(p1);

		    // If current track equals total track, 
			//skip to track 1, else increment track.
	        if (currentTrack == totalTracks)
		        currentTrack = 1;
			else
				++currentTrack;
	        StopMedia(p1);
			PlayMedia(p1, currentTrack);
		}
	}

	//////////////////////////////////////
	////// Lower-Level Methods ///////////
	//////////////////////////////////////

    // displays messagebox for errors generated
	// by mci commands.
    public static void showMciError(int mciProblems) {
        StringBuffer sbuf = new StringBuffer(512);
        boolean flag;

        flag = mciGetErrorString(mciProblems, sbuf, sbuf.capacity()+1);
        if (flag)
            MessageBox.show(sbuf.toString(), "Error Message", MessageBox.OKCANCEL);
        else
            MessageBox.show("Call to mciGetErrorString() failed", "Error Message", MessageBox.OKCANCEL);
    }

    public static boolean SetTimeFormat(int wDeviceID) {
        MCI_SET_PARMS mciSetParms = new MCI_SET_PARMS();
        mciSetParms.dwTimeFormat = MCI_FORMAT_TMSF;
        
        int mciProblems = mciSendCommand(wDeviceID, MCI_SET, MCI_SET_TIME_FORMAT, mciSetParms);
        if (mciProblems != 0) {
            showMciError(mciProblems);
            return false;
        }
        return true;
    }

    public static int GetTotalTracks(int wDeviceID) {
        MCI_STATUS_PARMS mciStatusParms = new MCI_STATUS_PARMS();
        mciStatusParms.dwItem = MCI_STATUS_NUMBER_OF_TRACKS;

        int mciProblems = mciSendCommand(wDeviceID, MCI_STATUS, MCI_STATUS_ITEM, mciStatusParms);
        if (mciProblems != 0) {
            showMciError(mciProblems);
            return 0;
        }
        return mciStatusParms.dwReturn;
    }

    public static int GetCurrentTrack(int wDeviceID) {
        MCI_STATUS_PARMS mciStatusParms = new MCI_STATUS_PARMS();
        mciStatusParms.dwItem = MCI_STATUS_CURRENT_TRACK;

        int mciProblems = mciSendCommand(wDeviceID, MCI_STATUS, MCI_STATUS_ITEM, mciStatusParms);
        if (mciProblems != 0) {
            showMciError(mciProblems);
            return 0;
        }
        return mciStatusParms.dwReturn;
    }
    
    public static int PlayMedia(int wDeviceID, int track) {
        MCI_PLAY_PARMS mciPlayParms = new MCI_PLAY_PARMS();
        mciPlayParms.dwFrom = track;

        int mciProblems = mciSendCommand(wDeviceID, MCI_PLAY, MCI_FROM, mciPlayParms);
        if (mciProblems != 0) {
              showMciError(mciProblems);
              return -1;
        }
        return 1;
    }

    public static void StopMedia(int wDeviceID) {
        int mciProblems = mciSendCommand(wDeviceID, MCI_STOP, 0, new MCI_GENERIC_PARMS());
        if (mciProblems != 0)
			showMciError(mciProblems);
    }

    // Win32 functions  : Added using the J/Direct Call Builder
	private static final int MCI_WAIT = 0x00000002;
	private static final int MCI_SET_DOOR_OPEN = 0x00000100;
	private static final int MCI_SET_DOOR_CLOSED = 0x00000200;
	private static final int MCI_OPEN = 0x0803;
    private static final int MCI_SET_TIME_FORMAT = 0x00000400;
    private static final int MCI_CLOSE = 0x0804;
    private static final int MCI_PLAY = 0x0806;
    private static final int MCI_STOP = 0x0808;
    private static final int MCI_SET = 0x080D;
    private static final int MCI_STATUS = 0x0814;
    private static final int MCI_FROM = 0x00000004;
    private static final int MCI_OPEN_ALIAS = 0x00000400;
    private static final int MCI_OPEN_ELEMENT = 0x00000200;
    private static final int MCI_OPEN_TYPE = 0x00002000;
    private static final int MCI_STATUS_ITEM = 0x00000100;
    private static final int MCI_TRACK = 0x00000010;
    private static final int MCI_CDA_STATUS_TYPE_TRACK = 0x00004001;
    private static final int MCI_STATUS_CURRENT_TRACK = 0x00000008;
    private static final int MCI_STATUS_MEDIA_PRESENT = 0x00000005;
    private static final int MCI_STATUS_NUMBER_OF_TRACKS = 0x00000003;
    private static final int MCI_FORMAT_TMSF = 10;
    private static final int MCI_OPEN_SHAREABLE = 0x00000100;
    private static final int MCI_SEQ_STATUS_PORT = 0x00004003;
    private static final int MCI_NOTIFY = 0x00000001;
    private static final int MCI_PAUSE = 0x0809;
    private static final int MCI_RESUME = 0x0855;
    private static final int MCI_OVLY_WINDOW_HWND = 0x00010000;
    private static final int MCI_WINDOW = 0x0841;
    private static final int MCI_OVLY_PUT_DESTINATION = 0x00040000;
    private static final int MCI_OVLY_RECT = 0x00010000;
    private static final int MCI_PUT = 0x0842;
    private static final int MCI_OVLY_WHERE_DESTINATION = 0x00040000;
    private static final int MCI_WHERE = 0x0843;
    private static final int MCI_STATUS_LENGTH = 0x00000001;
    private static final int MCI_STATUS_POSITION = 0x00000002;

	/**F
     * @dll.struct(pack=1) 
     */
    private static class MCI_GENERIC_PARMS { 
        public int dwCallback;
    }

    /**
     * @dll.struct(pack=1, auto) 
     */
    private static class MCI_OPEN_PARMS { 
        public int dwCallback;
        public int wDeviceID;
        public String lpstrDeviceType;
        public String lpstrElementName;
        public String lpstrAlias;
    }

    /**
     * @dll.struct(pack=1) 
     */
    private static class MCI_PLAY_PARMS { 
        public int dwCallback;
        public int dwFrom;
        public int dwTo;
    }

    /**
     * @dll.struct(pack=1) 
     */
    private static class MCI_SET_PARMS { 
        public int dwCallback;
        public int dwTimeFormat;
        public int dwAudio;
    }

    /**
     * @dll.struct(pack=1) 
     */
    private static class MCI_STATUS_PARMS { 
        public int dwCallback;
        public int dwReturn;
        public int dwItem;
        public int dwTrack;
    }

    /**
     * @dll.struct(pack=1) 
     */
    private static class MCI_SEQ_SET_PARMS { 
        public int dwCallback;
        public int dwTimeFormat;
        public int dwAudio;
        public int dwTempo;
        public int dwPort;
        public int dwSlave;
        public int dwMaster;
        public int dwOffset;
    }
    
    /**
     * @dll.struct(pack=1, auto) 
     */
    private static class MCI_OVLY_WINDOW_PARMS { 
        public int dwCallback;
        public int hWnd;
        public int nCmdShow;
        public String lpstrText;
    }
    
    /**
     * @dll.struct(pack=1) 
     */
    private static class MCI_OVLY_RECT_PARMS { 
        public int dwCallback;
        public com.ms.win32.RECT rc;
    }

    /**
     * @dll.import("WINMM", auto) 
     */
    private static native int mciSendCommand(int mciId, int uMsg, int dwParam1, int dwParam2);

    /**
     * @dll.import("WINMM", auto) 
     */
    private static native int mciSendCommand(int mciId, int uMsg, int dwParam1, Object dwParam2);

    /**
     * @dll.import("WINMM", auto) 
     */
    private static native boolean mciGetErrorString(int mcierr, StringBuffer pszText, int cchText);
}