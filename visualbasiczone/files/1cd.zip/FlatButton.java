import com.ms.wfc.core.*;
import com.ms.wfc.ui.*;
import com.ms.lang.Delegate;

/**
 * This class is a visual component. The entry point for class execution
 * is the constructor.
 * 
 * This class can be used as an ActiveX control. Check the checkbox for this class 
 * on the Project Properties COM Classes tab, or remove the // from the next line:
// * @com.register ( clsid=87A2C04D-5694-4A2E-A925-033DE7105D31, typelib=80FD1037-C04A-4285-B2EE-BAD7FFAD34F2 )
 */
public class FlatButton
       extends UserControl
	   implements IButtonControl {

    //  These are constants for the colors
    // used in the boxes. This is the order
    // in BTN_UP.
    private final Color white = Color.WHITE;
    private final Color upperHighlight = new Color(223,223,223);
    private final Color lightShadow = new Color(128,128,128);
    private final Color black = Color.BLACK;

    //  These are my constants for the
    // button types.
    private final int BTN_UP = 1;
    private final int BTN_FLAT = 2;
    private final int BTN_DOWN = 3;

    //  These are buffers for setBackColor(),
    // setText(), and current button state
    // respectively.
	private Color enabledBuffer = Color.BLACK;
    private Color backBuffer; //retrieved from setBackColor();
    private String textBuffer; //retrieved from setText();
    private int upDown = BTN_FLAT; //Up = 1; Flat = 2; Down = 3

    //  I use this so I can tell when I can
    // legally start drawing.
    private String hasAccessed;

    //  Source entry point...
    public FlatButton() {
        super();
        initForm(); //Required for Visual J++ Form Designer support
        hasAccessed = "YES";
    }

    ////////////////////////////////////////
    //  The following are subs that I use to
    // make my events smaller, quicker, and
    // more easily understandable.

    /** This is a sub to draw the button; it
     * takes a parameter of BTN_UP, BTN_FLAT,
     * or BTN_DOWN.
     */
    private void drawButton(int num) {
        int nx = 0, ny = 0;
        Bitmap pregraph = new Bitmap(this.getWidth(),this.getHeight());
        Graphics openimg = pregraph.getGraphics();
        openimg.setBackColor(backBuffer);
        setGrBack(openimg,backBuffer); //MUST RUN EARLY!
        switch (num) {
            case BTN_UP: {
                drawGrLine(openimg,white,0,0,0,this.getHeight()-2); //LeftOuter_White
                drawGrLine(openimg,upperHighlight,1,1,1,this.getHeight()-2); //LeftInner_LightGrey
                drawGrLine(openimg,white,0,0,this.getWidth()-2,0); //TopOuter_White
                drawGrLine(openimg,upperHighlight,1,1,this.getWidth()-2,1); //TopInner_LightGrey
                drawGrLine(openimg,black,this.getWidth()-1,0,this.getWidth()-1,this.getHeight()); //RightOuter_Black
                drawGrLine(openimg,lightShadow,this.getWidth()-2,0,this.getWidth()-2,this.getHeight()-1); //rightInner_DarkGrey
                drawGrLine(openimg,black,0,this.getHeight()-1,this.getWidth(),this.getHeight()-1); //BottomOuter_Black
                drawGrLine(openimg,lightShadow,0,this.getHeight()-2,this.getWidth()-1,this.getHeight()-2); //bottomInner_DarkGrey
                break;
            }
            case BTN_FLAT: {
                drawGrLine(openimg,white,0,0,0,this.getHeight()); //left
                drawGrLine(openimg,white,0,0,this.getWidth(),0); //top
                drawGrLine(openimg,lightShadow,this.getWidth()-1,0,this.getWidth()-1,this.getHeight()); //right
                drawGrLine(openimg,lightShadow,0,this.getHeight()-1,this.getWidth(),this.getHeight()-1); //bottom
                break;
            }
            case BTN_DOWN: {
                drawGrBox(openimg,black,new Point(0,0),new Point(this.getWidth(),this.getHeight()));
                drawGrBox(openimg,lightShadow,new Point(1,1),new Point(this.getWidth()-2,this.getHeight()-2));
                drawGrLine(openimg,white,this.getWidth()-2,1,this.getWidth()-2,this.getHeight()-1); //right
                drawGrLine(openimg,white,1,this.getHeight()-2,this.getWidth()-2,this.getHeight()-2); //bottom
                nx = 2; ny = 2; //Simulates pressing action on text
                break;
            }
        }
		drawGrString(openimg, textBuffer, nx, ny, this.getHeight(), this.getWidth());
        pictureBox1.setImage(pregraph);
    }

    private void setGrBack(Graphics gr, Color cr) {
        gr.setBrush(new Brush(cr));
        gr.floodFill(1,1,gr.getBackColor(),FloodFillType.BORDER);
    }

	private void drawGrString(Graphics gr, String text, int x, int y, int height, int width) {
        gr.setFont(this.getFont());
		gr.setTextColor(enabledBuffer);
        gr.drawString(text, new Rectangle(x, y, width, height), TextFormat.HORIZONTALCENTER | TextFormat.VERTICALCENTER | TextFormat.EDITCONTROL);
	}

    private void drawGrLine(Graphics gr, Color cr, int x01, int y01, int x02, int y02) {
        gr.setPen(new Pen(cr));
        gr.drawLine(new Point(x01,y01), new Point(x02,y02));
    }

    private void drawGrBox(Graphics gr, Color cr, Point upLeft, Point bttmRight) {
        gr.setPen(new Pen(cr));
        gr.drawRect(new Rectangle(upLeft.x, upLeft.y, bttmRight.x, bttmRight.y));
    }

    /*//////////////////////////////////////
    ////////////////////////////////////////
    // YOU NEED NOT GO BEYOND THIS POINT! //
    ////////////////////////////////////////
    //////////////////////////////////////*/

    ////////////////////////////////////////
    // Properties & Events
    public static class ClassInfo extends UserControl.ClassInfo {
        public void getEvents(IEvents events) {
            super.getEvents(events);
        }

        public void getProperties(IProperties props) {
            super.getProperties(props);
        }
    }
    
    /**
     * NOTE: The following code is required by the Visual J++ form
     * designer.  It can be modified using the form editor.  Do not
     * modify it using the code editor.
     */
    Container components = new Container();
    PictureBox pictureBox1 = new PictureBox();

    private void initForm() {
        this.setFont(new Font("MS Sans Serif", 10.0f, FontSize.CHARACTERHEIGHT, FontWeight.NORMAL, false, false, false, com.ms.wfc.app.CharacterSet.DEFAULT, 0));
        this.setSize(new Point(169, 51));
        this.setText("FlatButton");
        this.addOnResize(new EventHandler(this.FlatButton_resize));
        this.addOnPaint(new PaintEventHandler(this.FlatButton_paint));

        pictureBox1.setSize(new Point(160, 40));
        pictureBox1.setTabIndex(0);
        pictureBox1.setTabStop(false);
        pictureBox1.setText("pictureBox1");
        pictureBox1.addOnClick(new EventHandler(this.pictureBox1_click));
        pictureBox1.addOnMouseDown(new MouseEventHandler(this.pictureBox1_mouseDown));
        pictureBox1.addOnMouseEnter(new EventHandler(this.pictureBox1_mouseEnter));
        pictureBox1.addOnMouseLeave(new EventHandler(this.pictureBox1_mouseLeave));
        pictureBox1.addOnMouseUp(new MouseEventHandler(this.pictureBox1_mouseUp));

        this.setNewControls(new Control[] {
                            pictureBox1});
    }

    ////////////////////////////////////////
    //  The following are basic level
    // painting events that are fairly
    // self-explanitory.
    private void FlatButton_resize(Object source, Event e) {
        pictureBox1.setHeight(this.getHeight());
        pictureBox1.setWidth(this.getWidth());
    }

    private void FlatButton_paint(Object source, PaintEvent e) {
        this.onResize(new Event());
        drawButton(upDown); //upDown is default to BTN_FLAT
    }

    ////////////////////////////////////////
    //  The following are mouse events for
    // my button...
    private void pictureBox1_mouseEnter(Object source, Event e) {
        upDown = BTN_UP;
        drawButton(upDown);
    }

    private void pictureBox1_mouseLeave(Object source, Event e) {
        upDown = BTN_FLAT;
        drawButton(upDown);
    }

    private void pictureBox1_mouseDown(Object source, MouseEvent e) {
        upDown = BTN_DOWN;
        drawButton(upDown);
    }

    private void pictureBox1_mouseUp(Object source, MouseEvent e) {
        upDown = BTN_FLAT;
        drawButton(upDown);
    }

    private void pictureBox1_click(Object source, Event e) {
		if (this.getEnabled() == true)
			this.onClick(e);
    }

    ////////////////////////////////////////
    //  These two methods are here for
    // to accomodate the required methods
    // in IButtonControl.
    private boolean def = false;
    public void notifyDefault(boolean def) {
        if (this.def != def) {
            this.def = def;
            invalidate();
            update();
        }
    }

    public void performClick() {
        this.onClick(Event.EMPTY);
    }

    ////////////////////////////////////////
    //  These two methods override the
    // inherited ones to accomodate the
    // buffers & refreshing...
    public void setBackColor(Color p1) {
        backBuffer = p1;        if ( hasAccessed == "YES" )
            drawButton(upDown);        super.setBackColor(p1);
    }

	public void setEnabled(boolean p1) {
		if ( p1 == true )
			enabledBuffer = black;
		else
			enabledBuffer = lightShadow;
        if ( hasAccessed == "YES" )
            drawButton(upDown);
		super.setEnabled(p1);
	}

    public void setText(String p1) {
        textBuffer = p1;        if ( hasAccessed == "YES" )
            drawButton(upDown);        super.setText(p1);
    }
}