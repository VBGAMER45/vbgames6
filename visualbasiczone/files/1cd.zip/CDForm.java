import com.ms.wfc.app.*;
import com.ms.wfc.core.*;
import com.ms.wfc.ui.*;
import com.ms.wfc.io.*;

/**
 * This class can take a variable number of parameters on the command
 * line. Program execution begins with the main() method. The class
 * constructor is not invoked unless an object of type 'CDForm' is
 * created in the main() method.
 */
public class CDForm extends Form {
    public static int wDeviceID = 0; // Device ID of the device being played
	public static int currentTrack = 1;
    public static boolean MediaPlaying = false; // Flags to indicate whether Media is
    public static boolean MediaPaused = false; // playing/paused or not
	public static boolean MediaPresent = false;
	public static boolean firstTime = true;

    public CDForm() {
        // init vars, controls, objects
        initForm(); // Required for Visual J++ Form Designer support
        wDeviceID = CDInterface.deviceINIT();

        // centre to screen
        this.setLeft((Screen.getPrimary().bounds.height - this.getHeight()) / 2);
        this.setTop((Screen.getPrimary().bounds.height - this.getHeight()) / 2);
    }

    private void CDForm_closing(Object source, CancelEvent e) {
        CDInterface.deviceEXIT(wDeviceID);
    }

    /**
     * CDForm overrides dispose so it can clean up the
     * component list.
     */
    public void dispose() {
        super.dispose();
        components.dispose();
    }

    private void btnPlay_click(Object source, Event e) {
        CDInterface.Play(wDeviceID, 1, MediaPlaying, MediaPaused);
	    MediaPlaying = true;
		MediaPaused = false;
	}

    private void btnStop_click(Object source, Event e) {
        CDInterface.Stop(wDeviceID, MediaPlaying, MediaPaused);
	    MediaPlaying = false;
		MediaPaused = false;
    }

    private void btnPause_click(Object source, Event e) {
        CDInterface.Pause(wDeviceID, MediaPlaying, MediaPaused);
	    MediaPlaying = false;
		MediaPaused = true;
    }

    private void btnEject_click(Object source, Event e) {
        CDInterface.Eject(wDeviceID, MediaPlaying, MediaPaused);
	    MediaPlaying = false; //these don't need to be set, because
		MediaPaused = false;  //you can't click it if they are not.
    }

    private void btnBTrack_click(Object source, Event e) {
        CDInterface.BackTrack(wDeviceID, MediaPlaying, MediaPaused);
		comboBox1.setSelectedIndex(comboBox1.getSelectedIndex()-2);
	    MediaPlaying = true;
		MediaPaused = false;
    }

    private void btnFTrack_click(Object source, Event e) {
        CDInterface.ForwardTrack(wDeviceID, MediaPlaying, MediaPaused);
	    MediaPlaying = true;
		MediaPaused = false;
    }

    private void timer1_timer(Object source, Event e) {
		boolean there = CDInterface.isMediaPresent(wDeviceID);
		if (MediaPresent != there || firstTime == true) {
			// media has been inserted/removed
			MediaPresent = there;
			firstTime = false;
			if (MediaPresent) {
				int tracks = CDInterface.GetTotalTracks(wDeviceID);
				comboBox1.setMaxDropDownItems(tracks);
				for (int i = 1; i <= tracks; i++) {
					String cd = "Track " + String.valueOf(i);
					comboBox1.addItem(cd);
				}
			}
		}

		if (MediaPresent) {
			// there is something in there
			if (MediaPlaying) {
				// .. and it is playing
				currentTrack = CDInterface.deviceUPDATE(wDeviceID, edit1, currentTrack, MediaPlaying, MediaPaused);
				if (comboBox1.getDroppedDown() == false)
					comboBox1.setSelectedIndex(currentTrack-1);
				btnPlay.setEnabled(false);
				btnStop.setEnabled(true);
				btnPause.setEnabled(true);
				btnEject.setEnabled(false);
				btnFTrack.setEnabled(true);
				btnBTrack.setEnabled(true);
			}
			else if (MediaPaused) {
				// .. and it is paused
				btnPlay.setEnabled(true);
				btnStop.setEnabled(true);
				btnPause.setEnabled(false);
				btnEject.setEnabled(false);
				btnFTrack.setEnabled(true);
				btnBTrack.setEnabled(true);
			}
			else {
				// .. and it is stopped
				btnPlay.setEnabled(true);
				btnStop.setEnabled(false);
				btnPause.setEnabled(false);
				btnEject.setEnabled(true);
				btnFTrack.setEnabled(false);
				btnBTrack.setEnabled(false);
			}
		}
		else {
			// media has been removed
			comboBox1.removeAll();
			edit1.setText("");
		    btnPlay.setEnabled(false);
		    btnStop.setEnabled(false);
		    btnPause.setEnabled(false);
			btnEject.setEnabled(true);
		    btnFTrack.setEnabled(false);
			btnBTrack.setEnabled(false);
		}
    }

	private void comboBox1_selectedIndexChanged(Object source, Event e) {
		CDInterface.Play(wDeviceID, comboBox1.getSelectedIndex()+1, MediaPlaying, MediaPaused);
	    MediaPlaying = true;
		MediaPaused = false;
	}

	/**
	 * NOTE: The following code is required by the Visual J++ form
	 * designer.  It can be modified using the form editor.  Do not
	 * modify it using the code editor.
	 */
	Container components = new Container();
	Edit edit1 = new Edit();
	FlatButton btnPlay = new FlatButton();
	FlatButton btnBTrack = new FlatButton();
	FlatButton btnStop = new FlatButton();
	FlatButton btnPause = new FlatButton();
	FlatButton btnEject = new FlatButton();
	FlatButton btnFTrack = new FlatButton();
	Label totalplay = new Label();
	ComboBox comboBox1 = new ComboBox();
	Timer timer1 = new Timer(components);

	private void initForm()
	{
		this.setText("J++ infoCDplayer");
		this.setAutoScaleBaseSize(new Point(5, 13));
		this.setBorderStyle(FormBorderStyle.FIXED_3D);
		this.setClientSize(new Point(367, 173));
		this.setMaximizeBox(false);
		this.addOnClosing(new CancelEventHandler(this.CDForm_closing));

		edit1.setBackColor(Color.BLACK);
		edit1.setCursor(Cursor.ARROW);
		edit1.setEnabled(false);
		edit1.setFont(new Font("Arial", 18.0f, FontSize.CHARACTERHEIGHT, FontWeight.BOLD, false, false, false, CharacterSet.DEFAULT, 0));
		edit1.setForeColor(Color.SCROLLBAR);
		edit1.setLocation(new Point(24, 24));
		edit1.setSize(new Point(176, 72));
		edit1.setTabIndex(0);
		edit1.setText("");
		edit1.setAutoSize(false);
		edit1.setMultiline(true);
		edit1.setReadOnly(true);
		edit1.setWordWrap(false);

		btnPlay.setFont(new Font("Verdana", 9.0f, FontSize.POINTS, FontWeight.NORMAL, false, false, false, CharacterSet.DEFAULT, 0));
		btnPlay.setLocation(new Point(208, 24));
		btnPlay.setSize(new Point(40, 32));
		btnPlay.setTabIndex(1);
		btnPlay.setText(">");
		btnPlay.addOnClick(new EventHandler(this.btnPlay_click));

		btnBTrack.setFont(new Font("Verdana", 9.0f, FontSize.POINTS, FontWeight.NORMAL, false, false, false, CharacterSet.DEFAULT, 0));
		btnBTrack.setLocation(new Point(208, 64));
		btnBTrack.setSize(new Point(40, 32));
		btnBTrack.setTabIndex(2);
		btnBTrack.setText("|<<");
		btnBTrack.addOnClick(new EventHandler(this.btnBTrack_click));

		btnStop.setFont(new Font("Verdana", 9.0f, FontSize.POINTS, FontWeight.NORMAL, false, false, false, CharacterSet.DEFAULT, 0));
		btnStop.setLocation(new Point(256, 24));
		btnStop.setSize(new Point(40, 32));
		btnStop.setTabIndex(3);
		btnStop.setText("\u007F");
		btnStop.addOnClick(new EventHandler(this.btnStop_click));

		btnPause.setFont(new Font("Verdana", 9.0f, FontSize.POINTS, FontWeight.NORMAL, false, false, false, CharacterSet.DEFAULT, 0));
		btnPause.setLocation(new Point(304, 24));
		btnPause.setSize(new Point(40, 32));
		btnPause.setTabIndex(4);
		btnPause.setText("||");
		btnPause.addOnClick(new EventHandler(this.btnPause_click));

		btnEject.setFont(new Font("Verdana", 9.0f, FontSize.POINTS, FontWeight.NORMAL, false, false, false, CharacterSet.DEFAULT, 0));
		btnEject.setLocation(new Point(304, 64));
		btnEject.setSize(new Point(40, 32));
		btnEject.setTabIndex(5);
		btnEject.setText("EJECT");
		btnEject.addOnClick(new EventHandler(this.btnEject_click));

		btnFTrack.setFont(new Font("Verdana", 9.0f, FontSize.POINTS, FontWeight.NORMAL, false, false, false, CharacterSet.DEFAULT, 0));
		btnFTrack.setLocation(new Point(256, 64));
		btnFTrack.setSize(new Point(40, 32));
		btnFTrack.setTabIndex(6);
		btnFTrack.setText(">>|");
		btnFTrack.addOnClick(new EventHandler(this.btnFTrack_click));

		totalplay.setLocation(new Point(24, 104));
		totalplay.setSize(new Point(320, 16));
		totalplay.setTabIndex(7);
		totalplay.setTabStop(false);
		totalplay.setText("");
		totalplay.setBorderStyle(BorderStyle.FIXED_3D);

		comboBox1.setLocation(new Point(24, 128));
		comboBox1.setSize(new Point(320, 21));
		comboBox1.setTabIndex(9);
		comboBox1.setText("");
		comboBox1.setStyle(ComboBoxStyle.DROPDOWNLIST);
		comboBox1.addOnSelectedIndexChanged(new EventHandler(this.comboBox1_selectedIndexChanged));

		timer1.setInterval(1000);
		timer1.setEnabled(true);
		timer1.addOnTimer(new EventHandler(this.timer1_timer));

		this.setNewControls(new Control[] {
							comboBox1, 
							totalplay, 
							btnFTrack, 
							btnEject, 
							btnPause, 
							btnStop, 
							btnBTrack, 
							btnPlay, 
							edit1});
	}

    /**
     * The main entry point for the application. 
     *
     * @param args Array of parameters passed to the application
     * via the command line.
     */
    public static void main(String args[]) {
        Application.run(new CDForm());
    }
}