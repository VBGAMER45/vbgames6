********************************

 BladeX Game Demo

********************************

by Paul Pagel - pagel@clarityconnect.com

The latest version of this demo can be found at
The Code Node Homepage
http://members.xoom.com/DigiTorus/


RELEASE NOTES
----------------------------------------------
This demo demonstrates DirectX animation techniques, collision detection, and DirectSound usage for making a Legend of Zelda type game.  I may eventually turn it into a finished game - then again, maybe not.  All code, graphics, and sound are original.

Make sure when you unzipped the project (pkunzip -d option) that a subdirectory named Sounds was created and that it contains several .wav files.


REQUIREMENTS
----------------------------------------------
* The DirectX 5 and Win32 type libraries by Patrice Scribe.  It may also work with other versions (i.e. DirectX 6 tlb) but this has not yet been tested. The type libraries are available at www.chez.com/scribe/

* VB 5, preferrably with service pack 2 or higher.  The demo has also been successfully tested and will continue to be developed in VB 6.  VB service packs may be downloaded from http://msdn.microsoft.com/vbasic/download/default.htm

* Microsoft DirectX 5 or higher


LEGAL DISCLAIMER
----------------------------------------------
This program and source code may be freely modified and distributed, provided that this notice and the above credits are included in their entirety.  This program is provided 'as is' with no guarantee of merchantibility, either explicit or implied.  The author will in no way be held responsible for any damages incurred from the use or misuse of this software.


CONTROLLING THE DEMO
----------------------------------------------
[Arrow Keys]:  Move player
[A]:           Attack with sword
[S]:           Throw boomerang, select inventory
[Z]:           Player stats
[I]:           Show Inventory screen
[Esc]:         Close Inventory screen
[Q]:	       Quit the demo
