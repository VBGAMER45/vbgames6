This source code was distributed by Michael Wulfsohn for

Add to your VB Knowledge
http://www.ms-vb.com
by Michael Wulfsohn

created with
Visual Basic 5 SP3

Feel free to use parts of the source code in you own program, but if you post it on your web page, please acknowlege Add to your VB Knowledge and give a link to http://www.ms-vb.com