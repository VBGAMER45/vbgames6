Tray Icon Control
-----------------

You are free to use this control and source code in any way you wish, 
entirely at your own risk.

Description
-----------
A control that places an icon in the system tray.

Use
---
	Set the ToolTipText property to set the tray icon tooltip.  

	Use the Enabled property to toggle the icon.
	
	Respond to the MouseDown, MouseUp and DblClick events.
	
	---------------------------------------------------------------

Sample Project
--------------
The sample project supplied demonstrates how to add 'Minimize to Tray'
functionality to a Visual Basic application.

Paul Duffield
pduffield@apexmail.com
http://free.prohosting.com/~vbor/

November 1999