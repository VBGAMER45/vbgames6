The VBUSoftButton control is Freeware.  You may 
distribute it freely with your applications.  You are free 
to distribute copies of the control by itself as long as 
you also distribute the files, unmodified, that came with
this control.  These files are listed below.

The VBUSoftbutton is just like any other softbutton control
out there but his one has an optional dropdown button beside
the regular softbutton.  When clicked the dropdown button
fires a DropDown Event.

The VBUSoftButton control was developed with 
Visual Basic 5.0  This means that you will need the VB 5 
runtime files. I recommend using this control with VB 5
(Mainly because I haven't tested it under any other
development language.)

To register this control just open up VB and go to the screen
where you pick your components (In VB5 it is under the 
Projects|Components Menu). Click on the browse button. Now
find the VBUSoftButton.OCX and click OK.  Thats it.  Just remember
to check the X box next to the component name to add it to your
project.

These are the files that you should have received with this
control.

     VBUSoftButton.ocx
     ReadMe.txt  (What your reading right now.)
     

DISCLAIMER:
-----------
THIS CONTROL IS PROVIDED AS IS AND WITHOUT ANY WARRANTIES 
WHATSOEVER.  THE USER IS ADVISED TO THOROUGHLY TEST AND DEBUG
THEIR PROGRAM.  THE USER ASSUMES THE ENTIRE RISK OF USING
THE CONTROL.  THE AUTHOR OF THIS CONTROL IS UNDER NO LEGAL
RESPONSIBILTY.

If you have any questions or comments then please send me an
EMail to: 
larryallen@geocities.com   or

Visit My Website at:
Larry Allen's Visual Basic Universe
www.geocities.com/SiliconValley/Horizon/8806

Thank You
