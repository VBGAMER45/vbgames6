IsoRotate v1.2
--------------


IsoRotate is a simple application to aid game developers in creating isometric 
tiles/walls for their games. Basically this program will read in any block of tiles
in a standard image, and rotate all the tiles to the desired location.

To use IsoRotate, simply open any image which contains your tiles. You will see the image
you chose in the image preview pane located on the left of the screen. Once the image
has loaded, you have to setup the options for rendering the final image. The three
things you need to do are, Choose a gap (in pixels) to leave at the top of each frame,
then you must select the tile Background colour, and finally choose a brightness amount.

Then simply click any of the Rotate buttons to render the final image.

You can then save the image as you wish.


This release is extremely rushed, hense the use of InputBoxes in places. (Sorry) just had
to get it done. The source code is included for your convenience, it isn't good code, and
is not optimised at all, just an example.

Hope this helps some people who were wondering how it's done.

A quick note, you will notice that there is one empty pixel to the right of each tile.
This is not a bug, it has to be there for the tiles to fit together correctly. 
You will notice that there is 1 pixel protruding from the bottom corner of each tile.
This fits into that gap at the right of each tile.

Enjoy

Adam Hoult
Head Programmer and CEO
Daedalus Development Innovations
http://www.daedalusd.com
admin@daedalusd.com