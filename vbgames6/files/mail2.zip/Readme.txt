Email Sample
------------
Jonathan Valentin

You are free to use this source code in any way you wish, 
entirely at your own risk.

Description
-----------
Demonstrates a technique for sending email from within a VB app
without resorting to third part controls.

Paul Duffield
pduffield@lineone.net

January 1999