Extending the Textbox Control Demonstration Project - By Joacim Andersson

If you have any problems using this sample, or would like to ask a
question, please E-Mail us at: john@vb-world.net

Downloaded from VB-World.net at http://www.vb-world.net/

Updated 8/5/99