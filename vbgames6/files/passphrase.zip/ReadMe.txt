Password/Passphrase Creator v1.3                    11 Feb 2000

You will need the VB6 runtime files.

Visual Basic source code available on request.

This is freeware.  Since security is of the upmost these days,
a tool such as this should assist you in protecting your data.

--------------------------------------------------------------
Modification History
11 Feb 2000  1.3  Occassionally, would calculate the wrong 
                  data string length by one position
07 Feb 2000  1.2  Released to freeware
--------------------------------------------------------------


Files included:

      PWORDS     MDB  919,552  02-07-2000   PWords.mdb
      PASSPHRASE EXE   53,248  02-11-2000   PassPhrase.exe
      README     TXT    3,793  02-11-2000   ReadMe.txt

Note:    All three files must be in the same directory


The MDB file was created using Microsoft Access 97.  It has
been loaded with American English words varying in length from
three to eight characters.  There are currently over 26,700
words in this database.  

If you decide to also use numbers and/or the other printable 
characters on the keyboard, then you have a very formidable 
arsenal at your disposal to build your passwords or passphrases.
All passwords begin with an alpha character.  This is because
most security systems require it.

Options available:

o	Set the length of each password.  3 to 20 characters.
o	Each word in a passphrase can be 3 to 8 characters in length.
o	Choose from 1 to 14 words in a passphrase at a time.
o	Choose from 1 to 1000 passwords at a time.
o	Select whether to use alphabetic, numeric, special keyboard
	characters, or a mix of all the above.
o	Select if these are to be all characters are to be lowercase,
	uppercase, propercase, or a mix of all the above.
o	You can determine the number of charcters to be numeric or
	special characters
o	You can omit specific special characters by using the menu.
o	The ability to highlight and copy the data to another file
	for future reference.
o	Ability to add or delete data from the database tables.
o	You have the ability to save your data to a file or print it.

If you want to add your own words or your own language to the
database, follow these steps:

   1.  Open the database using Microsoft Access 97
   2.  Select Tools, Options, View.
   3.  On the Edit tab, check "Hidden Objects"
   4.  Click OK 
   5.  Now edit the tables with your enhancements.
   6.  After you are finished, remember to remove the check
       mark from "Hidden Objects" so the tables will remain hidden.

You have the option to manipulate the way passphrases are created.
You can choose all lowercase, all uppercase, all propercase 
(First letter of each word is uppercase) and mixed case (Letters
are converted to uppercase at random).  These are added security
features because most security sytems treat passwords and passphrases
as case sensitive.

This has been tested on Windows 98.  Let me know what you think.

-----------------------------------------------------------------
Written by Kenneth Ives                    kenaso@home.com

All of my routines have been compiled with VB6 Service Pack 3.
There are several locations on the web to obtain these
runtime modules.

This software is FREEWARE.  You may use it as you see fit for 
your own projects but you may not re-sell the original or the 
source code. If you redistribute it, you must include this 
disclaimer and all original copyright notices. 

No warranty expressed or implied is given as to the use of this
program.  Use at your own risk.

If you have any suggestions or questions, I would be happy to
hear from you.
-----------------------------------------------------------------
