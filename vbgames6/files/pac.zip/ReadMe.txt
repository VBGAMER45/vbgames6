VB-PACMAN Readme File

This Source Code Is Freeware, And Can Freely Be Distributed As Long As:
	* The Distributor Does Not Take Credit For This Source Code. 
	* The Distributor Does Not Charge For The Source Code.
	* I (Arvinder Sehmi) Grant Permision, E-Mail: VB@Arvinder.Co.Uk  <-OR->  Arvinder@Sehmi.Org.Uk  <-OR->   Arvinder@Bigfoot.com

The Source Code, Graphics and Levels Were Created By Arvinder Sehmi.
E-Mail: VB@Arvinder.co.uk
Web Page: www.arvinder.co.uk (not currently up)

PACMAN.EXE
=-=-=-=-=-

Keys: Use The Arrow Keys To Move Pacman.

Aim : Collect All The Food On The Levels.
 
Tip : Dodge The Beer As It Will Make Pacman Hard To Control.
      It Will Also Take 1000 Points Away.


LEVELEDIT.EXE
=-=-=-=-=-=-=

Aim : Create Your Own Cool Levels

Tips: * To Make Drawing Easier, Hold Down the SHIFT Buuton While Moving The Mouse. Make Sure You DO NOT HOLD DOWN ANY MOUSE BUTTONS!
      * Right Clicking On A Square Will Erase The Previous Content.
      * If You Intend To Make More Then One Level Set, Back The Other up First!


 