http://www.vb-helper.com/HowTo/ejectzip.zip

	Purpose
Eject a ZIP tape

	Method
Use the DeviceIoControl API function.

Note: I don't have a ZIP drive so I haven't tried this.

Thanks to Voronw� (voronwe@come.to) who dug up this code at the
VISBAS-L archives (http://eva.dc.lsoft.com/archives/visbas-l.html).

The code is mostly courtesy of Fred Vagner (FredVagner@geocities.com).


	Disclaimer
This example program is provided "as is" with no warranty of any kind. It is
intended for demonstration purposes only. In particular, it does no error
handling. You can use the example in any form, but please mention
www.vb-helper.com.
