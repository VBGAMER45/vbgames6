Hello, every body.

This is my win32program disassembler version 0.21.(October 16,1998)
This time I got rid of preccx dependencies. 
This means pure C code for decoding. 
And I totally redesigned program so,
speed is improved dramatically( at least as far ad i played with),
accuracy is improved, 
more information is displayed.
And, Oh yes, I added "hint" facility,
this means you can direct disassembler -- 
    some part of program is "code" 
    or "byte data" or "address" or
    "whatever it is significant"...	(actually only some part of
	                                 hint is implemented at this time}

in "hint file"-text file you may create.
you can specify information as follows:
    
    A: address
    B: byte data blocks  - implemented
    C: code blocks	 - implemented
    D: dwords
    F: floats
    G: doubles
    Q: quad words
    T: 80 bit reals	 - implemented
    W: words
    N: null strings
    P: pascal strings
    x:   end of hind file

format is as follows:
column  1: you give conversion specifier,
           which is A,B,C,D,F,G,Q,T,W,N,P, and x
column  2:     you need to give   ":" colon
column  3-10:  you need to give   start address
column  11:    you need to give   "-" minus
column  12-19: you need to give   ending address

last line should be 
    x:

the location from 0040512E(included) to 00405368(not included)
is converted to 80 bit reals.


<example for hint file> two lines between -------'s
-------------------------------------
C:00402345-00402356
T:0040512E-00405368
B:00410000-00411000
x:
-------------------------------------

The usage of hint file is as follows:

    dis "yourfile.exe" "hint.txt" > "yourfile.txt"

        if you have hint file or

    dis "yourfile.exe" > "yourfile.txt"


************************************************
Linux Porting
************************************************
Due to Uwe Bonnes, Win32Program Disassembler is tested under Linux.
He encouraged me to pay attention to the portability of disassembler.
Only thing you need to do is as follows:

1. convert dos file to unix file.
2. use the following make file and make.
3. thats all.

============Makefile=====================
CC=gcc
LD=gcc
VERSION = 0.21
CFLAGS= -g -DVERSION=\"$(VERSION)\"

C_SRCS= decoder.c ieee.c main.c pedump.c print.c
EXECUTABLE = pedisassem

all: $(EXECUTABLE)

OBJS = $(C_SRCS:.c=.o) $(GEN_ASM_SRCS:.s=.o) $(ASM_SRCS:.S=.o) \
        $(RC_SRCS:.rc=.o) $(EXTRA_OBJS)

pedisassem: $(OBJS)
        $(LD) -o $(EXECUTABLE) $(OBJS)

clean::
        $(RM) *.o \#*\# *~ *% .#* *.bak *.orig *.rej *.flc *-tmp.c y.tab.c y.tab.h lex.yy.c core $(GEN_ASM_SRCS) $(RC_SRCS:.rc=.s) $(RC_SRCS:.rc=.h) $(PROGRAMS)


+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
You can contact me if you have any questions or problems.
e-mail: sangcho@alpha94.chongju.ac.kr
homepage for disassembler: www.geocities.com/SiliconValley/Foothills/4078/
phone:  +82-431-229-8491 (South Korea)
p.s. i like to receive nice postcards from you.
if there is anyone who wants to express his/her gratitute
he/she can send me a nice postcard.

my snail address:
Sang Cho
Department of Computer and Information Engineering
ChongJu University
ChongJu 360-764
South Korea