http://www.vb-helper.com/HowTo/pingpong.zip

	Purpose
Make a ping pong program.

	Method
Look at the code. This is a pretty sophisticated game originally built as an
Easter egg program.

Thanks to Alexander Willemse (alexw@iaehv.nl).

	Disclaimer
This example program is provided "as is" with no warranty of any kind. It is
intended for demonstration purposes only. In particular, it does no error
handling. You can use the example in any form, but please mention
www.vb-helper.com.
