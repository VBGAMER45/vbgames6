Random Number Generator  

Converted from FORTRAN to C by Phil Linttell, James F. Hickling
Management Consultants Ltd, Aug. 14, 1989.

Converted from C to QuickBASIC by David Arigan Feb 4, 1996.

Converted QuickBASIC to Visual Basic by Kenneth Ives
kenaso@home.com Aug 29, 1999.

THIS IS ONE OF THE BEST KNOWN RANDOM NUMBER GENERATORS AVAILABLE.
However, a newly discovered technique can yield a period of
10^600, but that is still in the development stage.

This random number generator originally appeared in "Toward a
Universal Random Number Generator" by George Marsaglia and
Arif Zaman.
Florida State University Report:  FSU-SCRI-87-50 (1987)

It was later modified by F. James and published in "A Review
of Pseudo-Random Number Generators"

It passes ALL of the tests for random number generators and
has a period of 2^144, is completely portable (gives bit
identical results on all machines with at least 24-bit
mantissas in the floating point representation).

The algorithm is a combination of a Fibonacci sequence (with
lags of 97 and 33, and operation "subtraction plus one,
modulo one") and an "arithmetic sequence" (using subtraction).

Read the documentation in all the routines.

There are two test routines named "Test1" and "Test2".

-----------------------------------------------------------------
Converted to Visual Basic by Kenneth Ives        kenaso@home.com

All of my routines have been compiled with VB6 Service Pack 3.
There are several locations on the web to obtain these
modules.

Whenever I use someone else's code, I will give them credit.  
This is my way of saying thank you for your efforts.  I would
appreciate the same consideration.

Read all of the documentation within this program.  It is very
informative.  Also, if you learn to document properly now, you
will not be scratching your head next year trying to figure out
exactly what you were programming today.  Been there, done that.

This software is FREEWARE. You may use it as you see fit for 
your own projects but you may not re-sell the original or the 
source code. If you redistribute it you must include this 
disclaimer and all original copyright notices. 

No warranty express or implied, is given as to the use of this
program. Use at your own risk.

If you have any suggestions or questions, I'd be happy to
hear from you.
-----------------------------------------------------------------
