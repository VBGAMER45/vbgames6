DirectX MsgBox Demo
by Paul Pagel aka DigiTorus

e-mail:  DigiTorus@xoommail.com
website: VB Code Node
URL:     http://members.xoom.com/_XOOM/DigiTorus/

Requirements:  
VB6, DirectX 6 or higher, DirectX 6 type library by Patrice Scribe 
(may be downloaded at http://www.chez.com/scribe/)


Demonstrates how to build a Windows style popup message box, complete
with clickable buttons on DirectDraw surfaces.  Shows how to use
the included button classes to draw and detect button clicks, as well
as a reusable msgbox function.

You are free to use the demo classes and functions in your own 
projects.  A little note in your credits would be nice, but isn't 
required.
