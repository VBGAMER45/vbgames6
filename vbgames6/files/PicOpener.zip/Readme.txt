Thank you for downloading Softuarium PicOpener v2 demo.

Description
~~~~~~~~~~~
PicOpener is an ActiveX control that allows you to read image files in over 50 formats and convert them to BMP bitmaps. 
PicOpener supports the following formats:
BMP, BW, CDR, CDT, CEL, CLP, CMX, CPT, CUR, CUT, DCX, DIB, 
FLC, FLI, HAM, ICN, ICO, IFF, IMG, JFF, JIF, JMX, JPEG, JPG,
LBM, MAC, MSP, OFX, PAT, PBM, PC2, PCD, PCT, PCX, PIC, PGM,
PNG, PNM, PPM, PSD, PYX, QFX, RAS, RGB, RLE, SAM, SCx, SEP,
SGI, SUN, TGA, TIFF, UDI, WPG, ZBR

Note: GIF format is not supported. 

Installation
~~~~~~~~~~~~
To use PicOpener in your projects you must first register it using
Regsvr32.exe (you'll find it in windows\system directory). 
Alternatively, you can browse for it from within VB IDE, in which case it is registered automatically.
NOTE: you must register the control BEFORE you attempt to use it or run sample project included in the package.

Use
~~~
For practical demonstration please see included sample VB project.

PicOpener has the following properties:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

InputFile (string)
~~~~~~~~~
This is the full path of the image file you want to open. 
Example: PicOpen1.InputFile = "c:\windows\desktop\test.pcx"

OutputFolder (string)
~~~~~~~~~~~~
This is the path to the folder in which output bitmap will be created.
Example: PicOpen1.OutputFolder = "c:\pictures\bitmaps"

Note: The output bitmap will have the same name as input file, except for .bmp extension. If output folder contains a file with such a name it will be overwritten without warning.

PicOpener has one method:
~~~~~~~~~~~~~~~~~~~~~~~~~
Go 
~~
It reads the input image and saves output bitmap in output folder.
Example: PicOpen1.Go


Release information
~~~~~~~~~~~~~~~~~~~
PicOpener was created and compiled using VB6 with SP3.


Note on picture formats
~~~~~~~~~~~~~~~~~~~~~~~
Given the huge number of existing variations of image formats it is to be expected that PicOpener will not be able to open some files even if they appear to be in supported format. It is simply impossible to allow for all existing and future format modifications. Because of that please make sure that PicOpener is able to open the image files you want to work with before ordering the retail version. We will not honour requests for refund on the grounds that our software is not performing well with obsolete or future file formats, or files created with programs that use standard extensions to hide proprietary image format.

Pricing
~~~~~~~
The cost of retail version of PicOpener is $25. 
Retail version of PicOpener may be compiled using Microsoft Licence Key to protect your investment. 

Ordering
~~~~~~~~
At this time we only accept mail orders. 
For up to date information on how to order please visit our web site at http://users.senet.com.au/~eszlapek or email us at eszlapek@senet.com.au 

Disclaimer
~~~~~~~~~~
PicOpener control is distributed "as is".  No warranty of any kind is expressed or implied. While every precaution was taken to produce bug free code, you use it at your own risk. The author will not be liable for data loss, damages, loss of profits or any other kind of loss while using or misusing this software.


Thank you for using Softuarium PicOpener
